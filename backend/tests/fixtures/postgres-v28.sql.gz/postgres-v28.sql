BEGIN;
-- +goose Up
CREATE SCHEMA app;
REVOKE ALL ON SCHEMA app FROM PUBLIC;


-- +goose Up
CREATE TABLE app.audit_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    occurred_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    schema_version smallint NOT NULL DEFAULT 1 CHECK (schema_version = 1),
    actor_kind text NOT NULL CHECK (actor_kind IN ('system', 'user')),
    actor_user_id uuid,
    event_name text NOT NULL,
    resource_kind text NOT NULL CHECK (resource_kind ~ '^[a-z][a-z0-9_]{0,31}$'),
    resource_id uuid NOT NULL CHECK (resource_id <> '00000000-0000-0000-0000-000000000000'),
    client_id uuid CHECK (client_id <> '00000000-0000-0000-0000-000000000000'),
    request_id text NOT NULL CHECK (request_id ~ '^[A-Z2-7]{26}$'),
    before_state jsonb NOT NULL,
    after_state jsonb NOT NULL,
    metadata jsonb NOT NULL,
    CHECK ((actor_kind = 'system' AND actor_user_id IS NULL) OR
           (actor_kind = 'user' AND actor_user_id IS NOT NULL AND
            actor_user_id <> '00000000-0000-0000-0000-000000000000')),
    CHECK (event_name IN (resource_kind || '.created', resource_kind || '.updated',
                         resource_kind || '.archived', resource_kind || '.deleted')),
    CHECK (octet_length(before_state::text) <= 1024),
    CHECK (octet_length(after_state::text) <= 1024),
    CHECK (octet_length(metadata::text) <= 256 AND jsonb_typeof(metadata) = 'object' AND
           metadata - 'source' = '{}'::jsonb AND metadata ? 'source' AND
           jsonb_typeof(metadata->'source') = 'string' AND
           metadata->>'source' IN ('http', 'job', 'cli'))
);

-- Explicit key/type allowlists also reject raw SQL attempts to store secrets.
-- +goose StatementBegin
CREATE FUNCTION app.audit_snapshot_allowed(value jsonb) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE STRICT SET search_path = pg_catalog AS $$
BEGIN
    IF value = 'null'::jsonb THEN RETURN true; END IF;
    IF jsonb_typeof(value) <> 'object' OR value - ARRAY['exists', 'revision'] <> '{}'::jsonb THEN
        RETURN false;
    END IF;
    IF value ? 'exists' AND jsonb_typeof(value->'exists') <> 'boolean' THEN RETURN false; END IF;
    IF value ? 'revision' THEN
        IF jsonb_typeof(value->'revision') <> 'number' OR
           value->>'revision' !~ '^(0|[1-9][0-9]*)$' THEN RETURN false; END IF;
        IF (value->>'revision')::numeric > 9223372036854775807 THEN RETURN false; END IF;
    END IF;
    RETURN true;
END;
$$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION app.audit_snapshot_allowed(jsonb) FROM PUBLIC;
ALTER TABLE app.audit_events ADD CONSTRAINT audit_before_allowlist CHECK (app.audit_snapshot_allowed(before_state));
ALTER TABLE app.audit_events ADD CONSTRAINT audit_after_allowlist CHECK (app.audit_snapshot_allowed(after_state));

CREATE INDEX audit_events_resource_time ON app.audit_events (resource_kind, resource_id, occurred_at, id);
CREATE INDEX audit_events_client_time ON app.audit_events (client_id, occurred_at, id) WHERE client_id IS NOT NULL;
CREATE INDEX audit_events_actor_time ON app.audit_events (actor_user_id, occurred_at, id) WHERE actor_user_id IS NOT NULL;
CREATE INDEX audit_events_request ON app.audit_events (request_id);

-- +goose StatementBegin
CREATE FUNCTION app.audit_deny_history_change() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog AS $$
BEGIN
    RAISE EXCEPTION 'Audit history is append-only' USING ERRCODE = '42501';
END;
$$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION app.audit_deny_history_change() FROM PUBLIC;
CREATE TRIGGER audit_history_append_only BEFORE UPDATE OR DELETE OR TRUNCATE ON app.audit_events
FOR EACH STATEMENT EXECUTE FUNCTION app.audit_deny_history_change();
ALTER TABLE app.audit_events ENABLE ALWAYS TRIGGER audit_history_append_only;
REVOKE ALL ON TABLE app.audit_events FROM PUBLIC;

-- No hardcoded deployment role or default privileges for future domain tables.
-- Provision column-level INSERT and snapshot validator EXECUTE separately.


-- +goose Up
CREATE TABLE app.users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    email text NOT NULL,
    display_name text NOT NULL,
    password_hash text NOT NULL,
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
    bootstrap_admin boolean NOT NULL DEFAULT false,
    last_login_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (email = lower(email) AND email = btrim(email) AND octet_length(email) BETWEEN 3 AND 254 AND
           email ~ '^[a-z0-9.!#$%&''*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$'),
    CHECK (display_name = btrim(display_name) AND char_length(display_name) BETWEEN 1 AND 100),
    CHECK (octet_length(password_hash) BETWEEN 60 AND 255),
    CHECK (updated_at >= created_at AND (last_login_at IS NULL OR last_login_at >= created_at))
);
CREATE UNIQUE INDEX users_email_unique ON app.users (email);
CREATE UNIQUE INDEX users_single_bootstrap_admin ON app.users (bootstrap_admin) WHERE bootstrap_admin;

CREATE TABLE app.sessions (
    id uuid PRIMARY KEY,
    user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    token_hash bytea NOT NULL UNIQUE CHECK (octet_length(token_hash) = 32),
    csrf_hash bytea NOT NULL CHECK (octet_length(csrf_hash) = 32),
    created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    CHECK (expires_at > created_at AND expires_at <= created_at + interval '12 hours 1 minute'),
    CHECK (revoked_at IS NULL OR revoked_at >= created_at)
);
CREATE INDEX sessions_user_active ON app.sessions (user_id, expires_at) WHERE revoked_at IS NULL;
CREATE INDEX sessions_expiry ON app.sessions (expires_at) WHERE revoked_at IS NULL;

-- Keep credential/session lookup behind narrow invoker contracts rather than
-- granting the runtime role bulk reads of identity tables.
-- +goose StatementBegin
CREATE FUNCTION app.authentication_identity(candidate_email text)
RETURNS TABLE(id uuid, email text, display_name text, password_hash text, status text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog ROWS 1 AS $$
    SELECT u.id, u.email, u.display_name, u.password_hash, u.status
    FROM app.users u WHERE u.email = candidate_email;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.lock_authentication_identity(candidate_id uuid)
RETURNS TABLE(password_hash text, status text)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path = pg_catalog ROWS 1 AS $$
    SELECT u.password_hash, u.status FROM app.users u WHERE u.id = candidate_id FOR UPDATE;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.current_identity(candidate_token_hash bytea, checked_at timestamptz)
RETURNS TABLE(session_id uuid, user_id uuid, email text, display_name text, expires_at timestamptz, csrf_hash bytea)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog ROWS 1 AS $$
    SELECT s.id, u.id, u.email, u.display_name, s.expires_at, s.csrf_hash
    FROM app.sessions s JOIN app.users u ON u.id = s.user_id
    WHERE s.token_hash = candidate_token_hash AND s.revoked_at IS NULL
      AND s.expires_at > checked_at AND u.status = 'active';
$$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION app.authentication_identity(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION app.lock_authentication_identity(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION app.current_identity(bytea,timestamptz) FROM PUBLIC;
REVOKE ALL ON TABLE app.users, app.sessions FROM PUBLIC;

-- Runtime grants are provisioned explicitly for the deployment role after migration.


-- +goose Up
CREATE TABLE app.permissions (
    permission_key text PRIMARY KEY CHECK (permission_key ~ '^[a-z][a-z0-9_]{0,31}\.[a-z][a-z0-9_]{0,31}$'),
    scope_kind text NOT NULL CHECK (scope_kind IN ('global', 'client')),
    description text NOT NULL CHECK (description = btrim(description) AND char_length(description) BETWEEN 1 AND 160)
);

CREATE TABLE app.roles (
    id uuid PRIMARY KEY,
    role_key text NOT NULL UNIQUE CHECK (role_key ~ '^[a-z][a-z0-9_]{0,31}$'),
    display_name text NOT NULL CHECK (display_name = btrim(display_name) AND char_length(display_name) BETWEEN 1 AND 100),
    system_role boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    CHECK (updated_at >= created_at)
);

CREATE TABLE app.role_permissions (
    id uuid PRIMARY KEY,
    role_id uuid NOT NULL REFERENCES app.roles(id) ON DELETE RESTRICT,
    permission_key text NOT NULL REFERENCES app.permissions(permission_key) ON DELETE RESTRICT,
    seeded boolean NOT NULL DEFAULT false,
    assigned_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    revoked_at timestamptz,
    CHECK (revoked_at IS NULL OR revoked_at >= assigned_at)
);
CREATE UNIQUE INDEX role_permissions_active ON app.role_permissions (role_id, permission_key)
    WHERE revoked_at IS NULL;

CREATE TABLE app.user_roles (
    id uuid PRIMARY KEY,
    user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
    role_id uuid NOT NULL REFERENCES app.roles(id) ON DELETE RESTRICT,
    scope_kind text NOT NULL CHECK (scope_kind IN ('global', 'client')),
    client_id uuid,
    assigned_at timestamptz NOT NULL DEFAULT clock_timestamp(),
    revoked_at timestamptz,
    CHECK ((scope_kind = 'global' AND client_id IS NULL) OR
           (scope_kind = 'client' AND client_id IS NOT NULL AND client_id <> '00000000-0000-0000-0000-000000000000')),
    CHECK (revoked_at IS NULL OR revoked_at >= assigned_at)
);
CREATE UNIQUE INDEX user_roles_active_global ON app.user_roles (user_id, role_id)
    WHERE scope_kind = 'global' AND revoked_at IS NULL;
CREATE UNIQUE INDEX user_roles_active_client ON app.user_roles (user_id, role_id, client_id)
    WHERE scope_kind = 'client' AND revoked_at IS NULL;
CREATE INDEX user_roles_active_user ON app.user_roles (user_id, scope_kind, client_id)
    WHERE revoked_at IS NULL;

INSERT INTO app.permissions (permission_key, scope_kind, description) VALUES
    ('users.view',          'global', 'View user identities'),
    ('users.manage',        'global', 'Create and maintain user identities'),
    ('roles.view',          'global', 'View roles and permission assignments'),
    ('roles.manage',        'global', 'Maintain roles and permission assignments'),
    ('audit.view',          'global', 'View immutable audit history'),
    ('releases.view',       'global', 'View release status'),
    ('releases.manage',     'global', 'Manage release operations'),
    ('clients.create',      'global', 'Create client records'),
    ('clients.view',        'client', 'View client records'),
    ('clients.update',      'client', 'Update client records'),
    ('clients.archive',     'client', 'Archive client records'),
    ('billing.view',        'client', 'View client billing records'),
    ('billing.manage',      'client', 'Manage client billing records'),
    ('pricing.view',        'client', 'View client pricing'),
    ('pricing.manage',      'client', 'Manage client pricing'),
    ('tasks.view',          'client', 'View client tasks'),
    ('tasks.manage',        'client', 'Manage client tasks'),
    ('analytics.view',      'client', 'View client analytics'),
    ('integrations.manage', 'client', 'Manage client integrations');

INSERT INTO app.roles (id, role_key, display_name, system_role) VALUES
    ('00000000-0000-4000-8000-000000000001', 'initial_administrator', 'Initial Administrator', true),
    ('00000000-0000-4000-8000-000000000002', 'finance', 'Finance', true),
    ('00000000-0000-4000-8000-000000000003', 'viewer', 'Viewer', true);

INSERT INTO app.role_permissions (id, role_id, permission_key, seeded)
SELECT gen_random_uuid(), '00000000-0000-4000-8000-000000000001'::uuid, permission_key, true FROM app.permissions;
INSERT INTO app.role_permissions (id, role_id, permission_key, seeded) VALUES
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000002', 'clients.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000002', 'billing.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000002', 'billing.manage', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000002', 'pricing.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000003', 'clients.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000003', 'billing.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000003', 'pricing.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000003', 'tasks.view', true),
    (gen_random_uuid(), '00000000-0000-4000-8000-000000000003', 'analytics.view', true);

-- Existing bootstrap identities are migrated into ordinary RBAC assignments.
WITH assignments AS (
    INSERT INTO app.user_roles (id, user_id, role_id, scope_kind)
    SELECT gen_random_uuid(), id, '00000000-0000-4000-8000-000000000001', 'global'
    FROM app.users WHERE bootstrap_admin
    RETURNING id
)
INSERT INTO app.audit_events
    (actor_kind, actor_user_id, event_name, resource_kind, resource_id, client_id,
     request_id, before_state, after_state, metadata)
SELECT 'system', NULL, 'role_assignment.created', 'role_assignment', id, NULL,
       'AAAAAAAAAAAAAAAAAAAAAAAAAA', 'null', '{"exists":true}', '{"source":"cli"}'
FROM assignments;

-- Flattened effective grants. A client assignment deliberately omits global
-- permissions even if its role contains them.
-- +goose StatementBegin
CREATE FUNCTION app.authorization_grants(candidate_user uuid)
RETURNS TABLE(permission_key text, scope_kind text, client_id uuid)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
    SELECT DISTINCT p.permission_key,
           CASE WHEN ur.scope_kind = 'global' THEN 'global' ELSE 'client' END,
           ur.client_id
    FROM app.users u
    JOIN app.user_roles ur ON ur.user_id = u.id AND ur.revoked_at IS NULL
    JOIN app.role_permissions rp ON rp.role_id = ur.role_id AND rp.revoked_at IS NULL
    JOIN app.permissions p ON p.permission_key = rp.permission_key
    WHERE u.id = candidate_user AND u.status = 'active'
      AND (ur.scope_kind = 'global' OR p.scope_kind = 'client');
$$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.authorization_allowed(candidate_user uuid, candidate_permission text, candidate_client uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
    SELECT EXISTS (
        SELECT 1
        FROM app.users u
        JOIN app.user_roles ur ON ur.user_id = u.id AND ur.revoked_at IS NULL
        JOIN app.role_permissions rp ON rp.role_id = ur.role_id AND rp.revoked_at IS NULL
        JOIN app.permissions p ON p.permission_key = rp.permission_key
        WHERE u.id = candidate_user AND u.status = 'active'
          AND p.permission_key = candidate_permission
          AND ((p.scope_kind = 'global' AND candidate_client IS NULL AND ur.scope_kind = 'global') OR
               (p.scope_kind = 'client' AND candidate_client IS NOT NULL AND
                (ur.scope_kind = 'global' OR (ur.scope_kind = 'client' AND ur.client_id = candidate_client))))
    );
$$;
-- +goose StatementEnd

-- The actor needs global role administration plus every permission that the
-- requested assignment would make effective.
-- +goose StatementBegin
CREATE FUNCTION app.create_role_assignment(
    actor_id uuid, target_id uuid, requested_role uuid, requested_scope text,
    requested_client uuid, assignment_id uuid, assigned_time timestamptz)
RETURNS boolean
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF assignment_id IS NULL OR assignment_id = '00000000-0000-0000-0000-000000000000' OR
       requested_scope NOT IN ('global', 'client') OR
       (requested_scope = 'global' AND requested_client IS NOT NULL) OR
       (requested_scope = 'client' AND (requested_client IS NULL OR requested_client = '00000000-0000-0000-0000-000000000000')) OR
       NOT app.authorization_allowed(actor_id, 'roles.manage', NULL) OR
       NOT EXISTS (SELECT 1 FROM app.users WHERE id = target_id AND status = 'active') OR
       NOT EXISTS (SELECT 1 FROM app.roles WHERE id = requested_role) OR
       NOT EXISTS (
           SELECT 1 FROM app.role_permissions rp JOIN app.permissions p ON p.permission_key = rp.permission_key
           WHERE rp.role_id = requested_role AND rp.revoked_at IS NULL AND (requested_scope = 'global' OR p.scope_kind = 'client')
       ) OR EXISTS (
           SELECT 1 FROM app.role_permissions rp JOIN app.permissions p ON p.permission_key = rp.permission_key
           WHERE rp.role_id = requested_role AND rp.revoked_at IS NULL AND (requested_scope = 'global' OR p.scope_kind = 'client')
             AND NOT CASE
                 WHEN requested_scope = 'global' THEN EXISTS (
                     SELECT 1 FROM app.authorization_grants(actor_id) g
                     WHERE g.permission_key = p.permission_key AND g.scope_kind = 'global')
                 ELSE app.authorization_allowed(actor_id, p.permission_key, requested_client)
             END
       ) THEN
        RETURN false;
    END IF;
    INSERT INTO app.user_roles (id, user_id, role_id, scope_kind, client_id, assigned_at)
    VALUES (assignment_id, target_id, requested_role, requested_scope, requested_client, assigned_time);
    RETURN true;
EXCEPTION WHEN unique_violation OR foreign_key_violation OR check_violation THEN
    RETURN false;
END;
$$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.revoke_role_assignment(actor_id uuid, assignment_id uuid, revoked_time timestamptz)
RETURNS TABLE(changed boolean, client_id uuid)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE assignment app.user_roles%ROWTYPE;
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    SELECT * INTO assignment FROM app.user_roles WHERE id = assignment_id AND revoked_at IS NULL FOR UPDATE;
    IF NOT FOUND OR NOT app.authorization_allowed(actor_id, 'roles.manage', NULL) OR EXISTS (
        SELECT 1 FROM app.role_permissions rp JOIN app.permissions p ON p.permission_key = rp.permission_key
        WHERE rp.role_id = assignment.role_id AND rp.revoked_at IS NULL AND (assignment.scope_kind = 'global' OR p.scope_kind = 'client')
          AND NOT CASE
              WHEN assignment.scope_kind = 'global' THEN EXISTS (
                  SELECT 1 FROM app.authorization_grants(actor_id) g
                  WHERE g.permission_key = p.permission_key AND g.scope_kind = 'global')
              ELSE app.authorization_allowed(actor_id, p.permission_key, assignment.client_id)
          END
    ) THEN
        RETURN QUERY SELECT false, NULL::uuid;
        RETURN;
    END IF;
    UPDATE app.user_roles SET revoked_at = revoked_time WHERE id = assignment_id;
    RETURN QUERY SELECT true, assignment.client_id;
END;
$$;
-- +goose StatementEnd

-- Changing a role affects every current and future holder, so permission
-- delegation requires the actor to control that permission globally.
-- +goose StatementBegin
CREATE FUNCTION app.create_permission_assignment(
    actor_id uuid, requested_role uuid, requested_permission text,
    assignment_id uuid, assigned_time timestamptz)
RETURNS boolean
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF assignment_id IS NULL OR assignment_id = '00000000-0000-0000-0000-000000000000' OR
       NOT app.authorization_allowed(actor_id, 'roles.manage', NULL) OR
       NOT EXISTS (SELECT 1 FROM app.roles WHERE id = requested_role) OR
       NOT EXISTS (SELECT 1 FROM app.permissions WHERE permission_key = requested_permission) OR
       NOT EXISTS (
           SELECT 1 FROM app.authorization_grants(actor_id) g
           WHERE g.permission_key = requested_permission AND g.scope_kind = 'global'
       ) THEN
        RETURN false;
    END IF;
    INSERT INTO app.role_permissions (id, role_id, permission_key, assigned_at)
    VALUES (assignment_id, requested_role, requested_permission, assigned_time);
    RETURN true;
EXCEPTION WHEN unique_violation OR foreign_key_violation OR check_violation THEN
    RETURN false;
END;
$$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.revoke_permission_assignment(actor_id uuid, assignment_id uuid, revoked_time timestamptz)
RETURNS boolean
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE assignment app.role_permissions%ROWTYPE;
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    SELECT * INTO assignment FROM app.role_permissions WHERE id = assignment_id AND revoked_at IS NULL FOR UPDATE;
    IF NOT FOUND OR NOT app.authorization_allowed(actor_id, 'roles.manage', NULL) OR
       NOT EXISTS (
           SELECT 1 FROM app.authorization_grants(actor_id) g
           WHERE g.permission_key = assignment.permission_key AND g.scope_kind = 'global'
       ) THEN
        RETURN false;
    END IF;
    UPDATE app.role_permissions SET revoked_at = revoked_time WHERE id = assignment_id;
    RETURN true;
END;
$$;
-- +goose StatementEnd

REVOKE ALL ON TABLE app.permissions, app.roles, app.role_permissions, app.user_roles FROM PUBLIC;
REVOKE ALL ON FUNCTION app.authorization_grants(uuid),
                       app.authorization_allowed(uuid,text,uuid),
                       app.create_role_assignment(uuid,uuid,uuid,text,uuid,uuid,timestamptz),
                       app.revoke_role_assignment(uuid,uuid,timestamptz),
                       app.create_permission_assignment(uuid,uuid,text,uuid,timestamptz),
                       app.revoke_permission_assignment(uuid,uuid,timestamptz)
FROM PUBLIC;


-- +goose Up
ALTER TABLE app.users ADD COLUMN revision bigint NOT NULL DEFAULT 1 CHECK (revision > 0);
ALTER TABLE app.roles ADD COLUMN revision bigint NOT NULL DEFAULT 1 CHECK (revision > 0);

-- A recoverable administrator is defined by capabilities, never a role name.
-- VOLATILE gives fresh reads after the shared advisory lock, including in triggers.
-- +goose StatementBegin
CREATE FUNCTION app.admin_survives(excluded_user uuid, excluded_role_assignment uuid, excluded_permission_assignment uuid)
RETURNS boolean LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM app.users u WHERE u.status = 'active'
          AND (excluded_user IS NULL OR u.id <> excluded_user)
          AND (SELECT count(DISTINCT rp.permission_key) FROM app.user_roles ur
               JOIN app.role_permissions rp ON rp.role_id = ur.role_id AND rp.revoked_at IS NULL
               WHERE ur.user_id = u.id AND ur.scope_kind = 'global' AND ur.revoked_at IS NULL
                 AND rp.permission_key IN ('users.manage','roles.manage')
                 AND (excluded_role_assignment IS NULL OR ur.id <> excluded_role_assignment)
                 AND (excluded_permission_assignment IS NULL OR rp.id <> excluded_permission_assignment)) = 2
    );
END;
$$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.admin_guard_last() RETURNS trigger
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE excluded_user uuid; excluded_role uuid; excluded_permission uuid;
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF TG_TABLE_NAME = 'users' THEN
        IF OLD.status <> 'active' OR NEW.status = 'active' THEN RETURN NEW; END IF;
        excluded_user := OLD.id;
    ELSIF TG_TABLE_NAME = 'user_roles' THEN
        IF OLD.revoked_at IS NOT NULL THEN
            IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
        END IF;
        IF TG_OP = 'UPDATE' THEN
            IF NEW.revoked_at IS NULL AND (NEW.user_id,NEW.role_id,NEW.scope_kind,NEW.client_id) IS NOT DISTINCT FROM
               (OLD.user_id,OLD.role_id,OLD.scope_kind,OLD.client_id) THEN RETURN NEW; END IF;
        END IF;
        excluded_role := OLD.id;
    ELSE
        IF OLD.revoked_at IS NOT NULL THEN
            IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
        END IF;
        IF TG_OP = 'UPDATE' THEN
            IF NEW.revoked_at IS NULL AND (NEW.role_id,NEW.permission_key) IS NOT DISTINCT FROM
               (OLD.role_id,OLD.permission_key) THEN RETURN NEW; END IF;
        END IF;
        excluded_permission := OLD.id;
    END IF;
    IF app.admin_survives(NULL,NULL,NULL) AND NOT app.admin_survives(excluded_user,excluded_role,excluded_permission) THEN
        RAISE EXCEPTION 'Last administrator protected' USING ERRCODE = 'P1001';
    END IF;
    IF TG_OP = 'DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;
-- +goose StatementEnd
CREATE TRIGGER administration_last_user BEFORE UPDATE OF status ON app.users
FOR EACH ROW EXECUTE FUNCTION app.admin_guard_last();
CREATE TRIGGER administration_last_role BEFORE UPDATE OR DELETE ON app.user_roles
FOR EACH ROW EXECUTE FUNCTION app.admin_guard_last();
CREATE TRIGGER administration_last_permission BEFORE UPDATE OR DELETE ON app.role_permissions
FOR EACH ROW EXECUTE FUNCTION app.admin_guard_last();
ALTER TABLE app.users ENABLE ALWAYS TRIGGER administration_last_user;
ALTER TABLE app.user_roles ENABLE ALWAYS TRIGGER administration_last_role;
ALTER TABLE app.role_permissions ENABLE ALWAYS TRIGGER administration_last_permission;

-- Bounded read contracts check the current actor inside the database too.
-- +goose StatementBegin
CREATE FUNCTION app.admin_users(actor uuid, after_id uuid, page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    IF NOT app.authorization_allowed(actor,'users.view',NULL) THEN RAISE insufficient_privilege; END IF;
    IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
    RETURN QUERY SELECT jsonb_build_object('id',u.id,'email',u.email,'display_name',u.display_name,
        'status',u.status,'revision',u.revision,'created_at',u.created_at,'updated_at',u.updated_at,'last_login_at',u.last_login_at)
        FROM app.users u WHERE after_id IS NULL OR u.id > after_id ORDER BY u.id LIMIT page_limit;
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_user(actor uuid, target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    IF NOT app.authorization_allowed(actor,'users.view',NULL) THEN RAISE insufficient_privilege; END IF;
    RETURN (SELECT jsonb_build_object('id',u.id,'email',u.email,'display_name',u.display_name,
        'status',u.status,'revision',u.revision,'created_at',u.created_at,'updated_at',u.updated_at,'last_login_at',u.last_login_at)
        FROM app.users u WHERE u.id = target);
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_roles(actor uuid, after_id uuid, page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    IF NOT app.authorization_allowed(actor,'roles.view',NULL) THEN RAISE insufficient_privilege; END IF;
    IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
    RETURN QUERY SELECT jsonb_build_object('id',r.id,'display_name',r.display_name,'system_role',r.system_role,
        'revision',r.revision,'created_at',r.created_at,'updated_at',r.updated_at,
        'permissions',coalesce((SELECT jsonb_agg(rp.permission_key ORDER BY rp.permission_key)
            FROM app.role_permissions rp WHERE rp.role_id=r.id AND rp.revoked_at IS NULL),'[]'::jsonb))
        FROM app.roles r WHERE after_id IS NULL OR r.id > after_id ORDER BY r.id LIMIT page_limit;
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_role(actor uuid, target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    IF NOT app.authorization_allowed(actor,'roles.view',NULL) THEN RAISE insufficient_privilege; END IF;
    RETURN (SELECT jsonb_build_object('id',r.id,'display_name',r.display_name,'system_role',r.system_role,
        'revision',r.revision,'created_at',r.created_at,'updated_at',r.updated_at,
        'permissions',coalesce((SELECT jsonb_agg(rp.permission_key ORDER BY rp.permission_key)
            FROM app.role_permissions rp WHERE rp.role_id=r.id AND rp.revoked_at IS NULL),'[]'::jsonb))
        FROM app.roles r WHERE r.id=target);
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_catalog(actor uuid) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    IF NOT app.authorization_allowed(actor,'roles.view',NULL) THEN RAISE insufficient_privilege; END IF;
    RETURN QUERY SELECT jsonb_build_object('permission',p.permission_key,'scope',p.scope_kind,'description',p.description)
        FROM app.permissions p ORDER BY p.permission_key LIMIT 100;
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_assignments(actor uuid, target uuid, after_id uuid, page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    IF NOT app.authorization_allowed(actor,'roles.view',NULL) THEN RAISE insufficient_privilege; END IF;
    IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
    RETURN QUERY SELECT jsonb_build_object('id',ur.id,'user_id',ur.user_id,'role_id',ur.role_id,
        'display_name',r.display_name,'scope',ur.scope_kind,'client_id',ur.client_id,'assigned_at',ur.assigned_at)
        FROM app.user_roles ur JOIN app.roles r ON r.id=ur.role_id
        WHERE ur.user_id=target AND ur.revoked_at IS NULL AND (after_id IS NULL OR ur.id > after_id)
        ORDER BY ur.id LIMIT page_limit;
END;
$$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.admin_create_user(actor uuid, target uuid, supplied_email text, supplied_name text, supplied_hash text)
RETURNS text LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF NOT app.authorization_allowed(actor,'users.manage',NULL) THEN RETURN 'denied'; END IF;
    IF supplied_email IS NULL OR supplied_name IS NULL OR supplied_hash IS NULL OR
       target IS NULL OR target='00000000-0000-0000-0000-000000000000' OR
       supplied_hash !~ '^\$argon2id\$v=19\$m=19456,t=2,p=1\$[A-Za-z0-9+/]{22}\$[A-Za-z0-9+/]{43}$' THEN RETURN 'invalid'; END IF;
    INSERT INTO app.users (id,email,display_name,password_hash) VALUES (target,supplied_email,supplied_name,supplied_hash);
    RETURN 'ok';
EXCEPTION WHEN unique_violation THEN RETURN 'conflict';
          WHEN check_violation THEN RETURN 'invalid';
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_update_user(actor uuid, target uuid, expected_revision bigint, supplied_email text, supplied_name text)
RETURNS TABLE(outcome text, old_revision bigint, old_status text)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE record app.users%ROWTYPE;
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF NOT app.authorization_allowed(actor,'users.manage',NULL) THEN RETURN QUERY SELECT 'denied'::text,NULL::bigint,NULL::text; RETURN; END IF;
    IF supplied_email IS NULL OR supplied_name IS NULL THEN RETURN QUERY SELECT 'invalid'::text,NULL::bigint,NULL::text; RETURN; END IF;
    SELECT * INTO record FROM app.users WHERE id=target FOR UPDATE;
    IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::bigint,NULL::text; RETURN; END IF;
    IF expected_revision IS NULL OR expected_revision<1 OR record.revision <> expected_revision THEN RETURN QUERY SELECT 'conflict'::text,NULL::bigint,NULL::text; RETURN; END IF;
    UPDATE app.users SET email=supplied_email,display_name=supplied_name,revision=revision+1,updated_at=clock_timestamp() WHERE id=target;
    RETURN QUERY SELECT 'ok'::text,record.revision,record.status;
EXCEPTION WHEN unique_violation THEN RETURN QUERY SELECT 'conflict'::text,NULL::bigint,NULL::text;
          WHEN check_violation THEN RETURN QUERY SELECT 'invalid'::text,NULL::bigint,NULL::text;
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_disable_user(actor uuid, target uuid, expected_revision bigint)
RETURNS TABLE(outcome text, old_revision bigint, old_status text)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE record app.users%ROWTYPE;
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF NOT app.authorization_allowed(actor,'users.manage',NULL) THEN RETURN QUERY SELECT 'denied'::text,NULL::bigint,NULL::text; RETURN; END IF;
    IF actor=target THEN RETURN QUERY SELECT 'self_disable'::text,NULL::bigint,NULL::text; RETURN; END IF;
    SELECT * INTO record FROM app.users WHERE id=target FOR UPDATE;
    IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::bigint,NULL::text; RETURN; END IF;
    IF expected_revision IS NULL OR expected_revision<1 OR record.revision <> expected_revision OR record.status='disabled' THEN RETURN QUERY SELECT 'conflict'::text,NULL::bigint,NULL::text; RETURN; END IF;
    UPDATE app.users SET status='disabled',revision=revision+1,updated_at=clock_timestamp() WHERE id=target;
    UPDATE app.sessions SET revoked_at=clock_timestamp() WHERE user_id=target AND revoked_at IS NULL;
    RETURN QUERY SELECT 'ok'::text,record.revision,record.status;
END;
$$;
-- +goose StatementEnd

-- Global control is mandatory: changing a role affects all of its holders.
-- +goose StatementBegin
CREATE FUNCTION app.admin_create_role(actor uuid, target uuid, supplied_name text, supplied_permissions text[])
RETURNS text LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF NOT app.authorization_allowed(actor,'roles.manage',NULL) THEN RETURN 'denied'; END IF;
    IF supplied_name IS NULL OR target IS NULL OR target='00000000-0000-0000-0000-000000000000' OR
       supplied_permissions IS NULL OR cardinality(supplied_permissions) NOT BETWEEN 1 AND 100 OR
       cardinality(supplied_permissions) <> (SELECT count(DISTINCT p) FROM unnest(supplied_permissions) p) THEN RETURN 'invalid'; END IF;
    IF EXISTS (SELECT 1 FROM unnest(supplied_permissions) p WHERE
       NOT EXISTS (SELECT 1 FROM app.permissions WHERE permission_key=p) OR
       NOT EXISTS (SELECT 1 FROM app.authorization_grants(actor) g WHERE g.permission_key=p AND g.scope_kind='global')) THEN RETURN 'denied'; END IF;
    INSERT INTO app.roles (id,role_key,display_name,system_role) VALUES
        (target,'custom_'||substr(replace(target::text,'-',''),1,24),supplied_name,false);
    INSERT INTO app.role_permissions (id,role_id,permission_key) SELECT gen_random_uuid(),target,p FROM unnest(supplied_permissions) p;
    RETURN 'ok';
EXCEPTION WHEN unique_violation THEN RETURN 'conflict';
          WHEN check_violation THEN RETURN 'invalid';
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_replace_permissions(actor uuid, target uuid, expected_revision bigint, supplied_permissions text[])
RETURNS TABLE(outcome text, old_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
DECLARE record app.roles%ROWTYPE;
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF NOT app.authorization_allowed(actor,'roles.manage',NULL) THEN RETURN QUERY SELECT 'denied'::text,NULL::bigint; RETURN; END IF;
    SELECT * INTO record FROM app.roles WHERE id=target FOR UPDATE;
    IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::bigint; RETURN; END IF;
    IF record.system_role THEN RETURN QUERY SELECT 'system_role'::text,NULL::bigint; RETURN; END IF;
    IF expected_revision IS NULL OR expected_revision<1 OR record.revision <> expected_revision THEN RETURN QUERY SELECT 'conflict'::text,NULL::bigint; RETURN; END IF;
    IF supplied_permissions IS NULL OR cardinality(supplied_permissions) NOT BETWEEN 1 AND 100 OR
       cardinality(supplied_permissions) <> (SELECT count(DISTINCT p) FROM unnest(supplied_permissions) p) THEN
        RETURN QUERY SELECT 'invalid'::text,NULL::bigint; RETURN;
    END IF;
    IF EXISTS (SELECT 1 FROM (
        SELECT p AS key FROM unnest(supplied_permissions) p UNION
        SELECT rp.permission_key FROM app.role_permissions rp WHERE rp.role_id=target AND rp.revoked_at IS NULL
    ) affected WHERE NOT EXISTS (SELECT 1 FROM app.permissions WHERE permission_key=affected.key) OR
        NOT EXISTS (SELECT 1 FROM app.authorization_grants(actor) g WHERE g.permission_key=affected.key AND g.scope_kind='global')) THEN
        RETURN QUERY SELECT 'denied'::text,NULL::bigint; RETURN;
    END IF;
    INSERT INTO app.role_permissions (id,role_id,permission_key)
        SELECT gen_random_uuid(),target,p FROM unnest(supplied_permissions) p
        WHERE NOT EXISTS (SELECT 1 FROM app.role_permissions rp WHERE rp.role_id=target AND rp.permission_key=p AND rp.revoked_at IS NULL);
    UPDATE app.role_permissions SET revoked_at=clock_timestamp()
        WHERE role_id=target AND revoked_at IS NULL AND NOT (permission_key=ANY(supplied_permissions));
    UPDATE app.roles SET revision=revision+1,updated_at=clock_timestamp() WHERE id=target;
    RETURN QUERY SELECT 'ok'::text,record.revision;
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.admin_revoke_assignment(actor uuid, target uuid, assignment uuid, revoked_time timestamptz)
RETURNS TABLE(changed boolean, client_id uuid)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path = pg_catalog AS $$
BEGIN
    PERFORM pg_advisory_xact_lock(871092650209);
    IF NOT EXISTS (SELECT 1 FROM app.user_roles WHERE id=assignment AND user_id=target AND revoked_at IS NULL) THEN
        RETURN QUERY SELECT false,NULL::uuid; RETURN;
    END IF;
    RETURN QUERY SELECT * FROM app.revoke_role_assignment(actor,assignment,revoked_time);
END;
$$;
-- +goose StatementEnd

REVOKE ALL ON FUNCTION app.admin_survives(uuid,uuid,uuid),app.admin_guard_last(),
    app.admin_users(uuid,uuid,integer),app.admin_user(uuid,uuid),app.admin_roles(uuid,uuid,integer),app.admin_role(uuid,uuid),
    app.admin_catalog(uuid),app.admin_assignments(uuid,uuid,uuid,integer),
    app.admin_create_user(uuid,uuid,text,text,text),app.admin_update_user(uuid,uuid,bigint,text,text),
    app.admin_disable_user(uuid,uuid,bigint),app.admin_create_role(uuid,uuid,text,text[]),
    app.admin_replace_permissions(uuid,uuid,bigint,text[]),app.admin_revoke_assignment(uuid,uuid,uuid,timestamptz)
FROM PUBLIC;

-- Add only typed account status to snapshots; credential/profile strings stay forbidden.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.audit_snapshot_allowed(value jsonb) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE STRICT SET search_path = pg_catalog AS $$
BEGIN
    IF value='null'::jsonb THEN RETURN true; END IF;
    IF jsonb_typeof(value)<>'object' OR value-ARRAY['exists','revision','status']<>'{}'::jsonb THEN RETURN false; END IF;
    IF value ? 'exists' AND jsonb_typeof(value->'exists')<>'boolean' THEN RETURN false; END IF;
    IF value ? 'status' AND (jsonb_typeof(value->'status')<>'string' OR value->>'status' NOT IN ('active','disabled')) THEN RETURN false; END IF;
    IF value ? 'revision' THEN
        IF jsonb_typeof(value->'revision')<>'number' OR value->>'revision' !~ '^(0|[1-9][0-9]*)$' THEN RETURN false; END IF;
        IF (value->>'revision')::numeric > 9223372036854775807 THEN RETURN false; END IF;
    END IF;
    RETURN true;
END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
DO $$ DECLARE constraint_name text;
BEGIN
    FOR constraint_name IN SELECT conname FROM pg_constraint WHERE conrelid='app.audit_events'::regclass AND contype='c'
        AND pg_get_constraintdef(oid) LIKE '%event_name%' LOOP
        EXECUTE format('ALTER TABLE app.audit_events DROP CONSTRAINT %I',constraint_name);
    END LOOP;
END;
$$;
-- +goose StatementEnd
ALTER TABLE app.audit_events ADD CONSTRAINT audit_event_action CHECK (
    event_name IN (resource_kind||'.created',resource_kind||'.updated',resource_kind||'.archived',resource_kind||'.deleted') OR
    (resource_kind='user' AND event_name='user.disabled') OR (resource_kind='role' AND event_name='role.permission_changed'));


-- +goose Up
-- Scope IDs preserve pre-client grant history without inventing client profiles.
CREATE TABLE app.client_scopes (id uuid PRIMARY KEY CHECK (id<>'00000000-0000-0000-0000-000000000000'));
INSERT INTO app.client_scopes SELECT DISTINCT client_id FROM app.user_roles WHERE client_id IS NOT NULL;
ALTER TABLE app.user_roles ADD CONSTRAINT user_roles_client_scope FOREIGN KEY (client_id) REFERENCES app.client_scopes(id);
CREATE TABLE app.clients (
 id uuid PRIMARY KEY REFERENCES app.client_scopes(id),
 name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 200 AND name=btrim(name) AND name!~'[[:cntrl:]]'),
 legal_name text NOT NULL DEFAULT '' CHECK (char_length(legal_name)<=200 AND legal_name!~'[[:cntrl:]]'),
 website text NOT NULL DEFAULT '' CHECK (char_length(website)<=2048 AND website!~'[[:cntrl:]]'),
 notes text NOT NULL DEFAULT '' CHECK (char_length(notes)<=4000 AND notes!~'[[:cntrl:]]'),
 revision bigint NOT NULL DEFAULT 1 CHECK (revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 archived_at timestamptz,
 CHECK (updated_at>=created_at AND (archived_at IS NULL OR archived_at>=created_at))
);
CREATE INDEX clients_active_id ON app.clients(id) WHERE archived_at IS NULL;
CREATE INDEX clients_archived_id ON app.clients(id) WHERE archived_at IS NOT NULL;
CREATE TABLE app.client_contacts (
 client_id uuid NOT NULL REFERENCES app.clients(id),
 position integer NOT NULL CHECK (position BETWEEN 0 AND 19),
 name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 100 AND name!~'[[:cntrl:]]'),
 email text NOT NULL DEFAULT '' CHECK (char_length(email)<=254 AND email!~'[[:cntrl:]]'),
 phone text NOT NULL DEFAULT '' CHECK (char_length(phone)<=40 AND phone!~'[[:cntrl:]]'),
 PRIMARY KEY(client_id,position)
);
CREATE TABLE app.client_tags (
 client_id uuid NOT NULL REFERENCES app.clients(id),
 tag text NOT NULL CHECK (char_length(tag) BETWEEN 1 AND 40 AND tag=btrim(tag) AND tag=lower(tag) AND tag!~'[[:cntrl:]]'),
 PRIMARY KEY(client_id,tag)
);
CREATE INDEX client_tags_lookup ON app.client_tags(tag,client_id);

-- +goose StatementBegin
CREATE FUNCTION app.client_assignment_guard() RETURNS trigger
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.scope_kind<>'client' OR NEW.revoked_at IS NOT NULL THEN RETURN NEW; END IF;
 IF TG_OP='UPDATE' AND OLD.scope_kind=NEW.scope_kind AND OLD.client_id=NEW.client_id AND OLD.role_id=NEW.role_id AND OLD.user_id=NEW.user_id AND OLD.revoked_at IS NULL THEN RETURN NEW; END IF;
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT EXISTS (SELECT 1 FROM app.clients WHERE id=NEW.client_id AND archived_at IS NULL) THEN RAISE insufficient_privilege; END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
CREATE TRIGGER client_assignment_boundary BEFORE INSERT OR UPDATE ON app.user_roles FOR EACH ROW EXECUTE FUNCTION app.client_assignment_guard();
ALTER TABLE app.user_roles ENABLE ALWAYS TRIGGER client_assignment_boundary;

-- Trusted helper: no runtime EXECUTE; public profile values never enter audit.
-- +goose StatementBegin
CREATE FUNCTION app.client_document(target uuid,details boolean) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('id',c.id,'name',c.name,'legal_name',c.legal_name,
  'status',CASE WHEN c.archived_at IS NULL THEN 'active' ELSE 'archived' END,
  'revision',c.revision,'created_at',c.created_at,'updated_at',c.updated_at,'archived_at',c.archived_at,
  'tags',coalesce((SELECT jsonb_agg(t.tag ORDER BY t.tag) FROM app.client_tags t WHERE t.client_id=c.id),'[]'::jsonb))
  || CASE WHEN details THEN jsonb_build_object('website',c.website,'notes',c.notes,
   'contacts',coalesce((SELECT jsonb_agg(jsonb_build_object('name',p.name,'email',p.email,'phone',p.phone) ORDER BY p.position)
    FROM app.client_contacts p WHERE p.client_id=c.id),'[]'::jsonb)) ELSE '{}'::jsonb END
 FROM app.clients c WHERE c.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.client_read(actor uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'clients.view',target) THEN RETURN NULL; END IF;
 RETURN app.client_document(target,true);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.client_list(actor uuid,after_id uuid,page_limit integer,state text,search text,tag_filter text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM app.authorization_grants(actor) WHERE permission_key='clients.view') THEN RAISE insufficient_privilege; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR state IS NULL OR state NOT IN ('active','archived','all') OR
  search IS NULL OR char_length(search)>100 OR tag_filter IS NULL OR char_length(tag_filter)>40 OR descending IS NULL THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT app.client_document(c.id,false) FROM app.clients c
 WHERE app.authorization_allowed(actor,'clients.view',c.id)
  AND (state='all' OR (state='active' AND c.archived_at IS NULL) OR (state='archived' AND c.archived_at IS NOT NULL))
  AND (search='' OR strpos(lower(c.name),lower(search))>0)
  AND (tag_filter='' OR EXISTS (SELECT 1 FROM app.client_tags t WHERE t.client_id=c.id AND t.tag=tag_filter))
  AND (after_id IS NULL OR (NOT descending AND c.id>after_id) OR (descending AND c.id<after_id))
 ORDER BY CASE WHEN NOT descending THEN c.id END ASC,CASE WHEN descending THEN c.id END DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.client_write(actor uuid,target uuid,expected bigint,profile jsonb,archive boolean)
RETURNS text LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE record app.clients%ROWTYPE; permission text;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF expected=0 AND NOT archive THEN
  IF NOT app.authorization_allowed(actor,'clients.create',NULL) THEN RETURN 'denied'; END IF;
 ELSE
  permission:=CASE WHEN archive THEN 'clients.archive' ELSE 'clients.update' END;
  IF NOT app.authorization_allowed(actor,permission,target) THEN RETURN 'missing'; END IF;
  SELECT * INTO record FROM app.clients WHERE id=target FOR UPDATE;
  IF NOT FOUND THEN RETURN 'missing'; END IF;
  IF expected IS NULL OR expected<1 OR record.revision<>expected OR record.archived_at IS NOT NULL THEN RETURN 'conflict'; END IF;
 END IF;
 IF target IS NULL OR target='00000000-0000-0000-0000-000000000000' OR archive IS NULL OR expected IS NULL OR expected<0 THEN RETURN 'invalid'; END IF;
 IF archive THEN
  UPDATE app.clients SET archived_at=clock_timestamp(),updated_at=clock_timestamp(),revision=revision+1 WHERE id=target;
  RETURN 'ok';
 END IF;
 IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR
  profile-ARRAY['name','legal_name','website','notes','contacts','tags']<>'{}'::jsonb OR
  jsonb_typeof(profile->'name') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'legal_name') IS DISTINCT FROM 'string' OR
  jsonb_typeof(profile->'website') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'notes') IS DISTINCT FROM 'string' OR
  jsonb_typeof(profile->'contacts') IS DISTINCT FROM 'array' OR jsonb_typeof(profile->'tags') IS DISTINCT FROM 'array' THEN RETURN 'invalid'; END IF;
 IF jsonb_array_length(profile->'contacts')>20 OR jsonb_array_length(profile->'tags')>20 THEN RETURN 'invalid'; END IF;
 IF EXISTS (SELECT 1 FROM jsonb_array_elements(profile->'contacts') p WHERE jsonb_typeof(p)<>'object' OR
  p-ARRAY['name','email','phone']<>'{}'::jsonb OR jsonb_typeof(p->'name') IS DISTINCT FROM 'string' OR
  jsonb_typeof(p->'email') IS DISTINCT FROM 'string' OR jsonb_typeof(p->'phone') IS DISTINCT FROM 'string') OR
  EXISTS (SELECT 1 FROM jsonb_array_elements(profile->'tags') p WHERE jsonb_typeof(p)<>'string') THEN RETURN 'invalid'; END IF;
 IF expected=0 THEN
  INSERT INTO app.client_scopes(id) VALUES(target);
  INSERT INTO app.clients(id,name,legal_name,website,notes) VALUES(target,profile->>'name',profile->>'legal_name',profile->>'website',profile->>'notes');
 ELSE
  UPDATE app.clients SET name=profile->>'name',legal_name=profile->>'legal_name',website=profile->>'website',notes=profile->>'notes',revision=revision+1,updated_at=clock_timestamp() WHERE id=target;
  DELETE FROM app.client_contacts WHERE client_id=target;
  DELETE FROM app.client_tags WHERE client_id=target;
 END IF;
 INSERT INTO app.client_contacts(client_id,position,name,email,phone)
 SELECT target,(ordinality-1)::integer,p->>'name',p->>'email',p->>'phone' FROM jsonb_array_elements(profile->'contacts') WITH ORDINALITY AS input(p,ordinality);
 INSERT INTO app.client_tags(client_id,tag) SELECT target,p#>>'{}' FROM jsonb_array_elements(profile->'tags') p;
 RETURN 'ok';
EXCEPTION WHEN check_violation OR not_null_violation OR invalid_text_representation THEN RETURN 'invalid';
 WHEN unique_violation THEN RETURN 'conflict';
END; $$;
-- +goose StatementEnd
REVOKE ALL ON app.client_scopes,app.clients,app.client_contacts,app.client_tags FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.client_assignment_guard(),app.client_document(uuid,boolean),app.client_read(uuid,uuid),
 app.client_list(uuid,uuid,integer,text,text,text,boolean),app.client_write(uuid,uuid,bigint,jsonb,boolean) FROM PUBLIC;


-- +goose Up
INSERT INTO app.permissions(permission_key,scope_kind,description) VALUES
 ('tasks.create','client','Create client tasks'),
 ('tasks.update','client','Update client tasks and status'),
 ('tasks.delete','client','Archive client tasks while preserving history');
INSERT INTO app.role_permissions(id,role_id,permission_key,seeded)
 SELECT gen_random_uuid(),'00000000-0000-4000-8000-000000000001'::uuid,permission_key,true
 FROM app.permissions WHERE permission_key IN ('tasks.create','tasks.update','tasks.delete');

CREATE TABLE app.tasks (
 id uuid PRIMARY KEY CHECK (id<>'00000000-0000-0000-0000-000000000000'),
 client_id uuid NOT NULL REFERENCES app.clients(id),
 created_by uuid NOT NULL REFERENCES app.users(id),
 assignee_id uuid REFERENCES app.users(id),
 title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200 AND title=btrim(title) AND title!~'[[:cntrl:]]'),
 description text NOT NULL DEFAULT '' CHECK (char_length(description)<=8000 AND replace(description,E'\n','')!~'[[:cntrl:]]'),
 status text NOT NULL CHECK (status IN ('backlog','todo','in_progress','blocked','review','done','cancelled')),
 priority text NOT NULL CHECK (priority IN ('low','medium','high','urgent')),
 start_at timestamptz,
 due_at timestamptz,
 completed_at timestamptz,
 cancelled_at timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK (revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 archived_at timestamptz,
 CHECK (start_at IS NULL OR due_at IS NULL OR due_at>=start_at),
 CHECK (start_at IS NULL OR (isfinite(start_at) AND start_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND start_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')),
 CHECK (due_at IS NULL OR (isfinite(due_at) AND due_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND due_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')),
 CHECK ((status='done')=(completed_at IS NOT NULL)),
 CHECK ((status='cancelled')=(cancelled_at IS NOT NULL)),
 CHECK (updated_at>=created_at AND (archived_at IS NULL OR archived_at>=created_at)
  AND (completed_at IS NULL OR completed_at>=created_at) AND (cancelled_at IS NULL OR cancelled_at>=created_at))
);
CREATE INDEX tasks_active_client_id ON app.tasks(client_id,id) WHERE archived_at IS NULL;
CREATE INDEX tasks_archived_client_id ON app.tasks(client_id,id) WHERE archived_at IS NOT NULL;
CREATE INDEX tasks_client_status_id ON app.tasks(client_id,status,id);
CREATE INDEX tasks_client_assignee_id ON app.tasks(client_id,assignee_id,id);
CREATE TABLE app.task_tags (
 task_id uuid NOT NULL REFERENCES app.tasks(id),
 tag text NOT NULL CHECK (char_length(tag) BETWEEN 1 AND 40 AND tag=btrim(tag) AND tag=lower(tag) AND tag!~'[[:cntrl:]]'),
 PRIMARY KEY(task_id,tag)
);
CREATE INDEX task_tags_lookup ON app.task_tags(tag,task_id);

-- Private helpers are never granted to runtime.
-- +goose StatementBegin
CREATE FUNCTION app.task_allowed(actor uuid,permission text,client uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT app.authorization_allowed(actor,permission,client) OR
  (permission IN ('tasks.create','tasks.update','tasks.delete') AND app.authorization_allowed(actor,'tasks.manage',client));
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.task_transition(previous text,next text) RETURNS boolean
LANGUAGE sql IMMUTABLE SET search_path=pg_catalog AS $$
 SELECT CASE previous
 WHEN 'backlog' THEN next IN ('todo','cancelled')
 WHEN 'todo' THEN next IN ('backlog','in_progress','blocked','cancelled')
 WHEN 'in_progress' THEN next IN ('todo','blocked','review','done','cancelled')
 WHEN 'blocked' THEN next IN ('todo','in_progress','cancelled')
 WHEN 'review' THEN next IN ('in_progress','blocked','done','cancelled')
 WHEN 'done' THEN next='in_progress'
 WHEN 'cancelled' THEN next IN ('backlog','todo') ELSE false END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.task_document(target uuid,details boolean) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('id',t.id,'client_id',t.client_id,'created_by',t.created_by,'assignee_id',t.assignee_id,
 'title',t.title,'status',t.status,'priority',t.priority,'start_at',t.start_at,'due_at',t.due_at,
 'completed_at',t.completed_at,'cancelled_at',t.cancelled_at,'revision',t.revision,
 'created_at',t.created_at,'updated_at',t.updated_at,'archived_at',t.archived_at,
 'tags',coalesce((SELECT jsonb_agg(g.tag ORDER BY g.tag) FROM app.task_tags g WHERE g.task_id=t.id),'[]'::jsonb))
 || CASE WHEN details THEN jsonb_build_object('description',t.description) ELSE '{}'::jsonb END
 FROM app.tasks t WHERE t.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.task_read(actor uuid,client uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'tasks.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RETURN NULL; END IF;
 IF NOT EXISTS(SELECT 1 FROM app.tasks WHERE id=target AND client_id=client) THEN RETURN NULL; END IF;
 RETURN app.task_document(target,true);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.task_list(actor uuid,client uuid,after_id uuid,page_limit integer,state text,importance text,
 assigned uuid,unassigned boolean,search text,tag_filter text,archive_filter text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'tasks.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR state IS NULL OR state NOT IN ('all','backlog','todo','in_progress','blocked','review','done','cancelled') OR
 importance IS NULL OR importance NOT IN ('all','low','medium','high','urgent') OR unassigned IS NULL OR (unassigned AND assigned IS NOT NULL) OR
 search IS NULL OR char_length(search)>100 OR tag_filter IS NULL OR char_length(tag_filter)>40 OR
 archive_filter IS NULL OR archive_filter NOT IN ('false','true','all') OR descending IS NULL THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT app.task_document(t.id,false) FROM app.tasks t WHERE t.client_id=client
 AND (state='all' OR t.status=state) AND (importance='all' OR t.priority=importance)
 AND (assigned IS NULL OR t.assignee_id=assigned) AND (NOT unassigned OR t.assignee_id IS NULL)
 AND (search='' OR strpos(lower(t.title),lower(search))>0)
 AND (tag_filter='' OR EXISTS(SELECT 1 FROM app.task_tags g WHERE g.task_id=t.id AND g.tag=tag_filter))
 AND (archive_filter='all' OR (archive_filter='false' AND t.archived_at IS NULL) OR (archive_filter='true' AND t.archived_at IS NOT NULL))
 AND (after_id IS NULL OR (NOT descending AND t.id>after_id) OR (descending AND t.id<after_id))
 ORDER BY CASE WHEN NOT descending THEN t.id END ASC,CASE WHEN descending THEN t.id END DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.task_assignees(actor uuid,client uuid,after_id uuid,page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'tasks.view',client) OR
 NOT (app.task_allowed(actor,'tasks.create',client) OR app.task_allowed(actor,'tasks.update',client)) OR
 NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) THEN RAISE SQLSTATE 'P0001' USING MESSAGE='archived client'; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',u.id,'display_name',u.display_name) FROM app.users u
 WHERE u.status='active' AND app.authorization_allowed(u.id,'tasks.view',client)
 AND (after_id IS NULL OR u.id>after_id) ORDER BY u.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd

-- Permission and assignee reads must happen AFTER waiting on the shared lock.
-- +goose StatementBegin
CREATE FUNCTION app.task_write(actor uuid,client uuid,target uuid,expected bigint,operation text,profile jsonb,next_state text)
RETURNS TABLE(code text,before_status text,after_status text)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE record app.tasks%ROWTYPE; permission text; assigned uuid; starts timestamptz; due timestamptz; stamp timestamptz;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF operation IS NULL OR operation NOT IN ('create','update','status','archive') OR target IS NULL OR target='00000000-0000-0000-0000-000000000000' THEN
  RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text; RETURN;
 END IF;
 permission:=CASE operation WHEN 'create' THEN 'tasks.create' WHEN 'archive' THEN 'tasks.delete' ELSE 'tasks.update' END;
 IF NOT app.task_allowed(actor,permission,client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN
  RETURN QUERY SELECT 'missing'::text,NULL::text,NULL::text; RETURN;
 END IF;
 IF operation<>'create' THEN
  SELECT * INTO record FROM app.tasks WHERE id=target AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::text,NULL::text; RETURN; END IF;
 END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) OR
 (operation='create' AND expected IS DISTINCT FROM 0::bigint) OR
 (operation<>'create' AND (expected IS NULL OR expected<1 OR expected<>record.revision OR record.archived_at IS NOT NULL)) THEN
  RETURN QUERY SELECT 'conflict'::text,NULL::text,NULL::text; RETURN;
 END IF;
 stamp:=clock_timestamp();
 IF operation='archive' THEN
  UPDATE app.tasks SET archived_at=stamp,updated_at=stamp,revision=revision+1 WHERE id=target;
  RETURN QUERY SELECT 'ok'::text,record.status,record.status; RETURN;
 ELSIF operation='status' THEN
  IF NOT coalesce(app.task_transition(record.status,next_state),false) THEN RETURN QUERY SELECT 'invalid_transition'::text,NULL::text,NULL::text; RETURN; END IF;
  UPDATE app.tasks SET status=next_state,completed_at=CASE WHEN next_state='done' THEN stamp END,
   cancelled_at=CASE WHEN next_state='cancelled' THEN stamp END,updated_at=stamp,revision=revision+1 WHERE id=target;
  RETURN QUERY SELECT 'ok'::text,record.status,next_state; RETURN;
 END IF;
 IF operation='update' AND record.status IN ('done','cancelled') THEN RETURN QUERY SELECT 'conflict'::text,NULL::text,NULL::text; RETURN; END IF;
 IF operation='create' AND (next_state IS NULL OR next_state NOT IN ('backlog','todo')) THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text; RETURN; END IF;
 IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR profile-ARRAY['title','description','priority','assignee_id','start_at','due_at','tags']<>'{}'::jsonb OR
 jsonb_typeof(profile->'title') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'description') IS DISTINCT FROM 'string' OR
 jsonb_typeof(profile->'priority') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'tags') IS DISTINCT FROM 'array' OR
 NOT coalesce(jsonb_typeof(profile->'assignee_id') IN ('null','string'),false) OR
 NOT coalesce(jsonb_typeof(profile->'start_at') IN ('null','string'),false) OR NOT coalesce(jsonb_typeof(profile->'due_at') IN ('null','string'),false) THEN
  RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text; RETURN;
 END IF;
 IF jsonb_array_length(profile->'tags')>20 OR EXISTS(SELECT 1 FROM jsonb_array_elements(profile->'tags') p WHERE jsonb_typeof(p)<>'string') THEN
  RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text; RETURN;
 END IF;
 assigned:=(profile->>'assignee_id')::uuid; starts:=(profile->>'start_at')::timestamptz; due:=(profile->>'due_at')::timestamptz;
 IF assigned IS NOT NULL AND (operation='create' OR assigned IS DISTINCT FROM record.assignee_id) AND NOT app.authorization_allowed(assigned,'tasks.view',client) THEN
  RETURN QUERY SELECT 'invalid_assignee'::text,NULL::text,NULL::text; RETURN;
 END IF;
 IF operation='create' THEN
  INSERT INTO app.tasks(id,client_id,created_by,assignee_id,title,description,status,priority,start_at,due_at)
  VALUES(target,client,actor,assigned,profile->>'title',profile->>'description',next_state,profile->>'priority',starts,due);
 ELSE
  UPDATE app.tasks SET title=profile->>'title',description=profile->>'description',priority=profile->>'priority',assignee_id=assigned,
  start_at=starts,due_at=due,revision=revision+1,updated_at=stamp WHERE id=target;
  DELETE FROM app.task_tags WHERE task_id=target;
 END IF;
 INSERT INTO app.task_tags(task_id,tag) SELECT target,p#>>'{}' FROM jsonb_array_elements(profile->'tags') p;
 RETURN QUERY SELECT 'ok'::text,record.status,CASE WHEN operation='create' THEN next_state ELSE record.status END;
EXCEPTION WHEN check_violation OR not_null_violation OR invalid_text_representation OR datetime_field_overflow OR invalid_datetime_format OR foreign_key_violation THEN
 RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;
 WHEN unique_violation THEN RETURN QUERY SELECT 'conflict'::text,NULL::text,NULL::text;
END; $$;
-- +goose StatementEnd

-- Add only reviewed task state markers to the existing audit allowlist.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.audit_snapshot_allowed(value jsonb) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE STRICT SET search_path=pg_catalog AS $$
BEGIN
 IF value='null'::jsonb THEN RETURN true; END IF;
 IF jsonb_typeof(value)<>'object' OR value-ARRAY['exists','revision','status','task_status']<>'{}'::jsonb THEN RETURN false; END IF;
 IF value ? 'exists' AND jsonb_typeof(value->'exists')<>'boolean' THEN RETURN false; END IF;
 IF value ? 'status' AND (jsonb_typeof(value->'status')<>'string' OR value->>'status' NOT IN ('active','disabled')) THEN RETURN false; END IF;
 IF value ? 'task_status' AND (jsonb_typeof(value->'task_status')<>'string' OR value->>'task_status' NOT IN ('backlog','todo','in_progress','blocked','review','done','cancelled')) THEN RETURN false; END IF;
 IF value ? 'revision' THEN
  IF jsonb_typeof(value->'revision')<>'number' OR value->>'revision' !~ '^(0|[1-9][0-9]*)$' THEN RETURN false; END IF;
  IF (value->>'revision')::numeric>9223372036854775807 THEN RETURN false; END IF;
 END IF;
 RETURN true;
END; $$;
-- +goose StatementEnd
ALTER TABLE app.audit_events DROP CONSTRAINT audit_event_action;
ALTER TABLE app.audit_events ADD CONSTRAINT audit_event_action CHECK (
 event_name IN (resource_kind||'.created',resource_kind||'.updated',resource_kind||'.archived',resource_kind||'.deleted') OR
 (resource_kind='user' AND event_name='user.disabled') OR (resource_kind='role' AND event_name='role.permission_changed') OR
 (resource_kind='task' AND event_name IN ('task.completed','task.cancelled')));
ALTER TABLE app.audit_events ADD CONSTRAINT audit_task_snapshot_kind CHECK (
 resource_kind='task' OR NOT (before_state ? 'task_status' OR after_state ? 'task_status'));
REVOKE ALL ON app.tasks,app.task_tags FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.task_allowed(uuid,text,uuid),app.task_transition(text,text),app.task_document(uuid,boolean),
 app.task_read(uuid,uuid,uuid),app.task_list(uuid,uuid,uuid,integer,text,text,uuid,boolean,text,text,text,boolean),
 app.task_assignees(uuid,uuid,uuid,integer),app.task_write(uuid,uuid,uuid,bigint,text,jsonb,text) FROM PUBLIC;


-- +goose Up
INSERT INTO app.permissions(permission_key,scope_kind,description) VALUES
 ('planning.view','client','View client plans and milestones'),
 ('planning.create','client','Create client plans and milestones'),
 ('planning.update','client','Update client plans, milestones and task links'),
 ('planning.archive','client','Archive planning records while preserving history');
INSERT INTO app.role_permissions(id,role_id,permission_key,seeded)
 SELECT gen_random_uuid(),'00000000-0000-4000-8000-000000000001'::uuid,permission_key,true
 FROM app.permissions WHERE permission_key IN ('planning.view','planning.create','planning.update','planning.archive');

CREATE TABLE app.plans (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 client_id uuid NOT NULL REFERENCES app.clients(id),
 created_by uuid NOT NULL REFERENCES app.users(id),
 title text NOT NULL CHECK(char_length(title) BETWEEN 1 AND 200 AND title=btrim(title) AND title!~'[[:cntrl:]]'),
 description text NOT NULL DEFAULT '' CHECK(char_length(description)<=8000 AND replace(description,E'\n','')!~'[[:cntrl:]]'),
 status text NOT NULL CHECK(status IN ('draft','active','completed','cancelled')),
 start_at timestamptz,
 due_at timestamptz,
 completed_at timestamptz,
 cancelled_at timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 archived_at timestamptz,
 UNIQUE(id,client_id),
 CHECK(start_at IS NULL OR (isfinite(start_at) AND start_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND start_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')),
 CHECK(due_at IS NULL OR (isfinite(due_at) AND due_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND due_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')),
 CHECK(start_at IS NULL OR due_at IS NULL OR due_at>=start_at),
 CHECK((status='completed')=(completed_at IS NOT NULL)),
 CHECK((status='cancelled')=(cancelled_at IS NOT NULL)),
 CHECK(updated_at>=created_at AND (archived_at IS NULL OR archived_at>=created_at)
  AND (completed_at IS NULL OR completed_at>=created_at) AND (cancelled_at IS NULL OR cancelled_at>=created_at))
);
CREATE INDEX plans_client_id ON app.plans(client_id,id);
CREATE INDEX plans_client_status_id ON app.plans(client_id,status,id);
CREATE TABLE app.milestones (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 plan_id uuid NOT NULL,
 client_id uuid NOT NULL,
 created_by uuid NOT NULL REFERENCES app.users(id),
 title text NOT NULL CHECK(char_length(title) BETWEEN 1 AND 200 AND title=btrim(title) AND title!~'[[:cntrl:]]'),
 description text NOT NULL DEFAULT '' CHECK(char_length(description)<=8000 AND replace(description,E'\n','')!~'[[:cntrl:]]'),
 status text NOT NULL CHECK(status IN ('planned','in_progress','completed','cancelled')),
 due_at timestamptz,
 completed_at timestamptz,
 cancelled_at timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 archived_at timestamptz,
 UNIQUE(id,plan_id,client_id),
 FOREIGN KEY(plan_id,client_id) REFERENCES app.plans(id,client_id),
 CHECK(due_at IS NULL OR (isfinite(due_at) AND due_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND due_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')),
 CHECK((status='completed')=(completed_at IS NOT NULL)),
 CHECK((status='cancelled')=(cancelled_at IS NOT NULL)),
 CHECK(updated_at>=created_at AND (archived_at IS NULL OR archived_at>=created_at)
  AND (completed_at IS NULL OR completed_at>=created_at) AND (cancelled_at IS NULL OR cancelled_at>=created_at))
);
CREATE INDEX milestones_plan_id ON app.milestones(plan_id,client_id,id);
CREATE INDEX milestones_plan_due ON app.milestones(plan_id,due_at) WHERE archived_at IS NULL;
ALTER TABLE app.tasks ADD CONSTRAINT tasks_id_client_unique UNIQUE(id,client_id);
CREATE TABLE app.milestone_task_links (
 id uuid PRIMARY KEY,
 milestone_id uuid NOT NULL,
 plan_id uuid NOT NULL,
 client_id uuid NOT NULL,
 task_id uuid NOT NULL,
 linked_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 unlinked_at timestamptz CHECK(unlinked_at IS NULL OR unlinked_at>=linked_at),
 FOREIGN KEY(milestone_id,plan_id,client_id) REFERENCES app.milestones(id,plan_id,client_id),
 FOREIGN KEY(task_id,client_id) REFERENCES app.tasks(id,client_id)
);
CREATE UNIQUE INDEX milestone_links_active ON app.milestone_task_links(milestone_id,task_id) WHERE unlinked_at IS NULL;
CREATE INDEX milestone_links_page ON app.milestone_task_links(milestone_id,id);
CREATE INDEX milestone_links_task ON app.milestone_task_links(task_id,client_id);

-- Private helpers are not part of the runtime boundary.
-- +goose StatementBegin
CREATE FUNCTION app.planning_transition(previous text,next text,milestone boolean) RETURNS boolean
LANGUAGE sql IMMUTABLE SET search_path=pg_catalog AS $$
 SELECT CASE WHEN milestone THEN CASE previous
 WHEN 'planned' THEN next IN ('in_progress','completed','cancelled')
 WHEN 'in_progress' THEN next IN ('planned','completed','cancelled')
 WHEN 'completed' THEN next='in_progress'
 WHEN 'cancelled' THEN next IN ('planned','in_progress') ELSE false END
 ELSE CASE previous WHEN 'draft' THEN next IN ('active','cancelled')
 WHEN 'active' THEN next IN ('draft','completed','cancelled')
 WHEN 'completed' THEN next='active' WHEN 'cancelled' THEN next IN ('draft','active') ELSE false END END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.planning_document(parent uuid,target uuid,details boolean) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE result jsonb;
BEGIN
 IF parent IS NULL THEN SELECT to_jsonb(p) INTO result FROM app.plans p WHERE p.id=target;
 ELSE SELECT to_jsonb(m)||jsonb_build_object('start_at',NULL) INTO result FROM app.milestones m WHERE m.id=target AND m.plan_id=parent;
  IF details THEN result:=result||jsonb_build_object('task_ids',coalesce((SELECT jsonb_agg(l.task_id ORDER BY l.task_id)
   FROM app.milestone_task_links l WHERE l.milestone_id=target AND l.unlinked_at IS NULL),'[]'::jsonb)); END IF;
 END IF;
 RETURN CASE WHEN details THEN result ELSE result-'description' END;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.planning_read(actor uuid,client uuid,parent uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'planning.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RETURN NULL; END IF;
 IF parent IS NULL THEN IF NOT EXISTS(SELECT 1 FROM app.plans WHERE id=target AND client_id=client) THEN RETURN NULL; END IF;
 ELSE IF NOT EXISTS(SELECT 1 FROM app.milestones WHERE id=target AND client_id=client AND plan_id=parent) THEN RETURN NULL; END IF;
 END IF;
 RETURN app.planning_document(parent,target,true);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.planning_list(actor uuid,client uuid,parent uuid,after_id uuid,page_limit integer,state text,search text,archive_filter text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'planning.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) OR
 (parent IS NOT NULL AND NOT EXISTS(SELECT 1 FROM app.plans WHERE id=parent AND client_id=client)) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR search IS NULL OR char_length(search)>100 OR search~'[[:cntrl:]]' OR
 archive_filter IS NULL OR archive_filter NOT IN ('false','true','all') OR descending IS NULL OR state IS NULL OR
 (parent IS NULL AND state NOT IN ('all','draft','active','completed','cancelled')) OR
 (parent IS NOT NULL AND state NOT IN ('all','planned','in_progress','completed','cancelled')) THEN RAISE invalid_parameter_value; END IF;
 IF parent IS NULL THEN
  RETURN QUERY SELECT app.planning_document(NULL,p.id,false) FROM app.plans p WHERE p.client_id=client
  AND (state='all' OR p.status=state) AND (search='' OR strpos(lower(p.title),lower(search))>0)
  AND (archive_filter='all' OR (archive_filter='false' AND p.archived_at IS NULL) OR (archive_filter='true' AND p.archived_at IS NOT NULL))
  AND (after_id IS NULL OR (NOT descending AND p.id>after_id) OR (descending AND p.id<after_id))
  ORDER BY CASE WHEN NOT descending THEN p.id END ASC,CASE WHEN descending THEN p.id END DESC LIMIT page_limit;
 ELSE
  RETURN QUERY SELECT app.planning_document(parent,m.id,false) FROM app.milestones m WHERE m.plan_id=parent AND m.client_id=client
  AND (state='all' OR m.status=state) AND (search='' OR strpos(lower(m.title),lower(search))>0)
  AND (archive_filter='all' OR (archive_filter='false' AND m.archived_at IS NULL) OR (archive_filter='true' AND m.archived_at IS NOT NULL))
  AND (after_id IS NULL OR (NOT descending AND m.id>after_id) OR (descending AND m.id<after_id))
  ORDER BY CASE WHEN NOT descending THEN m.id END ASC,CASE WHEN descending THEN m.id END DESC LIMIT page_limit;
 END IF;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.planning_links(actor uuid,client uuid,parent uuid,target uuid,after_id uuid,page_limit integer,archive_filter text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF parent IS NULL OR app.planning_read(actor,client,parent,target) IS NULL THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR archive_filter IS NULL OR archive_filter NOT IN ('false','true','all') OR descending IS NULL THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',l.id,'task_id',l.task_id,'linked_at',l.linked_at,'unlinked_at',l.unlinked_at)
 FROM app.milestone_task_links l WHERE l.milestone_id=target AND l.plan_id=parent AND l.client_id=client
 AND (archive_filter='all' OR (archive_filter='false' AND l.unlinked_at IS NULL) OR (archive_filter='true' AND l.unlinked_at IS NOT NULL))
 AND (after_id IS NULL OR (NOT descending AND l.id>after_id) OR (descending AND l.id<after_id))
 ORDER BY CASE WHEN NOT descending THEN l.id END ASC,CASE WHEN descending THEN l.id END DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.planning_task_candidates(actor uuid,client uuid,parent uuid,after_id uuid,page_limit integer,search text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'planning.view',client) OR NOT app.authorization_allowed(actor,'tasks.view',client) OR
 NOT (app.authorization_allowed(actor,'planning.create',client) OR app.authorization_allowed(actor,'planning.update',client)) OR
 NOT EXISTS(SELECT 1 FROM app.plans WHERE id=parent AND client_id=client) THEN RAISE no_data_found; END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) OR
 EXISTS(SELECT 1 FROM app.plans WHERE id=parent AND (archived_at IS NOT NULL OR status IN ('completed','cancelled'))) THEN RAISE SQLSTATE 'P0001'; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR search IS NULL OR char_length(search)>100 OR search~'[[:cntrl:]]' OR descending IS NULL THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',t.id,'title',t.title,'status',t.status) FROM app.tasks t WHERE t.client_id=client AND t.archived_at IS NULL
 AND (search='' OR strpos(lower(t.title),lower(search))>0) AND (after_id IS NULL OR (NOT descending AND t.id>after_id) OR (descending AND t.id<after_id))
 ORDER BY CASE WHEN NOT descending THEN t.id END ASC,CASE WHEN descending THEN t.id END DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd

-- All authorization, parent and task checks run after the shared writer lock.
-- +goose StatementBegin
CREATE FUNCTION app.planning_write(actor uuid,client uuid,parent uuid,target uuid,expected bigint,operation text,profile jsonb,next_state text,task_ids jsonb)
RETURNS TABLE(result text,previous_status text,current_status text)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE permission text;plan app.plans%ROWTYPE;milestone app.milestones%ROWTYPE;old_state text;old_revision bigint;old_archive timestamptz;
 stamp timestamptz;starts timestamptz;due timestamptz;selected uuid[];initial text;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF operation IS NULL OR operation NOT IN ('create','update','status','archive','links') OR target IS NULL OR
 target='00000000-0000-0000-0000-000000000000' OR (operation='links' AND parent IS NULL) THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
 permission:=CASE operation WHEN 'create' THEN 'planning.create' WHEN 'archive' THEN 'planning.archive' ELSE 'planning.update' END;
 IF NOT app.authorization_allowed(actor,'planning.view',client) OR NOT app.authorization_allowed(actor,permission,client) OR
 NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RETURN QUERY SELECT 'missing'::text,NULL::text,NULL::text;RETURN; END IF;
 IF parent IS NOT NULL THEN
  SELECT * INTO plan FROM app.plans WHERE id=parent AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::text,NULL::text;RETURN; END IF;
  IF operation<>'create' THEN
   SELECT * INTO milestone FROM app.milestones WHERE id=target AND plan_id=parent AND client_id=client FOR UPDATE;
   IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::text,NULL::text;RETURN; END IF;
   old_state:=milestone.status;old_revision:=milestone.revision;old_archive:=milestone.archived_at;
  END IF;
 ELSIF operation<>'create' THEN
  SELECT * INTO plan FROM app.plans WHERE id=target AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::text,NULL::text;RETURN; END IF;
  old_state:=plan.status;old_revision:=plan.revision;old_archive:=plan.archived_at;
 END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) OR
 (parent IS NOT NULL AND (plan.archived_at IS NOT NULL OR plan.status IN ('completed','cancelled'))) OR
 (operation='create' AND expected IS DISTINCT FROM 0::bigint) OR
 (operation<>'create' AND (expected IS NULL OR expected<1 OR expected=9223372036854775807 OR expected<>old_revision OR old_archive IS NOT NULL)) THEN
 RETURN QUERY SELECT 'conflict'::text,NULL::text,NULL::text;RETURN; END IF;
 stamp:=clock_timestamp();
 IF operation='archive' THEN
  IF parent IS NULL THEN UPDATE app.plans SET archived_at=stamp,updated_at=stamp,revision=revision+1 WHERE id=target;
  ELSE UPDATE app.milestones SET archived_at=stamp,updated_at=stamp,revision=revision+1 WHERE id=target; END IF;
  RETURN QUERY SELECT 'ok'::text,old_state,old_state;RETURN;
 ELSIF operation='status' THEN
  IF NOT coalesce(app.planning_transition(old_state,next_state,parent IS NOT NULL),false) THEN RETURN QUERY SELECT 'invalid_transition'::text,NULL::text,NULL::text;RETURN; END IF;
  IF parent IS NULL THEN UPDATE app.plans SET status=next_state,completed_at=CASE WHEN next_state='completed' THEN stamp END,
   cancelled_at=CASE WHEN next_state='cancelled' THEN stamp END,updated_at=stamp,revision=revision+1 WHERE id=target;
  ELSE UPDATE app.milestones SET status=next_state,completed_at=CASE WHEN next_state='completed' THEN stamp END,
   cancelled_at=CASE WHEN next_state='cancelled' THEN stamp END,updated_at=stamp,revision=revision+1 WHERE id=target; END IF;
  RETURN QUERY SELECT 'ok'::text,old_state,next_state;RETURN;
 END IF;
 IF operation<>'create' AND old_state IN ('completed','cancelled') THEN RETURN QUERY SELECT 'conflict'::text,NULL::text,NULL::text;RETURN; END IF;
 IF operation='links' THEN
  IF task_ids IS NULL OR jsonb_typeof(task_ids)<>'array' THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
  IF jsonb_array_length(task_ids)>50 OR EXISTS(SELECT 1 FROM jsonb_array_elements(task_ids) v WHERE jsonb_typeof(v)<>'string') THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
  SELECT coalesce(array_agg(v::uuid),ARRAY[]::uuid[]) INTO selected FROM jsonb_array_elements_text(task_ids) v;
  IF cardinality(selected)<>(SELECT count(DISTINCT v) FROM unnest(selected) v) OR '00000000-0000-0000-0000-000000000000'::uuid=ANY(selected) THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
  IF EXISTS(SELECT 1 FROM unnest(selected) v WHERE NOT EXISTS(SELECT 1 FROM app.milestone_task_links l WHERE l.milestone_id=target AND l.task_id=v AND l.unlinked_at IS NULL)
   AND (NOT app.authorization_allowed(actor,'tasks.view',client) OR NOT EXISTS(SELECT 1 FROM app.tasks t WHERE t.id=v AND t.client_id=client AND t.archived_at IS NULL))) THEN
   RETURN QUERY SELECT 'invalid_link'::text,NULL::text,NULL::text;RETURN; END IF;
  UPDATE app.milestone_task_links SET unlinked_at=stamp WHERE milestone_id=target AND unlinked_at IS NULL AND NOT (task_id=ANY(selected));
  INSERT INTO app.milestone_task_links(id,milestone_id,plan_id,client_id,task_id,linked_at)
   SELECT gen_random_uuid(),target,parent,client,v,stamp FROM unnest(selected) v
   WHERE NOT EXISTS(SELECT 1 FROM app.milestone_task_links l WHERE l.milestone_id=target AND l.task_id=v AND l.unlinked_at IS NULL);
  UPDATE app.milestones SET revision=revision+1,updated_at=stamp WHERE id=target;
  RETURN QUERY SELECT 'ok'::text,old_state,old_state;RETURN;
 END IF;
 IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR profile-ARRAY['title','description','start_at','due_at']<>'{}'::jsonb OR
 jsonb_typeof(profile->'title') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'description') IS DISTINCT FROM 'string' OR
 NOT coalesce(jsonb_typeof(profile->'start_at') IN ('null','string'),false) OR NOT coalesce(jsonb_typeof(profile->'due_at') IN ('null','string'),false) THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
 starts:=(profile->>'start_at')::timestamptz;due:=(profile->>'due_at')::timestamptz;
 IF (starts IS NOT NULL AND (NOT isfinite(starts) OR starts<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR starts>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (due IS NOT NULL AND (NOT isfinite(due) OR due<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR due>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
 IF parent IS NOT NULL THEN
  IF starts IS NOT NULL THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;RETURN; END IF;
  IF due IS NOT NULL AND ((plan.start_at IS NOT NULL AND due<plan.start_at) OR (plan.due_at IS NOT NULL AND due>plan.due_at)) THEN RETURN QUERY SELECT 'invalid_dates'::text,NULL::text,NULL::text;RETURN; END IF;
 ELSE
  IF (starts IS NOT NULL AND due IS NOT NULL AND due<starts) OR (operation='update' AND EXISTS(SELECT 1 FROM app.milestones m WHERE m.plan_id=target AND m.archived_at IS NULL AND m.due_at IS NOT NULL
   AND ((starts IS NOT NULL AND m.due_at<starts) OR (due IS NOT NULL AND m.due_at>due)))) THEN RETURN QUERY SELECT 'invalid_dates'::text,NULL::text,NULL::text;RETURN; END IF;
 END IF;
 initial:=CASE WHEN parent IS NULL THEN 'draft' ELSE 'planned' END;
 IF operation='create' THEN
  IF parent IS NULL THEN INSERT INTO app.plans(id,client_id,created_by,title,description,status,start_at,due_at) VALUES(target,client,actor,profile->>'title',profile->>'description',initial,starts,due);
  ELSE INSERT INTO app.milestones(id,plan_id,client_id,created_by,title,description,status,due_at) VALUES(target,parent,client,actor,profile->>'title',profile->>'description',initial,due); END IF;
 ELSE
  IF parent IS NULL THEN UPDATE app.plans SET title=profile->>'title',description=profile->>'description',start_at=starts,due_at=due,revision=revision+1,updated_at=stamp WHERE id=target;
  ELSE UPDATE app.milestones SET title=profile->>'title',description=profile->>'description',due_at=due,revision=revision+1,updated_at=stamp WHERE id=target; END IF;
 END IF;
 RETURN QUERY SELECT 'ok'::text,old_state,CASE WHEN operation='create' THEN initial ELSE old_state END;
EXCEPTION WHEN check_violation OR not_null_violation OR invalid_text_representation OR datetime_field_overflow OR invalid_datetime_format OR foreign_key_violation THEN RETURN QUERY SELECT 'invalid'::text,NULL::text,NULL::text;
 WHEN unique_violation THEN RETURN QUERY SELECT 'conflict'::text,NULL::text,NULL::text;
END; $$;
-- +goose StatementEnd

-- Add a resource-bound, typed planning marker; never store metadata or task IDs.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.audit_snapshot_allowed(value jsonb) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE STRICT SET search_path=pg_catalog AS $$
BEGIN
 IF value='null'::jsonb THEN RETURN true; END IF;
 IF jsonb_typeof(value)<>'object' OR value-ARRAY['exists','revision','status','task_status','planning_status']<>'{}'::jsonb THEN RETURN false; END IF;
 IF value ? 'exists' AND jsonb_typeof(value->'exists')<>'boolean' THEN RETURN false; END IF;
 IF value ? 'status' AND (jsonb_typeof(value->'status')<>'string' OR value->>'status' NOT IN ('active','disabled')) THEN RETURN false; END IF;
 IF value ? 'task_status' AND (jsonb_typeof(value->'task_status')<>'string' OR value->>'task_status' NOT IN ('backlog','todo','in_progress','blocked','review','done','cancelled')) THEN RETURN false; END IF;
 IF value ? 'planning_status' AND (jsonb_typeof(value->'planning_status')<>'string' OR value->>'planning_status' NOT IN ('draft','active','planned','in_progress','completed','cancelled')) THEN RETURN false; END IF;
 IF value ? 'revision' THEN
  IF jsonb_typeof(value->'revision')<>'number' OR value->>'revision' !~ '^(0|[1-9][0-9]*)$' THEN RETURN false; END IF;
  IF (value->>'revision')::numeric>9223372036854775807 THEN RETURN false; END IF;
 END IF;
 RETURN true;
END; $$;
-- +goose StatementEnd
ALTER TABLE app.audit_events ADD CONSTRAINT audit_planning_snapshot_kind CHECK (
 NOT (before_state ? 'planning_status' OR after_state ? 'planning_status') OR
 (resource_kind='plan' AND coalesce(before_state->>'planning_status','draft') IN ('draft','active','completed','cancelled') AND coalesce(after_state->>'planning_status','draft') IN ('draft','active','completed','cancelled')) OR
 (resource_kind='milestone' AND coalesce(before_state->>'planning_status','planned') IN ('planned','in_progress','completed','cancelled') AND coalesce(after_state->>'planning_status','planned') IN ('planned','in_progress','completed','cancelled')));
REVOKE ALL ON app.plans,app.milestones,app.milestone_task_links FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.planning_transition(text,text,boolean),app.planning_document(uuid,uuid,boolean),
 app.planning_read(uuid,uuid,uuid,uuid),app.planning_list(uuid,uuid,uuid,uuid,integer,text,text,text,boolean),
 app.planning_links(uuid,uuid,uuid,uuid,uuid,integer,text,boolean),app.planning_task_candidates(uuid,uuid,uuid,uuid,integer,text,boolean),
 app.planning_write(uuid,uuid,uuid,uuid,bigint,text,jsonb,text,jsonb) FROM PUBLIC;


-- +goose Up
INSERT INTO app.permissions(permission_key,scope_kind,description) VALUES
 ('reminders.view','client','View client reminders'),
 ('reminders.create','client','Create client reminders'),
 ('reminders.update','client','Update, complete and dismiss client reminders');
INSERT INTO app.role_permissions(id,role_id,permission_key,seeded)
 SELECT gen_random_uuid(),'00000000-0000-4000-8000-000000000001'::uuid,permission_key,true
 FROM app.permissions WHERE permission_key IN ('reminders.view','reminders.create','reminders.update');

-- Validation is repeated inside the trusted SQL writer, including for direct
-- runtime calls. IANA rule disagreements fail rather than silently moving time.
-- +goose StatementBegin
CREATE FUNCTION app.reminder_schedule_consistent(local_time text,zone text,utc_offset integer,instant timestamptz) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $$
DECLARE wall timestamp;
BEGIN
 IF local_time IS NULL OR local_time !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?$' OR
 zone IS NULL OR char_length(zone)>100 OR zone !~ '^(UTC|[A-Za-z][A-Za-z0-9_+-]*(/[A-Za-z0-9_+-]+)+)$' OR
 utc_offset IS NULL OR utc_offset NOT BETWEEN -86399 AND 86399 OR
 instant IS NULL OR NOT isfinite(instant) OR instant<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR instant>=TIMESTAMPTZ '10000-01-01 00:00:00+00' THEN RETURN false; END IF;
 wall:=local_time::timestamp;
 IF left(local_time,19)<>to_char(wall,'YYYY-MM-DD"T"HH24:MI:SS') THEN RETURN false; END IF;
 RETURN wall>=TIMESTAMP '0001-01-01' AND wall<TIMESTAMP '10000-01-01' AND
 extract(epoch FROM wall-(instant AT TIME ZONE 'UTC'))=utc_offset;
EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow OR invalid_parameter_value THEN RETURN false;
END; $$;
-- +goose StatementEnd
-- Keep stored intent valid after timezone rules change; new schedules still
-- need matching current rules in both the Go adapter and guarded SQL writer.
-- +goose StatementBegin
CREATE FUNCTION app.reminder_schedule_valid(local_time text,zone text,utc_offset integer,instant timestamptz) RETURNS boolean
LANGUAGE plpgsql STABLE SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.reminder_schedule_consistent(local_time,zone,utc_offset,instant) OR
 NOT EXISTS(SELECT 1 FROM pg_timezone_names WHERE name=zone) THEN RETURN false; END IF;
 RETURN instant AT TIME ZONE zone=local_time::timestamp;
EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow OR invalid_parameter_value THEN RETURN false;
END; $$;
-- +goose StatementEnd
CREATE TABLE app.reminders (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 client_id uuid NOT NULL REFERENCES app.clients(id),
 created_by uuid NOT NULL REFERENCES app.users(id),
 owner_id uuid NOT NULL REFERENCES app.users(id),
 title text NOT NULL CHECK(char_length(title) BETWEEN 1 AND 200 AND title=btrim(title) AND title!~'[[:cntrl:]]'),
 description text NOT NULL DEFAULT '' CHECK(char_length(description)<=8000 AND replace(description,E'\n','')!~'[[:cntrl:]]'),
 status text NOT NULL CHECK(status IN ('pending','completed','dismissed')),
 scheduled_at timestamptz NOT NULL,
 scheduled_local text NOT NULL,
 timezone text NOT NULL,
 utc_offset_seconds integer NOT NULL,
 task_id uuid,
 plan_id uuid,
 milestone_id uuid,
 milestone_plan_id uuid,
 completed_at timestamptz,
 dismissed_at timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 FOREIGN KEY(task_id,client_id) REFERENCES app.tasks(id,client_id),
 FOREIGN KEY(plan_id,client_id) REFERENCES app.plans(id,client_id),
 FOREIGN KEY(milestone_id,milestone_plan_id,client_id) REFERENCES app.milestones(id,plan_id,client_id),
 CHECK(num_nonnulls(task_id,plan_id,milestone_id)<=1),
 CHECK((milestone_id IS NULL)=(milestone_plan_id IS NULL)),
 CHECK(app.reminder_schedule_consistent(scheduled_local,timezone,utc_offset_seconds,scheduled_at)),
 CHECK((status='completed')=(completed_at IS NOT NULL)),
 CHECK((status='dismissed')=(dismissed_at IS NOT NULL)),
 CHECK(updated_at>=created_at AND (completed_at IS NULL OR completed_at>=created_at) AND (dismissed_at IS NULL OR dismissed_at>=created_at))
);
CREATE INDEX reminders_client_id ON app.reminders(client_id,id);
CREATE INDEX reminders_client_status_id ON app.reminders(client_id,status,id);
CREATE INDEX reminders_client_owner_id ON app.reminders(client_id,owner_id,id);
CREATE INDEX reminders_pending_due ON app.reminders(client_id,scheduled_at,id) WHERE status='pending';

-- +goose StatementBegin
CREATE FUNCTION app.reminder_document(target uuid,details boolean) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('id',r.id,'client_id',r.client_id,'created_by',r.created_by,'owner_id',r.owner_id,
 'title',r.title,'status',r.status,'scheduled_at',r.scheduled_at,'scheduled_local',r.scheduled_local,
 'timezone',r.timezone,'utc_offset_seconds',r.utc_offset_seconds,
 'resource',CASE WHEN r.task_id IS NOT NULL THEN jsonb_build_object('kind','task','id',r.task_id)
  WHEN r.plan_id IS NOT NULL THEN jsonb_build_object('kind','plan','id',r.plan_id)
  WHEN r.milestone_id IS NOT NULL THEN jsonb_build_object('kind','milestone','id',r.milestone_id) END,
 'is_due',r.status='pending' AND r.scheduled_at<=statement_timestamp(),'completed_at',r.completed_at,'dismissed_at',r.dismissed_at,
 'revision',r.revision,'created_at',r.created_at,'updated_at',r.updated_at)
 ||CASE WHEN details THEN jsonb_build_object('description',r.description) ELSE '{}'::jsonb END
 FROM app.reminders r WHERE r.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.reminder_snapshot(target uuid) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('exists',true,'revision',r.revision,'reminder_status',r.status,
 'reminder_scheduled_at',to_char(r.scheduled_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
 'reminder_timezone',r.timezone) FROM app.reminders r WHERE r.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.reminder_read(actor uuid,client uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'reminders.view',client) OR NOT EXISTS(SELECT 1 FROM app.reminders WHERE id=target AND client_id=client) THEN RETURN NULL; END IF;
 RETURN app.reminder_document(target,true);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.reminder_list(actor uuid,client uuid,after_id uuid,page_limit integer,state text,due_filter text,owner_filter uuid,search text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'reminders.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR state IS NULL OR state NOT IN ('all','pending','completed','dismissed') OR
 due_filter IS NULL OR due_filter NOT IN ('all','due','upcoming') OR search IS NULL OR char_length(search)>100 OR search~'[[:cntrl:]]' OR descending IS NULL THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT app.reminder_document(r.id,false) FROM app.reminders r WHERE r.client_id=client
 AND (state='all' OR r.status=state) AND (owner_filter IS NULL OR r.owner_id=owner_filter)
 AND (due_filter='all' OR (r.status='pending' AND ((due_filter='due' AND r.scheduled_at<=statement_timestamp()) OR (due_filter='upcoming' AND r.scheduled_at>statement_timestamp()))))
 AND (search='' OR strpos(lower(r.title),lower(search))>0)
 AND (after_id IS NULL OR (NOT descending AND r.id>after_id) OR (descending AND r.id<after_id))
 ORDER BY CASE WHEN NOT descending THEN r.id END ASC,CASE WHEN descending THEN r.id END DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.reminder_owners(actor uuid,client uuid,after_id uuid,page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'reminders.view',client) OR
 NOT (app.authorization_allowed(actor,'reminders.create',client) OR app.authorization_allowed(actor,'reminders.update',client)) OR
 NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) THEN RAISE SQLSTATE 'P0001' USING MESSAGE='archived client'; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',u.id,'display_name',u.display_name) FROM app.users u
 WHERE u.status='active' AND app.authorization_allowed(u.id,'reminders.view',client)
 AND (after_id IS NULL OR u.id>after_id) ORDER BY u.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd

-- Permission, lifecycle, owner and link checks occur after the shared lock wait.
-- +goose StatementBegin
CREATE FUNCTION app.reminder_write(actor uuid,client uuid,target uuid,expected bigint,operation text,profile jsonb)
RETURNS TABLE(code text,before_state jsonb,after_state jsonb)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE previous app.reminders%ROWTYPE; before_value jsonb:='null'::jsonb; stamp timestamptz;
 assigned uuid; scheduled timestamptz; local_time text; zone text; utc_offset integer;
 link_kind text; link_id uuid; linked_task uuid; linked_plan uuid; linked_milestone uuid; milestone_parent uuid;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF operation IS NULL OR operation NOT IN ('create','update','complete','dismiss') OR target IS NULL OR target='00000000-0000-0000-0000-000000000000' THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 IF NOT app.authorization_allowed(actor,'reminders.view',client) OR NOT app.authorization_allowed(actor,CASE WHEN operation='create' THEN 'reminders.create' ELSE 'reminders.update' END,client) OR
 NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RETURN QUERY SELECT 'missing'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 IF operation<>'create' THEN
  SELECT * INTO previous FROM app.reminders WHERE id=target AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
  before_value:=app.reminder_snapshot(target);
 END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) OR
 (operation='create' AND expected IS DISTINCT FROM 0::bigint) OR
 (operation<>'create' AND (expected IS NULL OR expected<1 OR expected=9223372036854775807 OR expected<>previous.revision OR previous.status<>'pending')) THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 stamp:=clock_timestamp();
 IF operation IN ('complete','dismiss') THEN
  UPDATE app.reminders SET status=CASE WHEN operation='complete' THEN 'completed' ELSE 'dismissed' END,
   completed_at=CASE WHEN operation='complete' THEN stamp END,dismissed_at=CASE WHEN operation='dismiss' THEN stamp END,
   revision=revision+1,updated_at=stamp WHERE id=target;
  RETURN QUERY SELECT 'ok'::text,before_value,app.reminder_snapshot(target);RETURN;
 END IF;
 IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR profile-ARRAY['title','description','owner_id','scheduled_local','timezone','utc_offset_seconds','scheduled_at','resource']<>'{}'::jsonb OR
 jsonb_typeof(profile->'title') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'description') IS DISTINCT FROM 'string' OR
 jsonb_typeof(profile->'owner_id') IS DISTINCT FROM 'string' OR NOT coalesce(jsonb_typeof(profile->'resource') IN ('null','object'),false) THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 assigned:=(profile->>'owner_id')::uuid;
 IF (operation='create' OR assigned IS DISTINCT FROM previous.owner_id) AND
 (NOT EXISTS(SELECT 1 FROM app.users WHERE id=assigned AND status='active') OR NOT app.authorization_allowed(assigned,'reminders.view',client)) THEN RETURN QUERY SELECT 'invalid_owner'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 IF jsonb_typeof(profile->'scheduled_local') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'timezone') IS DISTINCT FROM 'string' OR
 jsonb_typeof(profile->'scheduled_at') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'utc_offset_seconds') IS DISTINCT FROM 'number' OR
 profile->>'utc_offset_seconds' !~ '^-?(0|[1-9][0-9]*)$' THEN RETURN QUERY SELECT 'invalid_schedule'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 local_time:=profile->>'scheduled_local';zone:=profile->>'timezone';utc_offset:=(profile->>'utc_offset_seconds')::integer;scheduled:=(profile->>'scheduled_at')::timestamptz;
 IF NOT app.reminder_schedule_valid(local_time,zone,utc_offset,scheduled) THEN RETURN QUERY SELECT 'invalid_schedule'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
 IF jsonb_typeof(profile->'resource')='object' THEN
  IF (profile->'resource')-ARRAY['kind','id']<>'{}'::jsonb OR jsonb_typeof(profile->'resource'->'kind') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'resource'->'id') IS DISTINCT FROM 'string' THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
  link_kind:=profile->'resource'->>'kind';link_id:=(profile->'resource'->>'id')::uuid;
  IF link_kind='task' THEN
   linked_task:=link_id;
   IF (operation='create' OR link_id IS DISTINCT FROM previous.task_id) AND (NOT app.authorization_allowed(actor,'tasks.view',client) OR NOT EXISTS(SELECT 1 FROM app.tasks WHERE id=link_id AND client_id=client AND archived_at IS NULL)) THEN RETURN QUERY SELECT 'invalid_resource'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
  ELSIF link_kind='plan' THEN
   linked_plan:=link_id;
   IF (operation='create' OR link_id IS DISTINCT FROM previous.plan_id) AND (NOT app.authorization_allowed(actor,'planning.view',client) OR NOT EXISTS(SELECT 1 FROM app.plans WHERE id=link_id AND client_id=client AND archived_at IS NULL)) THEN RETURN QUERY SELECT 'invalid_resource'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
  ELSIF link_kind='milestone' THEN
   linked_milestone:=link_id;
   IF operation='update' AND link_id IS NOT DISTINCT FROM previous.milestone_id THEN milestone_parent:=previous.milestone_plan_id;
   ELSE
    IF NOT app.authorization_allowed(actor,'planning.view',client) THEN RETURN QUERY SELECT 'invalid_resource'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
    SELECT m.plan_id INTO milestone_parent FROM app.milestones m JOIN app.plans p ON p.id=m.plan_id AND p.client_id=m.client_id
     WHERE m.id=link_id AND m.client_id=client AND m.archived_at IS NULL AND p.archived_at IS NULL;
    IF NOT FOUND THEN RETURN QUERY SELECT 'invalid_resource'::text,NULL::jsonb,NULL::jsonb;RETURN; END IF;
   END IF;
  ELSE RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb;RETURN;
  END IF;
 END IF;
 IF operation='create' THEN
  INSERT INTO app.reminders(id,client_id,created_by,owner_id,title,description,status,scheduled_at,scheduled_local,timezone,utc_offset_seconds,task_id,plan_id,milestone_id,milestone_plan_id,created_at,updated_at)
   VALUES(target,client,actor,assigned,profile->>'title',profile->>'description','pending',scheduled,local_time,zone,utc_offset,linked_task,linked_plan,linked_milestone,milestone_parent,stamp,stamp);
 ELSE
  UPDATE app.reminders SET owner_id=assigned,title=profile->>'title',description=profile->>'description',scheduled_at=scheduled,scheduled_local=local_time,
   timezone=zone,utc_offset_seconds=utc_offset,task_id=linked_task,plan_id=linked_plan,milestone_id=linked_milestone,milestone_plan_id=milestone_parent,revision=revision+1,updated_at=stamp WHERE id=target;
 END IF;
 RETURN QUERY SELECT 'ok'::text,before_value,app.reminder_snapshot(target);
EXCEPTION WHEN check_violation OR not_null_violation OR invalid_text_representation OR datetime_field_overflow OR invalid_datetime_format OR foreign_key_violation OR numeric_value_out_of_range THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb;
 WHEN unique_violation THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb;
END; $$;
-- +goose StatementEnd

-- Extend only typed scheduling fields, with pairing, UTC and resource bounds.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.audit_snapshot_allowed(value jsonb) RETURNS boolean
LANGUAGE plpgsql STABLE STRICT SET search_path=pg_catalog AS $$
DECLARE scheduled timestamptz;
BEGIN
 IF value='null'::jsonb THEN RETURN true; END IF;
 IF jsonb_typeof(value)<>'object' OR value-ARRAY['exists','revision','status','task_status','planning_status','reminder_status','reminder_scheduled_at','reminder_timezone']<>'{}'::jsonb THEN RETURN false; END IF;
 IF value ? 'exists' AND jsonb_typeof(value->'exists')<>'boolean' THEN RETURN false; END IF;
 IF value ? 'status' AND (jsonb_typeof(value->'status')<>'string' OR value->>'status' NOT IN ('active','disabled')) THEN RETURN false; END IF;
 IF value ? 'task_status' AND (jsonb_typeof(value->'task_status')<>'string' OR value->>'task_status' NOT IN ('backlog','todo','in_progress','blocked','review','done','cancelled')) THEN RETURN false; END IF;
 IF value ? 'planning_status' AND (jsonb_typeof(value->'planning_status')<>'string' OR value->>'planning_status' NOT IN ('draft','active','planned','in_progress','completed','cancelled')) THEN RETURN false; END IF;
 IF value ? 'reminder_status' AND (jsonb_typeof(value->'reminder_status')<>'string' OR value->>'reminder_status' NOT IN ('pending','completed','dismissed')) THEN RETURN false; END IF;
 IF (value ? 'reminder_scheduled_at')<>(value ? 'reminder_timezone') THEN RETURN false; END IF;
 IF value ? 'reminder_scheduled_at' THEN
  IF jsonb_typeof(value->'reminder_scheduled_at')<>'string' OR value->>'reminder_scheduled_at' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?Z$' OR
  jsonb_typeof(value->'reminder_timezone')<>'string' OR char_length(value->>'reminder_timezone')>100 OR value->>'reminder_timezone' !~ '^(UTC|[A-Za-z][A-Za-z0-9_+-]*(/[A-Za-z0-9_+-]+)+)$' OR
  NOT EXISTS(SELECT 1 FROM pg_timezone_names WHERE name=value->>'reminder_timezone') THEN RETURN false; END IF;
  scheduled:=(value->>'reminder_scheduled_at')::timestamptz;
  IF left(value->>'reminder_scheduled_at',19)<>to_char(scheduled AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS') THEN RETURN false; END IF;
  IF NOT isfinite(scheduled) OR scheduled<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR scheduled>=TIMESTAMPTZ '10000-01-01 00:00:00+00' THEN RETURN false; END IF;
 END IF;
 IF value ? 'revision' THEN
  IF jsonb_typeof(value->'revision')<>'number' OR value->>'revision' !~ '^(0|[1-9][0-9]*)$' THEN RETURN false; END IF;
  IF (value->>'revision')::numeric>9223372036854775807 THEN RETURN false; END IF;
 END IF;
 RETURN true;
EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow THEN RETURN false;
END; $$;
-- +goose StatementEnd
ALTER TABLE app.audit_events ADD CONSTRAINT audit_reminder_snapshot_kind CHECK (
 NOT (before_state ?| ARRAY['reminder_status','reminder_scheduled_at','reminder_timezone'] OR after_state ?| ARRAY['reminder_status','reminder_scheduled_at','reminder_timezone']) OR resource_kind='reminder');
ALTER TABLE app.audit_events DROP CONSTRAINT audit_event_action;
ALTER TABLE app.audit_events ADD CONSTRAINT audit_event_action CHECK (
 (resource_kind<>'reminder' AND (event_name IN (resource_kind||'.created',resource_kind||'.updated',resource_kind||'.archived',resource_kind||'.deleted') OR
 (resource_kind='user' AND event_name='user.disabled') OR (resource_kind='role' AND event_name='role.permission_changed') OR
 (resource_kind='task' AND event_name IN ('task.completed','task.cancelled')))) OR
 (resource_kind='reminder' AND event_name IN ('reminder.created','reminder.updated','reminder.completed','reminder.dismissed')));
REVOKE ALL ON app.reminders FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.reminder_schedule_consistent(text,text,integer,timestamptz),app.reminder_schedule_valid(text,text,integer,timestamptz),app.reminder_document(uuid,boolean),app.reminder_snapshot(uuid),
 app.reminder_read(uuid,uuid,uuid),app.reminder_list(uuid,uuid,uuid,integer,text,text,uuid,text,boolean),
 app.reminder_owners(uuid,uuid,uuid,integer),app.reminder_write(uuid,uuid,uuid,bigint,text,jsonb) FROM PUBLIC;


-- +goose Up
INSERT INTO app.permissions(permission_key,scope_kind,description)
 VALUES ('activity.view','client','View authorized client business activity');
INSERT INTO app.role_permissions(id,role_id,permission_key,seeded)
 VALUES (gen_random_uuid(),'00000000-0000-4000-8000-000000000001','activity.view',true);

-- Read the append-only source directly: no backfill, projection lag or profile
-- joins. The existing audit_events_client_time index supports reverse keysets.
-- +goose StatementBegin
CREATE FUNCTION app.activity_list(actor uuid,client uuid,after_time timestamptz,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,occurred_at timestamptz,event_type text,resource_kind text,resource_id uuid)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE task_access boolean; planning_access boolean; reminder_access boolean;
BEGIN
 IF NOT app.authorization_allowed(actor,'activity.view',client) OR
 NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR
 (after_time IS NULL)<>(after_id IS NULL) OR after_id='00000000-0000-0000-0000-000000000000'::uuid OR
 (after_time IS NOT NULL AND (NOT isfinite(after_time) OR after_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR after_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) THEN RAISE invalid_parameter_value; END IF;
 task_access:=app.authorization_allowed(actor,'tasks.view',client);
 planning_access:=app.authorization_allowed(actor,'planning.view',client);
 reminder_access:=app.authorization_allowed(actor,'reminders.view',client);
 RETURN QUERY SELECT e.id,e.client_id,e.occurred_at,e.event_name,e.resource_kind,e.resource_id
 FROM app.audit_events e
 WHERE e.client_id=client AND e.schema_version=1 AND
 ((e.resource_kind='client' AND e.event_name IN ('client.created','client.updated','client.archived')) OR
  (task_access AND e.resource_kind='task' AND e.event_name IN ('task.created','task.updated','task.archived','task.completed','task.cancelled')) OR
  (planning_access AND e.resource_kind='plan' AND e.event_name IN ('plan.created','plan.updated','plan.archived')) OR
  (planning_access AND e.resource_kind='milestone' AND e.event_name IN ('milestone.created','milestone.updated','milestone.archived')) OR
  (reminder_access AND e.resource_kind='reminder' AND e.event_name IN ('reminder.created','reminder.updated','reminder.completed','reminder.dismissed'))) AND
 (after_time IS NULL OR (e.occurred_at,e.id)<(after_time,after_id))
 ORDER BY e.occurred_at DESC,e.id DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.activity_list(uuid,uuid,timestamptz,uuid,integer) FROM PUBLIC;


-- +goose Up
CREATE INDEX audit_events_time ON app.audit_events(occurred_at DESC,id DESC);

-- New storage keys never expand this read projection.
-- +goose StatementBegin
CREATE FUNCTION app.audit_reader_snapshot(value jsonb) RETURNS jsonb
LANGUAGE sql IMMUTABLE STRICT SET search_path=pg_catalog AS $$
 SELECT CASE WHEN value='null'::jsonb THEN 'null'::jsonb ELSE jsonb_strip_nulls(jsonb_build_object(
 'exists',value->'exists','revision',value->'revision','status',value->'status',
 'task_status',value->'task_status','planning_status',value->'planning_status',
 'reminder_status',value->'reminder_status','reminder_scheduled_at',value->'reminder_scheduled_at',
 'reminder_timezone',value->'reminder_timezone')) END;
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.audit_reader_snapshot(jsonb) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.audit_reader_list(actor uuid,scope_client uuid,filter_client uuid,filter_actor uuid,
 filter_actor_kind text,filter_event text,filter_kind text,filter_resource uuid,filter_request text,
 from_time timestamptz,to_time timestamptz,after_time timestamptz,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,schema_version smallint,occurred_at timestamptz,actor_kind text,actor_user_id uuid,
 event_type text,resource_kind text,resource_id uuid,client_id uuid,request_id text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE selected_client uuid;
BEGIN
 IF NOT app.authorization_allowed(actor,'audit.view',NULL) THEN
 IF scope_client IS NOT NULL THEN RAISE no_data_found; END IF;
 RAISE EXCEPTION 'Audit access denied' USING ERRCODE='P0001'; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR
 scope_client='00000000-0000-0000-0000-000000000000'::uuid OR
 filter_client='00000000-0000-0000-0000-000000000000'::uuid OR
 filter_actor='00000000-0000-0000-0000-000000000000'::uuid OR
 filter_resource='00000000-0000-0000-0000-000000000000'::uuid OR
 (scope_client IS NOT NULL AND filter_client IS NOT NULL AND scope_client<>filter_client) OR
 (filter_actor_kind IS NOT NULL AND filter_actor_kind NOT IN ('system','user')) OR
 (filter_event IS NOT NULL AND filter_event !~ '^[a-z][a-z0-9_]{0,31}\.(created|updated|archived|deleted|disabled|permission_changed|completed|cancelled|dismissed)$') OR
 (filter_kind IS NOT NULL AND filter_kind !~ '^[a-z][a-z0-9_]{0,31}$') OR
 (filter_request IS NOT NULL AND filter_request !~ '^[A-Z2-7]{26}$') OR
 (after_time IS NULL)<>(after_id IS NULL) OR after_id='00000000-0000-0000-0000-000000000000'::uuid OR
 (from_time IS NOT NULL AND (NOT isfinite(from_time) OR from_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR from_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (to_time IS NOT NULL AND (NOT isfinite(to_time) OR to_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR to_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (after_time IS NOT NULL AND (NOT isfinite(after_time) OR after_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR after_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (from_time IS NOT NULL AND to_time IS NOT NULL AND from_time>=to_time) THEN RAISE invalid_parameter_value; END IF;
 selected_client:=COALESCE(scope_client,filter_client);
 IF selected_client IS NOT NULL AND (NOT app.authorization_allowed(actor,'clients.view',selected_client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=selected_client)) THEN RAISE no_data_found; END IF;
 RETURN QUERY WITH client_grants AS MATERIALIZED (
 SELECT g.scope_kind,g.client_id FROM app.authorization_grants(actor) g WHERE g.permission_key='clients.view')
 SELECT e.id,e.schema_version,e.occurred_at,e.actor_kind,e.actor_user_id,e.event_name,e.resource_kind,e.resource_id,e.client_id,e.request_id
 FROM app.audit_events e WHERE e.schema_version=1 AND
 (e.client_id IS NULL OR EXISTS(SELECT 1 FROM app.clients c WHERE c.id=e.client_id AND
 EXISTS(SELECT 1 FROM client_grants g WHERE g.scope_kind='global' OR g.client_id=e.client_id))) AND
 (selected_client IS NULL OR e.client_id=selected_client) AND
 (filter_actor IS NULL OR e.actor_user_id=filter_actor) AND (filter_actor_kind IS NULL OR e.actor_kind=filter_actor_kind) AND
 (filter_event IS NULL OR e.event_name=filter_event) AND (filter_kind IS NULL OR e.resource_kind=filter_kind) AND
 (filter_resource IS NULL OR e.resource_id=filter_resource) AND (filter_request IS NULL OR e.request_id=filter_request) AND
 (from_time IS NULL OR e.occurred_at>=from_time) AND (to_time IS NULL OR e.occurred_at<to_time) AND
 (after_time IS NULL OR (e.occurred_at,e.id)<(after_time,after_id))
 ORDER BY e.occurred_at DESC,e.id DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.audit_reader_list(uuid,uuid,uuid,uuid,text,text,text,uuid,text,timestamptz,timestamptz,timestamptz,uuid,integer) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.audit_reader_detail(actor uuid,scope_client uuid,event_id uuid)
RETURNS TABLE(id uuid,schema_version smallint,occurred_at timestamptz,actor_kind text,actor_user_id uuid,
 event_type text,resource_kind text,resource_id uuid,client_id uuid,request_id text,before_state jsonb,after_state jsonb,metadata jsonb)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'audit.view',NULL) THEN
 IF scope_client IS NOT NULL THEN RAISE no_data_found; END IF;
 RAISE EXCEPTION 'Audit access denied' USING ERRCODE='P0001'; END IF;
 IF event_id IS NULL OR event_id='00000000-0000-0000-0000-000000000000'::uuid OR
 scope_client='00000000-0000-0000-0000-000000000000'::uuid THEN RAISE invalid_parameter_value; END IF;
 IF scope_client IS NOT NULL AND (NOT app.authorization_allowed(actor,'clients.view',scope_client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=scope_client)) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT e.id,e.schema_version,e.occurred_at,e.actor_kind,e.actor_user_id,e.event_name,e.resource_kind,e.resource_id,e.client_id,e.request_id,
 app.audit_reader_snapshot(e.before_state),app.audit_reader_snapshot(e.after_state),jsonb_build_object('source',e.metadata->'source')
 FROM app.audit_events e WHERE e.id=event_id AND e.schema_version=1 AND (scope_client IS NULL OR e.client_id=scope_client) AND
 (e.client_id IS NULL OR (app.authorization_allowed(actor,'clients.view',e.client_id) AND EXISTS(SELECT 1 FROM app.clients c WHERE c.id=e.client_id)));
 IF NOT FOUND THEN RAISE no_data_found; END IF;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.audit_reader_detail(uuid,uuid,uuid) FROM PUBLIC;


-- +goose Up
INSERT INTO app.permissions(permission_key,scope_kind,description) VALUES
 ('billing.create','client','Create client collections'),
 ('billing.update','client','Edit collections and record payments'),
 ('billing.delete','client','Cancel unsettled collections with retained history');
INSERT INTO app.role_permissions(id,role_id,permission_key,seeded)
 SELECT gen_random_uuid(),'00000000-0000-4000-8000-000000000001'::uuid,permission_key,true
 FROM app.permissions WHERE permission_key IN ('billing.create','billing.update','billing.delete');
CREATE TABLE app.billing_currencies (
 code text PRIMARY KEY CHECK(code IN ('USD','EUR','GBP','TRY','JPY','KWD')),
 exponent smallint NOT NULL CHECK(exponent=CASE code WHEN 'JPY' THEN 0 WHEN 'KWD' THEN 3 ELSE 2 END),
 UNIQUE(code,exponent)
);
INSERT INTO app.billing_currencies VALUES ('USD',2),('EUR',2),('GBP',2),('TRY',2),('JPY',0),('KWD',3);
CREATE TABLE app.collections (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 client_id uuid NOT NULL REFERENCES app.clients(id),
 created_by uuid NOT NULL REFERENCES app.users(id),
 description text NOT NULL CHECK(char_length(description) BETWEEN 1 AND 2000 AND description=btrim(description) AND replace(description,E'\n','')!~'[[:cntrl:]]'),
 internal_note text NOT NULL DEFAULT '' CHECK(char_length(internal_note)<=8000 AND replace(internal_note,E'\n','')!~'[[:cntrl:]]'),
 amount_minor bigint NOT NULL CHECK(amount_minor>0),
 paid_minor bigint NOT NULL DEFAULT 0 CHECK(paid_minor>=0 AND paid_minor<=amount_minor),
 currency text NOT NULL,
 currency_exponent smallint NOT NULL,
 due_date date CHECK(due_date IS NULL OR due_date BETWEEN DATE '0001-01-01' AND DATE '9999-12-31'),
 cancelled_at timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 FOREIGN KEY(currency,currency_exponent) REFERENCES app.billing_currencies(code,exponent),
 UNIQUE(id,client_id,currency),
 CHECK(updated_at>=created_at AND (cancelled_at IS NULL OR cancelled_at>=created_at)),
 CHECK(cancelled_at IS NULL OR paid_minor<amount_minor)
);
CREATE INDEX collections_client_id ON app.collections(client_id,id);
CREATE INDEX collections_client_currency_id ON app.collections(client_id,currency,id);
CREATE INDEX collections_unsettled_due ON app.collections(client_id,due_date,id) WHERE cancelled_at IS NULL AND paid_minor<amount_minor;
CREATE TABLE app.payments (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 collection_id uuid NOT NULL,
 client_id uuid NOT NULL,
 currency text NOT NULL,
 recorded_by uuid NOT NULL REFERENCES app.users(id),
 amount_minor bigint NOT NULL CHECK(amount_minor>0),
 paid_on date NOT NULL CHECK(paid_on BETWEEN DATE '0001-01-01' AND DATE '9999-12-31'),
 method text NOT NULL CHECK(method IN ('bank_transfer','cash','card','other')),
 reference text NOT NULL DEFAULT '' CHECK(char_length(reference)<=200 AND reference!~'[[:cntrl:]]'),
 note text NOT NULL DEFAULT '' CHECK(char_length(note)<=2000 AND replace(note,E'\n','')!~'[[:cntrl:]]'),
 command_id uuid NOT NULL CHECK(command_id<>'00000000-0000-0000-0000-000000000000'),
 expected_revision bigint NOT NULL CHECK(expected_revision>0 AND expected_revision<9223372036854775807),
 collection_revision bigint NOT NULL CHECK(collection_revision=expected_revision+1),
 recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 FOREIGN KEY(collection_id,client_id,currency) REFERENCES app.collections(id,client_id,currency),
 UNIQUE(collection_id,command_id),UNIQUE(collection_id,collection_revision)
);
CREATE INDEX payments_collection_id ON app.payments(collection_id,id);

-- +goose StatementBegin
CREATE FUNCTION app.billing_history_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog AS $$
BEGIN
 IF TG_TABLE_NAME='collections' AND TG_OP='UPDATE' THEN
  IF (NEW.id,NEW.client_id,NEW.created_by,NEW.currency,NEW.currency_exponent,NEW.created_at) IS DISTINCT FROM
     (OLD.id,OLD.client_id,OLD.created_by,OLD.currency,OLD.currency_exponent,OLD.created_at) OR
    (OLD.cancelled_at IS NOT NULL AND NEW IS DISTINCT FROM OLD) OR
    (NEW.amount_minor<>OLD.amount_minor AND EXISTS(SELECT 1 FROM app.payments WHERE collection_id=OLD.id)) THEN
   RAISE EXCEPTION 'Financial history is immutable' USING ERRCODE='42501';
  END IF;
  RETURN NEW;
 END IF;
 RAISE EXCEPTION 'Financial history cannot be removed or rewritten' USING ERRCODE='42501';
END; $$;
-- +goose StatementEnd
CREATE TRIGGER collection_history_guard BEFORE UPDATE OR DELETE ON app.collections FOR EACH ROW EXECUTE FUNCTION app.billing_history_guard();
CREATE TRIGGER collection_truncate_guard BEFORE TRUNCATE ON app.collections FOR EACH STATEMENT EXECUTE FUNCTION app.billing_history_guard();
CREATE TRIGGER payment_history_guard BEFORE UPDATE OR DELETE OR TRUNCATE ON app.payments FOR EACH STATEMENT EXECUTE FUNCTION app.billing_history_guard();
ALTER TABLE app.collections ENABLE ALWAYS TRIGGER collection_history_guard;
ALTER TABLE app.collections ENABLE ALWAYS TRIGGER collection_truncate_guard;
ALTER TABLE app.payments ENABLE ALWAYS TRIGGER payment_history_guard;
-- Cached balance must exactly equal the append-only ledger at commit.
-- Definer authority is required after the guarded writer has returned;
-- the committing runtime deliberately has no financial table privileges.
-- +goose StatementBegin
CREATE FUNCTION app.billing_balance_guard() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE target uuid; balance numeric; collected bigint;
BEGIN
 IF TG_TABLE_NAME='payments' THEN target:=NEW.collection_id; ELSE target:=NEW.id; END IF;
 SELECT paid_minor INTO collected FROM app.collections WHERE id=target FOR UPDATE;
 SELECT coalesce(sum(amount_minor::numeric),0) INTO balance FROM app.payments WHERE collection_id=target;
 IF collected IS DISTINCT FROM balance THEN RAISE EXCEPTION 'Financial balance disagrees with ledger' USING ERRCODE='23514'; END IF;
 RETURN NULL;
END; $$;
-- +goose StatementEnd
CREATE CONSTRAINT TRIGGER collection_balance_guard AFTER INSERT OR UPDATE ON app.collections DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.billing_balance_guard();
CREATE CONSTRAINT TRIGGER payment_balance_guard AFTER INSERT ON app.payments DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.billing_balance_guard();
ALTER TABLE app.collections ENABLE ALWAYS TRIGGER collection_balance_guard;
ALTER TABLE app.payments ENABLE ALWAYS TRIGGER payment_balance_guard;
-- +goose StatementBegin
CREATE FUNCTION app.billing_payment_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.paid_on>(statement_timestamp() AT TIME ZONE 'UTC')::date OR EXISTS(SELECT 1 FROM app.collections WHERE id=NEW.collection_id AND cancelled_at IS NOT NULL) THEN
  RAISE EXCEPTION 'Invalid payment lifecycle' USING ERRCODE='23514';
 END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
CREATE TRIGGER payment_insert_guard BEFORE INSERT ON app.payments FOR EACH ROW EXECUTE FUNCTION app.billing_payment_guard();
ALTER TABLE app.payments ENABLE ALWAYS TRIGGER payment_insert_guard;

-- +goose StatementBegin
CREATE FUNCTION app.billing_status(total bigint,collected bigint,due date,cancelled timestamptz) RETURNS text
LANGUAGE sql STABLE SET search_path=pg_catalog AS $$
 SELECT CASE WHEN cancelled IS NOT NULL THEN 'cancelled' WHEN collected=total THEN 'paid'
 WHEN due<(statement_timestamp() AT TIME ZONE 'UTC')::date THEN 'overdue'
 WHEN collected>0 THEN 'partially_paid' ELSE 'pending' END;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_document(target uuid) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('id',c.id,'client_id',c.client_id,'created_by',c.created_by,'description',c.description,
 'internal_note',c.internal_note,'amount_minor',c.amount_minor::text,'paid_minor',c.paid_minor::text,
 'outstanding_minor',CASE WHEN c.cancelled_at IS NOT NULL THEN '0' ELSE (c.amount_minor-c.paid_minor)::text END,
 'currency',c.currency,'currency_exponent',c.currency_exponent,'due_date',to_char(c.due_date,'YYYY-MM-DD'),
 'status',app.billing_status(c.amount_minor,c.paid_minor,c.due_date,c.cancelled_at),'cancelled_at',c.cancelled_at,
 'revision',c.revision::text,'created_at',c.created_at,'updated_at',c.updated_at) FROM app.collections c WHERE c.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_snapshot(target uuid) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('exists',true,'revision',c.revision,'billing_status',app.billing_status(c.amount_minor,c.paid_minor,c.due_date,c.cancelled_at),
 'currency',c.currency,'amount_minor',c.amount_minor::text,'paid_minor',c.paid_minor::text) FROM app.collections c WHERE c.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_read(actor uuid,client uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'billing.view',client) OR NOT EXISTS(SELECT 1 FROM app.collections WHERE id=target AND client_id=client) THEN RETURN NULL; END IF;
 RETURN app.billing_document(target);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_list(actor uuid,client uuid,after_id uuid,page_limit integer,state text,requested_currency text,search text) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'billing.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR state IS NULL OR state NOT IN ('all','pending','partially_paid','paid','overdue','cancelled') OR
 requested_currency IS NULL OR (requested_currency<>'' AND NOT EXISTS(SELECT 1 FROM app.billing_currencies WHERE code=requested_currency)) OR
 search IS NULL OR char_length(search)>100 OR search~'[[:cntrl:]]' THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT app.billing_document(c.id) FROM app.collections c WHERE c.client_id=client AND
 (after_id IS NULL OR c.id>after_id) AND (state='all' OR app.billing_status(c.amount_minor,c.paid_minor,c.due_date,c.cancelled_at)=state) AND
 (requested_currency='' OR c.currency=requested_currency) AND (search='' OR strpos(lower(c.description),lower(search))>0) ORDER BY c.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_payments(actor uuid,client uuid,target uuid,after_id uuid,page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'billing.view',client) OR NOT EXISTS(SELECT 1 FROM app.collections WHERE id=target AND client_id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',p.id,'collection_id',p.collection_id,'client_id',p.client_id,'recorded_by',p.recorded_by,
 'amount_minor',p.amount_minor::text,'currency',p.currency,'paid_on',to_char(p.paid_on,'YYYY-MM-DD'),'method',p.method,
 'reference',p.reference,'note',p.note,'command_id',p.command_id,'collection_revision',p.collection_revision::text,'recorded_at',p.recorded_at)
 FROM app.payments p WHERE p.collection_id=target AND (after_id IS NULL OR p.id>after_id) ORDER BY p.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_summary(actor uuid,client uuid) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'billing.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT jsonb_build_object('currency',c.currency,'currency_exponent',c.currency_exponent,
 'amount_minor',coalesce(sum(c.amount_minor::numeric) FILTER(WHERE c.cancelled_at IS NULL),0)::text,
 'paid_minor',coalesce(sum(c.paid_minor::numeric) FILTER(WHERE c.cancelled_at IS NULL),0)::text,
 'outstanding_minor',coalesce(sum((c.amount_minor-c.paid_minor)::numeric) FILTER(WHERE c.cancelled_at IS NULL),0)::text,
 'overdue_minor',coalesce(sum((c.amount_minor-c.paid_minor)::numeric) FILTER(WHERE c.cancelled_at IS NULL AND c.due_date<(statement_timestamp() AT TIME ZONE 'UTC')::date),0)::text,
 'cancelled_amount_minor',coalesce(sum(c.amount_minor::numeric) FILTER(WHERE c.cancelled_at IS NOT NULL),0)::text,
 'cancelled_paid_minor',coalesce(sum(c.paid_minor::numeric) FILTER(WHERE c.cancelled_at IS NOT NULL),0)::text)
 FROM app.collections c WHERE c.client_id=client GROUP BY c.currency,c.currency_exponent ORDER BY c.currency;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.billing_currency_list(actor uuid,client uuid) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'billing.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT jsonb_build_object('code',code,'exponent',exponent) FROM app.billing_currencies ORDER BY code;
END; $$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.billing_write(actor uuid,client uuid,target uuid,expected bigint,operation text,profile jsonb,new_payment uuid)
RETURNS TABLE(code text,before_state jsonb,after_state jsonb,payment_id uuid,new_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE previous app.collections%ROWTYPE; prior_payment app.payments%ROWTYPE; before_value jsonb:='null'::jsonb;
 stamp timestamptz; amount bigint; unit smallint; due date; payment_day date; command uuid;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF operation IS NULL OR operation NOT IN ('create','update','payment','cancel') OR target IS NULL OR target='00000000-0000-0000-0000-000000000000' THEN
  RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
 IF NOT app.authorization_allowed(actor,'billing.view',client) OR NOT app.authorization_allowed(actor,CASE operation WHEN 'create' THEN 'billing.create' WHEN 'cancel' THEN 'billing.delete' ELSE 'billing.update' END,client) OR
 NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RETURN QUERY SELECT 'missing'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
 IF operation<>'create' THEN
  SELECT * INTO previous FROM app.collections WHERE id=target AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RETURN QUERY SELECT 'missing'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  before_value:=app.billing_snapshot(target);
 END IF;
 IF operation IN ('create','update','payment') THEN
  IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR jsonb_typeof(profile->'amount_minor') IS DISTINCT FROM 'string' OR
   profile->>'amount_minor' !~ '^[1-9][0-9]{0,18}$' OR (profile->>'amount_minor')::numeric>9223372036854775807 OR
   jsonb_typeof(profile->'currency') IS DISTINCT FROM 'string' THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  amount:=(profile->>'amount_minor')::bigint;
  SELECT bc.exponent INTO unit FROM app.billing_currencies bc WHERE bc.code=profile->>'currency';
  IF NOT FOUND THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
 END IF;
 IF operation='payment' THEN
  IF profile-ARRAY['command_id','amount_minor','currency','paid_on','method','reference','note']<>'{}'::jsonb OR
   jsonb_typeof(profile->'command_id') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'paid_on') IS DISTINCT FROM 'string' OR
   jsonb_typeof(profile->'method') IS DISTINCT FROM 'string' OR profile->>'method' NOT IN ('bank_transfer','cash','card','other') OR
   jsonb_typeof(profile->'reference') IS DISTINCT FROM 'string' OR char_length(profile->>'reference')>200 OR profile->>'reference'~'[[:cntrl:]]' OR
   jsonb_typeof(profile->'note') IS DISTINCT FROM 'string' OR char_length(profile->>'note')>2000 OR replace(profile->>'note',E'\n','')~'[[:cntrl:]]' OR
   profile->>'paid_on' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  command:=(profile->>'command_id')::uuid;payment_day:=(profile->>'paid_on')::date;
  IF command='00000000-0000-0000-0000-000000000000' OR payment_day NOT BETWEEN DATE '0001-01-01' AND DATE '9999-12-31' OR
   to_char(payment_day,'YYYY-MM-DD')<>profile->>'paid_on' OR payment_day>(statement_timestamp() AT TIME ZONE 'UTC')::date THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  SELECT * INTO prior_payment FROM app.payments WHERE collection_id=target AND command_id=command;
  IF FOUND THEN
   IF (prior_payment.recorded_by,prior_payment.expected_revision,prior_payment.amount_minor,prior_payment.currency,prior_payment.paid_on,prior_payment.method,prior_payment.reference,prior_payment.note) IS DISTINCT FROM
      (actor,expected,amount,profile->>'currency',payment_day,profile->>'method',profile->>'reference',profile->>'note') THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
   RETURN QUERY SELECT 'replay'::text,NULL::jsonb,NULL::jsonb,prior_payment.id,previous.revision;RETURN;
  END IF;
 END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) OR
 (operation='create' AND expected IS DISTINCT FROM 0::bigint) OR
 (operation<>'create' AND (expected IS NULL OR expected<1 OR expected=9223372036854775807 OR expected<>previous.revision OR previous.cancelled_at IS NOT NULL)) THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
 stamp:=clock_timestamp();
 IF operation='cancel' THEN
  IF previous.paid_minor=previous.amount_minor THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  UPDATE app.collections SET cancelled_at=stamp,revision=revision+1,updated_at=stamp WHERE id=target;
 ELSIF operation='payment' THEN
  IF profile->>'currency'<>previous.currency OR amount>previous.amount_minor-previous.paid_minor OR new_payment IS NULL OR new_payment='00000000-0000-0000-0000-000000000000' THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  INSERT INTO app.payments(id,collection_id,client_id,currency,recorded_by,amount_minor,paid_on,method,reference,note,command_id,expected_revision,collection_revision,recorded_at)
  VALUES(new_payment,target,client,previous.currency,actor,amount,payment_day,profile->>'method',profile->>'reference',profile->>'note',command,expected,expected+1,stamp);
  UPDATE app.collections SET paid_minor=paid_minor+amount,revision=revision+1,updated_at=stamp WHERE id=target;
 ELSE
  IF profile-ARRAY['description','internal_note','amount_minor','currency','due_date']<>'{}'::jsonb OR
   jsonb_typeof(profile->'description') IS DISTINCT FROM 'string' OR char_length(profile->>'description') NOT BETWEEN 1 AND 2000 OR profile->>'description'<>btrim(profile->>'description') OR replace(profile->>'description',E'\n','')~'[[:cntrl:]]' OR
   jsonb_typeof(profile->'internal_note') IS DISTINCT FROM 'string' OR char_length(profile->>'internal_note')>8000 OR replace(profile->>'internal_note',E'\n','')~'[[:cntrl:]]' OR
   NOT coalesce(jsonb_typeof(profile->'due_date') IN ('null','string'),false) THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  IF profile->>'due_date' IS NOT NULL THEN
   IF profile->>'due_date' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
   due:=(profile->>'due_date')::date;
   IF due NOT BETWEEN DATE '0001-01-01' AND DATE '9999-12-31' OR to_char(due,'YYYY-MM-DD')<>profile->>'due_date' THEN RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
  END IF;
  IF operation='create' THEN
   INSERT INTO app.collections(id,client_id,created_by,description,internal_note,amount_minor,currency,currency_exponent,due_date,created_at,updated_at)
   VALUES(target,client,actor,profile->>'description',profile->>'internal_note',amount,profile->>'currency',unit,due,stamp,stamp);
  ELSE
   IF profile->>'currency'<>previous.currency OR (amount<>previous.amount_minor AND previous.paid_minor>0) THEN RETURN QUERY SELECT 'conflict'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;RETURN; END IF;
   UPDATE app.collections SET description=profile->>'description',internal_note=profile->>'internal_note',amount_minor=amount,due_date=due,revision=revision+1,updated_at=stamp WHERE id=target;
  END IF;
 END IF;
 RETURN QUERY SELECT 'ok'::text,before_value,app.billing_snapshot(target),CASE WHEN operation='payment' THEN new_payment END,
  CASE WHEN operation='create' THEN 1::bigint ELSE expected+1 END;
EXCEPTION WHEN invalid_text_representation OR invalid_datetime_format OR datetime_field_overflow OR numeric_value_out_of_range OR check_violation THEN
 RETURN QUERY SELECT 'invalid'::text,NULL::jsonb,NULL::jsonb,NULL::uuid,0::bigint;
END; $$;
-- +goose StatementEnd
REVOKE ALL ON app.billing_currencies,app.collections,app.payments FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.billing_history_guard(),app.billing_balance_guard(),app.billing_payment_guard(),
 app.billing_status(bigint,bigint,date,timestamptz),app.billing_document(uuid),app.billing_snapshot(uuid),
 app.billing_read(uuid,uuid,uuid),app.billing_list(uuid,uuid,uuid,integer,text,text,text),
 app.billing_payments(uuid,uuid,uuid,uuid,integer),app.billing_summary(uuid,uuid),app.billing_currency_list(uuid,uuid),
 app.billing_write(uuid,uuid,uuid,bigint,text,jsonb,uuid) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.audit_snapshot_allowed(value jsonb) RETURNS boolean
LANGUAGE plpgsql STABLE STRICT SET search_path=pg_catalog AS $$
DECLARE scheduled timestamptz;
BEGIN
 IF value='null'::jsonb THEN RETURN true; END IF;
 IF value ?| ARRAY['billing_status','currency','amount_minor','paid_minor'] THEN
  IF NOT value ?& ARRAY['billing_status','currency','amount_minor','paid_minor'] OR
   jsonb_typeof(value->'billing_status') IS DISTINCT FROM 'string' OR value->>'billing_status' NOT IN ('pending','partially_paid','paid','overdue','cancelled') OR
   jsonb_typeof(value->'currency') IS DISTINCT FROM 'string' OR value->>'currency' NOT IN ('USD','EUR','GBP','TRY','JPY','KWD') OR
   jsonb_typeof(value->'amount_minor') IS DISTINCT FROM 'string' OR value->>'amount_minor' !~ '^[1-9][0-9]{0,18}$' OR
   jsonb_typeof(value->'paid_minor') IS DISTINCT FROM 'string' OR value->>'paid_minor' !~ '^(0|[1-9][0-9]{0,18})$' THEN RETURN false; END IF;
  IF (value->>'amount_minor')::numeric>9223372036854775807 OR (value->>'paid_minor')::numeric>(value->>'amount_minor')::numeric THEN RETURN false; END IF;
 END IF;
 value:=value-ARRAY['billing_status','currency','amount_minor','paid_minor'];

 IF jsonb_typeof(value)<>'object' OR value-ARRAY['exists','revision','status','task_status','planning_status','reminder_status','reminder_scheduled_at','reminder_timezone']<>'{}'::jsonb THEN RETURN false; END IF;
 IF value ? 'exists' AND jsonb_typeof(value->'exists')<>'boolean' THEN RETURN false; END IF;
 IF value ? 'status' AND (jsonb_typeof(value->'status')<>'string' OR value->>'status' NOT IN ('active','disabled')) THEN RETURN false; END IF;
 IF value ? 'task_status' AND (jsonb_typeof(value->'task_status')<>'string' OR value->>'task_status' NOT IN ('backlog','todo','in_progress','blocked','review','done','cancelled')) THEN RETURN false; END IF;
 IF value ? 'planning_status' AND (jsonb_typeof(value->'planning_status')<>'string' OR value->>'planning_status' NOT IN ('draft','active','planned','in_progress','completed','cancelled')) THEN RETURN false; END IF;
 IF value ? 'reminder_status' AND (jsonb_typeof(value->'reminder_status')<>'string' OR value->>'reminder_status' NOT IN ('pending','completed','dismissed')) THEN RETURN false; END IF;
 IF (value ? 'reminder_scheduled_at')<>(value ? 'reminder_timezone') THEN RETURN false; END IF;
 IF value ? 'reminder_scheduled_at' THEN
  IF jsonb_typeof(value->'reminder_scheduled_at')<>'string' OR value->>'reminder_scheduled_at' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?Z$' OR
  jsonb_typeof(value->'reminder_timezone')<>'string' OR char_length(value->>'reminder_timezone')>100 OR value->>'reminder_timezone' !~ '^(UTC|[A-Za-z][A-Za-z0-9_+-]*(/[A-Za-z0-9_+-]+)+)$' OR
  NOT EXISTS(SELECT 1 FROM pg_timezone_names WHERE name=value->>'reminder_timezone') THEN RETURN false; END IF;
  scheduled:=(value->>'reminder_scheduled_at')::timestamptz;
  IF left(value->>'reminder_scheduled_at',19)<>to_char(scheduled AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS') THEN RETURN false; END IF;
  IF NOT isfinite(scheduled) OR scheduled<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR scheduled>=TIMESTAMPTZ '10000-01-01 00:00:00+00' THEN RETURN false; END IF;
 END IF;
 IF value ? 'revision' THEN
  IF jsonb_typeof(value->'revision')<>'number' OR value->>'revision' !~ '^(0|[1-9][0-9]*)$' THEN RETURN false; END IF;
  IF (value->>'revision')::numeric>9223372036854775807 THEN RETURN false; END IF;
 END IF;
 RETURN true;
EXCEPTION WHEN invalid_datetime_format OR datetime_field_overflow THEN RETURN false;
END; $$;
-- +goose StatementEnd
ALTER TABLE app.audit_events DROP CONSTRAINT audit_event_action;
ALTER TABLE app.audit_events ADD CONSTRAINT audit_event_action CHECK (
 (resource_kind NOT IN ('reminder','billing') AND (event_name IN (resource_kind||'.created',resource_kind||'.updated',resource_kind||'.archived',resource_kind||'.deleted') OR
 (resource_kind='user' AND event_name='user.disabled') OR (resource_kind='role' AND event_name='role.permission_changed') OR
 (resource_kind='task' AND event_name IN ('task.completed','task.cancelled')))) OR
 (resource_kind='reminder' AND event_name IN ('reminder.created','reminder.updated','reminder.completed','reminder.dismissed')) OR
 (resource_kind='billing' AND event_name IN ('billing.created','billing.updated','billing.payment_recorded','billing.cancelled')));
ALTER TABLE app.audit_events ADD CONSTRAINT audit_billing_snapshot_kind CHECK (
 NOT (before_state ?| ARRAY['billing_status','currency','amount_minor','paid_minor'] OR after_state ?| ARRAY['billing_status','currency','amount_minor','paid_minor']) OR resource_kind='billing');
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.audit_reader_list(actor uuid,scope_client uuid,filter_client uuid,filter_actor uuid,
 filter_actor_kind text,filter_event text,filter_kind text,filter_resource uuid,filter_request text,
 from_time timestamptz,to_time timestamptz,after_time timestamptz,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,schema_version smallint,occurred_at timestamptz,actor_kind text,actor_user_id uuid,
 event_type text,resource_kind text,resource_id uuid,client_id uuid,request_id text)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE selected_client uuid;
BEGIN
 IF NOT app.authorization_allowed(actor,'audit.view',NULL) THEN
 IF scope_client IS NOT NULL THEN RAISE no_data_found; END IF;
 RAISE EXCEPTION 'Audit access denied' USING ERRCODE='P0001'; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR
 scope_client='00000000-0000-0000-0000-000000000000'::uuid OR
 filter_client='00000000-0000-0000-0000-000000000000'::uuid OR
 filter_actor='00000000-0000-0000-0000-000000000000'::uuid OR
 filter_resource='00000000-0000-0000-0000-000000000000'::uuid OR
 (scope_client IS NOT NULL AND filter_client IS NOT NULL AND scope_client<>filter_client) OR
 (filter_actor_kind IS NOT NULL AND filter_actor_kind NOT IN ('system','user')) OR
 (filter_event IS NOT NULL AND filter_event !~ '^[a-z][a-z0-9_]{0,31}\.(created|updated|archived|deleted|disabled|permission_changed|completed|cancelled|dismissed|payment_recorded)$') OR
 (filter_event LIKE '%.payment_recorded' AND filter_event<>'billing.payment_recorded') OR
 (filter_kind IS NOT NULL AND filter_kind !~ '^[a-z][a-z0-9_]{0,31}$') OR
 (filter_request IS NOT NULL AND filter_request !~ '^[A-Z2-7]{26}$') OR
 (after_time IS NULL)<>(after_id IS NULL) OR after_id='00000000-0000-0000-0000-000000000000'::uuid OR
 (from_time IS NOT NULL AND (NOT isfinite(from_time) OR from_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR from_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (to_time IS NOT NULL AND (NOT isfinite(to_time) OR to_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR to_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (after_time IS NOT NULL AND (NOT isfinite(after_time) OR after_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR after_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) OR
 (from_time IS NOT NULL AND to_time IS NOT NULL AND from_time>=to_time) THEN RAISE invalid_parameter_value; END IF;
 selected_client:=COALESCE(scope_client,filter_client);
 IF selected_client IS NOT NULL AND (NOT app.authorization_allowed(actor,'clients.view',selected_client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=selected_client)) THEN RAISE no_data_found; END IF;
 RETURN QUERY WITH client_grants AS MATERIALIZED (
 SELECT g.scope_kind,g.client_id FROM app.authorization_grants(actor) g WHERE g.permission_key='clients.view')
 SELECT e.id,e.schema_version,e.occurred_at,e.actor_kind,e.actor_user_id,e.event_name,e.resource_kind,e.resource_id,e.client_id,e.request_id
 FROM app.audit_events e WHERE e.schema_version=1 AND
 (e.client_id IS NULL OR EXISTS(SELECT 1 FROM app.clients c WHERE c.id=e.client_id AND
 EXISTS(SELECT 1 FROM client_grants g WHERE g.scope_kind='global' OR g.client_id=e.client_id))) AND
 (selected_client IS NULL OR e.client_id=selected_client) AND
 (filter_actor IS NULL OR e.actor_user_id=filter_actor) AND (filter_actor_kind IS NULL OR e.actor_kind=filter_actor_kind) AND
 (filter_event IS NULL OR e.event_name=filter_event) AND (filter_kind IS NULL OR e.resource_kind=filter_kind) AND
 (filter_resource IS NULL OR e.resource_id=filter_resource) AND (filter_request IS NULL OR e.request_id=filter_request) AND
 (from_time IS NULL OR e.occurred_at>=from_time) AND (to_time IS NULL OR e.occurred_at<to_time) AND
 (after_time IS NULL OR (e.occurred_at,e.id)<(after_time,after_id))
 ORDER BY e.occurred_at DESC,e.id DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd


-- +goose Up
CREATE TABLE app.pricing_sheets (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 client_id uuid NOT NULL REFERENCES app.clients(id), currency text NOT NULL, currency_exponent smallint NOT NULL,
 revision bigint NOT NULL CHECK(revision>0),
 FOREIGN KEY(currency,currency_exponent) REFERENCES app.billing_currencies(code,exponent),
 UNIQUE(id,client_id,currency)
);
CREATE INDEX pricing_sheets_client ON app.pricing_sheets(client_id,id);
CREATE TABLE app.pricing_versions (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'),
 sheet_id uuid NOT NULL, client_id uuid NOT NULL, currency text NOT NULL,
 revision bigint NOT NULL CHECK(revision>0),
 title text NOT NULL CHECK(char_length(title) BETWEEN 1 AND 200 AND title=btrim(title) AND title!~'[[:cntrl:]]'),
 note text NOT NULL CHECK(char_length(note)<=2000 AND replace(note,E'\n','')!~'[[:cntrl:]]'),
 effective_from date NOT NULL CHECK(effective_from BETWEEN DATE '0001-01-01' AND DATE '9999-12-31'),
 effective_until date CHECK(effective_until>effective_from AND effective_until<=DATE '9999-12-31'),
 created_by uuid NOT NULL REFERENCES app.users(id), created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 base_minor bigint NOT NULL CHECK(base_minor>=0), discount_minor bigint NOT NULL CHECK(discount_minor>=0 AND discount_minor<=base_minor),
 net_minor bigint NOT NULL CHECK(net_minor=base_minor-discount_minor), tax_minor bigint NOT NULL CHECK(tax_minor>=0),
 total_minor bigint NOT NULL CHECK(total_minor::numeric=net_minor::numeric+tax_minor), cost_minor bigint CHECK(cost_minor>=0),
 creation_xid xid8 NOT NULL DEFAULT pg_current_xact_id(),
 FOREIGN KEY(sheet_id,client_id,currency) REFERENCES app.pricing_sheets(id,client_id,currency),
 UNIQUE(sheet_id,revision), UNIQUE(id,sheet_id,client_id,currency)
);
CREATE INDEX pricing_versions_sheet_id ON app.pricing_versions(sheet_id,id);
CREATE TABLE app.pricing_lines (
 version_id uuid NOT NULL REFERENCES app.pricing_versions(id), position integer NOT NULL CHECK(position BETWEEN 1 AND 50),
 description text NOT NULL CHECK(char_length(description) BETWEEN 1 AND 200 AND description=btrim(description) AND description!~'[[:cntrl:]]'),
 kind text NOT NULL CHECK(kind IN ('recurring','one_time','custom')),
 frequency text NOT NULL CHECK(frequency IN ('none','weekly','monthly','quarterly','yearly')),
 quantity_micros bigint NOT NULL CHECK(quantity_micros>0), unit_price_minor bigint NOT NULL CHECK(unit_price_minor>=0),
 discount_bps integer NOT NULL CHECK(discount_bps BETWEEN 0 AND 10000), tax_bps integer NOT NULL CHECK(tax_bps BETWEEN 0 AND 10000),
 unit_cost_minor bigint CHECK(unit_cost_minor>=0),
 base_minor bigint NOT NULL CHECK(base_minor::numeric=round(quantity_micros::numeric*unit_price_minor/1000000)),
 discount_minor bigint NOT NULL CHECK(discount_minor::numeric=round(base_minor::numeric*discount_bps/10000)),
 net_minor bigint NOT NULL CHECK(net_minor=base_minor-discount_minor),
 tax_minor bigint NOT NULL CHECK(tax_minor::numeric=round(net_minor::numeric*tax_bps/10000)),
 total_minor bigint NOT NULL CHECK(total_minor::numeric=net_minor::numeric+tax_minor),
 cost_minor bigint CHECK(cost_minor::numeric IS NOT DISTINCT FROM round(quantity_micros::numeric*unit_cost_minor/1000000)),
 CHECK((kind<>'recurring' OR frequency<>'none') AND (kind<>'one_time' OR frequency='none')),
 PRIMARY KEY(version_id,position)
);
CREATE TABLE app.pricing_snapshots (
 collection_id uuid PRIMARY KEY, client_id uuid NOT NULL, sheet_id uuid NOT NULL, version_id uuid NOT NULL, currency text NOT NULL,
 command_id uuid NOT NULL CHECK(command_id<>'00000000-0000-0000-0000-000000000000'),
 expected_revision bigint NOT NULL CHECK(expected_revision>0),
 created_by uuid NOT NULL REFERENCES app.users(id), created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 billing_date date NOT NULL CHECK(billing_date BETWEEN DATE '0001-01-01' AND DATE '9999-12-31'),
 original_due_date date CHECK(original_due_date BETWEEN DATE '0001-01-01' AND DATE '9999-12-31'),
 original_internal_note text NOT NULL CHECK(char_length(original_internal_note)<=8000 AND replace(original_internal_note,E'\n','')!~'[[:cntrl:]]'),
 title text NOT NULL, base_minor bigint NOT NULL, discount_minor bigint NOT NULL, net_minor bigint NOT NULL, tax_minor bigint NOT NULL, total_minor bigint NOT NULL CHECK(total_minor>0),
 creation_xid xid8 NOT NULL DEFAULT pg_current_xact_id(),
 FOREIGN KEY(collection_id,client_id,currency) REFERENCES app.collections(id,client_id,currency),
 FOREIGN KEY(version_id,sheet_id,client_id,currency) REFERENCES app.pricing_versions(id,sheet_id,client_id,currency),
 UNIQUE(client_id,command_id)
);
-- Copies deliberately contain no internal costs or pricing notes.
CREATE TABLE app.pricing_snapshot_lines (
 collection_id uuid NOT NULL REFERENCES app.pricing_snapshots(collection_id), position integer NOT NULL CHECK(position BETWEEN 1 AND 50),
 description text NOT NULL, kind text NOT NULL, frequency text NOT NULL,
 quantity_micros bigint NOT NULL, unit_price_minor bigint NOT NULL, discount_bps integer NOT NULL, tax_bps integer NOT NULL,
 base_minor bigint NOT NULL, discount_minor bigint NOT NULL, net_minor bigint NOT NULL, tax_minor bigint NOT NULL, total_minor bigint NOT NULL,
 PRIMARY KEY(collection_id,position)
);

-- +goose StatementBegin
CREATE FUNCTION app.pricing_history_guard() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF TG_TABLE_NAME='pricing_sheets' AND TG_OP='UPDATE' AND
  (NEW.id,NEW.client_id,NEW.currency,NEW.currency_exponent) IS NOT DISTINCT FROM (OLD.id,OLD.client_id,OLD.currency,OLD.currency_exponent) AND NEW.revision::numeric=OLD.revision::numeric+1 THEN RETURN NEW; END IF;
 RAISE EXCEPTION 'Pricing history is immutable' USING ERRCODE='42501';
END; $$;
-- +goose StatementEnd
CREATE TRIGGER pricing_sheet_guard BEFORE UPDATE ON app.pricing_sheets FOR EACH ROW EXECUTE FUNCTION app.pricing_history_guard();
CREATE TRIGGER pricing_sheet_removal_guard BEFORE DELETE OR TRUNCATE ON app.pricing_sheets FOR EACH STATEMENT EXECUTE FUNCTION app.pricing_history_guard();
CREATE TRIGGER pricing_version_guard BEFORE UPDATE OR DELETE OR TRUNCATE ON app.pricing_versions FOR EACH STATEMENT EXECUTE FUNCTION app.pricing_history_guard();
CREATE TRIGGER pricing_line_guard BEFORE UPDATE OR DELETE OR TRUNCATE ON app.pricing_lines FOR EACH STATEMENT EXECUTE FUNCTION app.pricing_history_guard();
CREATE TRIGGER pricing_snapshot_guard BEFORE UPDATE OR DELETE OR TRUNCATE ON app.pricing_snapshots FOR EACH STATEMENT EXECUTE FUNCTION app.pricing_history_guard();
CREATE TRIGGER pricing_snapshot_line_guard BEFORE UPDATE OR DELETE OR TRUNCATE ON app.pricing_snapshot_lines FOR EACH STATEMENT EXECUTE FUNCTION app.pricing_history_guard();
ALTER TABLE app.pricing_sheets ENABLE ALWAYS TRIGGER pricing_sheet_guard;
ALTER TABLE app.pricing_sheets ENABLE ALWAYS TRIGGER pricing_sheet_removal_guard;
ALTER TABLE app.pricing_versions ENABLE ALWAYS TRIGGER pricing_version_guard;
ALTER TABLE app.pricing_lines ENABLE ALWAYS TRIGGER pricing_line_guard;
ALTER TABLE app.pricing_snapshots ENABLE ALWAYS TRIGGER pricing_snapshot_guard;
ALTER TABLE app.pricing_snapshot_lines ENABLE ALWAYS TRIGGER pricing_snapshot_line_guard;

-- A zero-valued later line would leave aggregate totals unchanged. Bind all
-- lines to their header's creation transaction as well as checking exact sums.
-- +goose StatementBegin
CREATE FUNCTION app.pricing_insert_guard() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE original_xid xid8; previous_day date; latest bigint;
BEGIN
 IF TG_TABLE_NAME='pricing_versions' THEN
  SELECT revision INTO latest FROM app.pricing_sheets WHERE id=NEW.sheet_id FOR UPDATE;
  SELECT effective_from INTO previous_day FROM app.pricing_versions WHERE sheet_id=NEW.sheet_id AND revision=NEW.revision-1;
  IF NEW.revision IS DISTINCT FROM latest OR (NEW.revision>1 AND (previous_day IS NULL OR NEW.effective_from<previous_day OR NEW.effective_from<(statement_timestamp() AT TIME ZONE 'UTC')::date)) OR NEW.creation_xid<>pg_current_xact_id() THEN RAISE check_violation; END IF;
  RETURN NEW;
 ELSIF TG_TABLE_NAME='pricing_lines' THEN SELECT creation_xid INTO original_xid FROM app.pricing_versions WHERE id=NEW.version_id;
 ELSE SELECT creation_xid INTO original_xid FROM app.pricing_snapshots WHERE collection_id=NEW.collection_id; END IF;
 IF original_xid IS DISTINCT FROM pg_current_xact_id() THEN RAISE EXCEPTION 'Pricing lines are immutable after creation' USING ERRCODE='42501'; END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
CREATE TRIGGER pricing_version_insert_guard BEFORE INSERT ON app.pricing_versions FOR EACH ROW EXECUTE FUNCTION app.pricing_insert_guard();
CREATE TRIGGER pricing_line_insert_guard BEFORE INSERT ON app.pricing_lines FOR EACH ROW EXECUTE FUNCTION app.pricing_insert_guard();
CREATE TRIGGER pricing_snapshot_line_insert_guard BEFORE INSERT ON app.pricing_snapshot_lines FOR EACH ROW EXECUTE FUNCTION app.pricing_insert_guard();
ALTER TABLE app.pricing_versions ENABLE ALWAYS TRIGGER pricing_version_insert_guard;
ALTER TABLE app.pricing_lines ENABLE ALWAYS TRIGGER pricing_line_insert_guard;
ALTER TABLE app.pricing_snapshot_lines ENABLE ALWAYS TRIGGER pricing_snapshot_line_insert_guard;

-- +goose StatementBegin
CREATE FUNCTION app.pricing_amount_guard() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.amount_minor<>OLD.amount_minor AND EXISTS(SELECT 1 FROM app.pricing_snapshots WHERE collection_id=OLD.id) THEN
  RAISE EXCEPTION 'Copied collection amount is immutable' USING ERRCODE='P0001'; END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
CREATE TRIGGER pricing_collection_amount_guard BEFORE UPDATE ON app.collections FOR EACH ROW EXECUTE FUNCTION app.pricing_amount_guard();
ALTER TABLE app.collections ENABLE ALWAYS TRIGGER pricing_collection_amount_guard;

-- +goose StatementBegin
CREATE FUNCTION app.pricing_consistency_guard() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE target uuid; v app.pricing_versions%ROWTYPE; p app.pricing_snapshots%ROWTYPE; s app.pricing_sheets%ROWTYPE; totals record;
BEGIN
 IF TG_TABLE_NAME IN ('pricing_sheets','pricing_versions','pricing_lines') THEN
  IF TG_TABLE_NAME='pricing_sheets' THEN SELECT * INTO v FROM app.pricing_versions WHERE sheet_id=NEW.id ORDER BY revision DESC LIMIT 1;
  ELSIF TG_TABLE_NAME='pricing_versions' THEN SELECT * INTO v FROM app.pricing_versions WHERE id=NEW.id;
  ELSE SELECT * INTO v FROM app.pricing_versions WHERE id=NEW.version_id; END IF;
  IF v.id IS NULL THEN RAISE check_violation; END IF;
  SELECT * INTO s FROM app.pricing_sheets WHERE id=v.sheet_id FOR UPDATE;
  IF s.revision<>(SELECT max(revision) FROM app.pricing_versions WHERE sheet_id=s.id) OR
   s.revision<>(SELECT count(*) FROM app.pricing_versions WHERE sheet_id=s.id) OR
   EXISTS(SELECT 1 FROM app.pricing_versions a JOIN app.pricing_versions b ON b.sheet_id=a.sheet_id AND b.revision=a.revision-1 WHERE a.sheet_id=s.id AND a.effective_from<b.effective_from) THEN RAISE check_violation; END IF;
  SELECT count(*) AS count,max(position) AS last,sum(base_minor::numeric) AS base,sum(discount_minor::numeric) AS discount,sum(net_minor::numeric) AS net,sum(tax_minor::numeric) AS tax,sum(total_minor::numeric) AS total,
   CASE WHEN count(cost_minor)=count(*) THEN sum(cost_minor::numeric) END AS cost,sum(cost_minor::numeric) AS known_cost INTO totals FROM app.pricing_lines WHERE version_id=v.id;
  IF totals.count NOT BETWEEN 1 AND 50 OR totals.last<>totals.count OR coalesce(totals.known_cost,0)>9223372036854775807 OR
   (v.base_minor::numeric,v.discount_minor::numeric,v.net_minor::numeric,v.tax_minor::numeric,v.total_minor::numeric,v.cost_minor::numeric) IS DISTINCT FROM (totals.base,totals.discount,totals.net,totals.tax,totals.total,totals.cost) THEN RAISE check_violation; END IF;
 ELSE
  target:=NEW.collection_id;
  SELECT * INTO p FROM app.pricing_snapshots WHERE collection_id=target;
  SELECT * INTO v FROM app.pricing_versions WHERE id=p.version_id;
  IF (p.title,p.base_minor,p.discount_minor,p.net_minor,p.tax_minor,p.total_minor) IS DISTINCT FROM (v.title,v.base_minor,v.discount_minor,v.net_minor,v.tax_minor,v.total_minor) OR
   p.billing_date>(statement_timestamp() AT TIME ZONE 'UTC')::date OR
   NOT EXISTS(SELECT 1 FROM app.collections WHERE id=target AND amount_minor=p.total_minor) OR
   (SELECT count(*) FROM app.pricing_snapshot_lines WHERE collection_id=target)<>(SELECT count(*) FROM app.pricing_lines WHERE version_id=v.id) OR
   EXISTS(SELECT 1 FROM app.pricing_snapshot_lines l LEFT JOIN app.pricing_lines original ON original.version_id=v.id AND original.position=l.position
    WHERE l.collection_id=target AND (l.position,l.description,l.kind,l.frequency,l.quantity_micros,l.unit_price_minor,l.discount_bps,l.tax_bps,l.base_minor,l.discount_minor,l.net_minor,l.tax_minor,l.total_minor) IS DISTINCT FROM
    (original.position,original.description,original.kind,original.frequency,original.quantity_micros,original.unit_price_minor,original.discount_bps,original.tax_bps,original.base_minor,original.discount_minor,original.net_minor,original.tax_minor,original.total_minor)) THEN RAISE check_violation; END IF;
 END IF;
 RETURN NULL;
END; $$;
-- +goose StatementEnd
CREATE CONSTRAINT TRIGGER pricing_sheet_consistency AFTER INSERT OR UPDATE ON app.pricing_sheets DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.pricing_consistency_guard();
CREATE CONSTRAINT TRIGGER pricing_version_consistency AFTER INSERT ON app.pricing_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.pricing_consistency_guard();
CREATE CONSTRAINT TRIGGER pricing_line_consistency AFTER INSERT ON app.pricing_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.pricing_consistency_guard();
CREATE CONSTRAINT TRIGGER pricing_snapshot_consistency AFTER INSERT ON app.pricing_snapshots DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.pricing_consistency_guard();
CREATE CONSTRAINT TRIGGER pricing_snapshot_line_consistency AFTER INSERT ON app.pricing_snapshot_lines DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION app.pricing_consistency_guard();
ALTER TABLE app.pricing_sheets ENABLE ALWAYS TRIGGER pricing_sheet_consistency;
ALTER TABLE app.pricing_versions ENABLE ALWAYS TRIGGER pricing_version_consistency;
ALTER TABLE app.pricing_lines ENABLE ALWAYS TRIGGER pricing_line_consistency;
ALTER TABLE app.pricing_snapshots ENABLE ALWAYS TRIGGER pricing_snapshot_consistency;
ALTER TABLE app.pricing_snapshot_lines ENABLE ALWAYS TRIGGER pricing_snapshot_line_consistency;

-- Canonical string parsing precedes every numeric/date cast. No floating point.
-- +goose StatementBegin
CREATE FUNCTION app.pricing_integer(value jsonb,positive boolean,maximum numeric DEFAULT 9223372036854775807) RETURNS bigint
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $$
DECLARE result numeric;
BEGIN
 IF jsonb_typeof(value) IS DISTINCT FROM 'string' OR value#>>'{}' !~ '^(0|[1-9][0-9]{0,18})$' THEN RAISE invalid_parameter_value; END IF;
 result:=(value#>>'{}')::numeric;
 IF result>maximum OR (positive AND result=0) THEN RAISE invalid_parameter_value; END IF;
 RETURN result::bigint;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_date(value jsonb,optional boolean) RETURNS date
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $$
DECLARE result date;
BEGIN
 IF optional AND (value IS NULL OR value='null'::jsonb) THEN RETURN NULL; END IF;
 IF jsonb_typeof(value) IS DISTINCT FROM 'string' OR value#>>'{}' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' THEN RAISE invalid_parameter_value; END IF;
 result:=(value#>>'{}')::date;
 IF result NOT BETWEEN DATE '0001-01-01' AND DATE '9999-12-31' OR to_char(result,'YYYY-MM-DD')<>value#>>'{}' THEN RAISE invalid_parameter_value; END IF;
 RETURN result;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_calculate(profile jsonb) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE l jsonb; lines jsonb:='[]'::jsonb; exponent smallint; q bigint; u bigint; d bigint; t bigint; c bigint;
 b numeric; discount numeric; net numeric; tax numeric; total numeric; cost numeric;
 sb numeric:=0; sd numeric:=0; sn numeric:=0; st numeric:=0; sa numeric:=0; sc numeric:=0; known boolean:=true; start_day date; end_day date;
BEGIN
 IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR profile-ARRAY['title','note','currency','effective_from','effective_until','lines']<>'{}'::jsonb OR
  jsonb_typeof(profile->'title') IS DISTINCT FROM 'string' OR char_length(profile->>'title') NOT BETWEEN 1 AND 200 OR profile->>'title'<>btrim(profile->>'title') OR profile->>'title'~'[[:cntrl:]]' OR
  jsonb_typeof(profile->'note') IS DISTINCT FROM 'string' OR char_length(profile->>'note')>2000 OR replace(profile->>'note',E'\n','')~'[[:cntrl:]]' OR
  jsonb_typeof(profile->'currency') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'lines') IS DISTINCT FROM 'array' THEN RAISE invalid_parameter_value; END IF;
 IF jsonb_array_length(profile->'lines') NOT BETWEEN 1 AND 50 THEN RAISE invalid_parameter_value; END IF;
 SELECT bc.exponent INTO exponent FROM app.billing_currencies bc WHERE bc.code=profile->>'currency';
 IF NOT FOUND THEN RAISE invalid_parameter_value; END IF;
 start_day:=app.pricing_date(profile->'effective_from',false);end_day:=app.pricing_date(profile->'effective_until',true);
 IF end_day<=start_day THEN RAISE invalid_parameter_value; END IF;
 FOR l IN SELECT value FROM jsonb_array_elements(profile->'lines') LOOP
  IF jsonb_typeof(l)<>'object' OR l-ARRAY['description','kind','frequency','quantity_micros','unit_price_minor','discount_bps','tax_bps','unit_cost_minor']<>'{}'::jsonb OR
   jsonb_typeof(l->'description') IS DISTINCT FROM 'string' OR char_length(l->>'description') NOT BETWEEN 1 AND 200 OR l->>'description'<>btrim(l->>'description') OR l->>'description'~'[[:cntrl:]]' OR
   jsonb_typeof(l->'kind') IS DISTINCT FROM 'string' OR l->>'kind' NOT IN ('recurring','one_time','custom') OR
   jsonb_typeof(l->'frequency') IS DISTINCT FROM 'string' OR l->>'frequency' NOT IN ('none','weekly','monthly','quarterly','yearly') OR
   (l->>'kind'='recurring' AND l->>'frequency'='none') OR (l->>'kind'='one_time' AND l->>'frequency'<>'none') THEN RAISE invalid_parameter_value; END IF;
  q:=app.pricing_integer(l->'quantity_micros',true);u:=app.pricing_integer(l->'unit_price_minor',false);
  d:=app.pricing_integer(l->'discount_bps',false,10000);t:=app.pricing_integer(l->'tax_bps',false,10000);
  c:=NULL;IF l->'unit_cost_minor' IS NOT NULL AND l->'unit_cost_minor'<>'null'::jsonb THEN c:=app.pricing_integer(l->'unit_cost_minor',false); ELSE known:=false; END IF;
  b:=round(q::numeric*u/1000000);discount:=round(b*d/10000);net:=b-discount;tax:=round(net*t/10000);total:=net+tax;cost:=round(q::numeric*c/1000000);
  sb:=sb+b;sd:=sd+discount;sn:=sn+net;st:=st+tax;sa:=sa+total;sc:=sc+coalesce(cost,0);
  IF greatest(sb,sd,sn,st,sa,sc)>9223372036854775807 THEN RAISE numeric_value_out_of_range; END IF;
  lines:=lines||jsonb_build_array(l||jsonb_build_object('position',jsonb_array_length(lines)+1,'base_minor',b::bigint::text,'discount_minor',discount::bigint::text,'net_minor',net::bigint::text,'tax_minor',tax::bigint::text,'total_minor',total::bigint::text,'cost_minor',cost::bigint::text));
 END LOOP;
 RETURN jsonb_build_object('currency',profile->>'currency','currency_exponent',exponent,'lines',lines,'base_minor',sb::bigint::text,'discount_minor',sd::bigint::text,'net_minor',sn::bigint::text,'tax_minor',st::bigint::text,'total_minor',sa::bigint::text,'cost_minor',CASE WHEN known THEN sc::bigint::text END);
END; $$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.pricing_version_document(target uuid,include_cost boolean) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('id',v.id,'sheet_id',v.sheet_id,'client_id',v.client_id,'revision',v.revision::text,'title',v.title,'note',v.note,
  'effective_from',to_char(v.effective_from,'YYYY-MM-DD'),'effective_until',to_char(v.effective_until,'YYYY-MM-DD'),
  'window_until',to_char(least(v.effective_until,(SELECT n.effective_from FROM app.pricing_versions n WHERE n.sheet_id=v.sheet_id AND n.revision=v.revision+1)),'YYYY-MM-DD'),
  'created_by',v.created_by,'created_at',v.created_at,'currency',v.currency,'currency_exponent',s.currency_exponent,
  'base_minor',v.base_minor::text,'discount_minor',v.discount_minor::text,'net_minor',v.net_minor::text,'tax_minor',v.tax_minor::text,'total_minor',v.total_minor::text,
  'lines',coalesce((SELECT jsonb_agg((jsonb_build_object('position',l.position,'description',l.description,'kind',l.kind,'frequency',l.frequency,'quantity_micros',l.quantity_micros::text,'unit_price_minor',l.unit_price_minor::text,'discount_bps',l.discount_bps::text,'tax_bps',l.tax_bps::text,'base_minor',l.base_minor::text,'discount_minor',l.discount_minor::text,'net_minor',l.net_minor::text,'tax_minor',l.tax_minor::text,'total_minor',l.total_minor::text)||CASE WHEN include_cost THEN jsonb_build_object('unit_cost_minor',l.unit_cost_minor::text,'cost_minor',l.cost_minor::text) ELSE '{}'::jsonb END) ORDER BY position) FROM app.pricing_lines l WHERE l.version_id=v.id),'[]'::jsonb))
  ||CASE WHEN include_cost THEN jsonb_build_object('cost_minor',v.cost_minor::text) ELSE '{}'::jsonb END
 FROM app.pricing_versions v JOIN app.pricing_sheets s ON s.id=v.sheet_id WHERE v.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_read(actor uuid,client uuid,target uuid,version uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE s app.pricing_sheets%ROWTYPE; v uuid; costs boolean;
BEGIN
 IF NOT app.authorization_allowed(actor,'pricing.view',client) THEN RETURN NULL; END IF;
 SELECT * INTO s FROM app.pricing_sheets WHERE id=target AND client_id=client;
 IF NOT FOUND THEN RETURN NULL; END IF;
 costs:=app.authorization_allowed(actor,'pricing.manage',client);
 IF version IS NOT NULL THEN
  IF NOT EXISTS(SELECT 1 FROM app.pricing_versions WHERE id=version AND sheet_id=target) THEN RETURN NULL; END IF;
  RETURN app.pricing_version_document(version,costs);
 END IF;
 SELECT id INTO v FROM app.pricing_versions WHERE sheet_id=target AND revision=s.revision;
 RETURN jsonb_build_object('id',s.id,'client_id',s.client_id,'revision',s.revision::text,'latest_version',app.pricing_version_document(v,costs));
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_list(actor uuid,client uuid,target uuid,after_id uuid,page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'pricing.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) OR
  (target IS NOT NULL AND NOT EXISTS(SELECT 1 FROM app.pricing_sheets WHERE id=target AND client_id=client)) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
 IF target IS NULL THEN RETURN QUERY SELECT app.pricing_read(actor,client,s.id,NULL) FROM app.pricing_sheets s WHERE s.client_id=client AND (after_id IS NULL OR s.id>after_id) ORDER BY s.id LIMIT page_limit;
 ELSE RETURN QUERY SELECT app.pricing_version_document(v.id,app.authorization_allowed(actor,'pricing.manage',client)) FROM app.pricing_versions v WHERE v.sheet_id=target AND (after_id IS NULL OR v.id>after_id) ORDER BY v.id LIMIT page_limit; END IF;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_preview(actor uuid,client uuid,profile jsonb) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NOT app.authorization_allowed(actor,'pricing.view',client) OR NOT app.authorization_allowed(actor,'pricing.manage',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) THEN RAISE EXCEPTION 'Archived client' USING ERRCODE='P0001'; END IF;
 RETURN app.pricing_calculate(profile);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_write(actor uuid,client uuid,target uuid,version uuid,expected bigint,profile jsonb)
RETURNS TABLE(code text,before_state jsonb,after_state jsonb,new_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE s app.pricing_sheets%ROWTYPE; calc jsonb; l jsonb; rev bigint; start_day date; last_day date;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'pricing.view',client) OR NOT app.authorization_allowed(actor,'pricing.manage',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF target IS NULL OR version IS NULL OR target='00000000-0000-0000-0000-000000000000' OR version='00000000-0000-0000-0000-000000000000' OR expected IS NULL OR expected<0 OR expected=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 IF EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) THEN RAISE EXCEPTION 'Archived client' USING ERRCODE='P0001'; END IF;
 calc:=app.pricing_calculate(profile);start_day:=app.pricing_date(profile->'effective_from',false);rev:=expected+1;
 IF expected=0 THEN
  INSERT INTO app.pricing_sheets VALUES(target,client,profile->>'currency',(calc->>'currency_exponent')::smallint,1);
 ELSE
  SELECT * INTO s FROM app.pricing_sheets WHERE id=target AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RAISE no_data_found; END IF;
  SELECT effective_from INTO last_day FROM app.pricing_versions WHERE sheet_id=target AND revision=s.revision;
  IF s.revision<>expected OR s.currency<>profile->>'currency' OR start_day<last_day OR start_day<(statement_timestamp() AT TIME ZONE 'UTC')::date THEN RAISE EXCEPTION 'Stale revision or pricing window' USING ERRCODE='P0001'; END IF;
  UPDATE app.pricing_sheets SET revision=rev WHERE id=target;
 END IF;
 INSERT INTO app.pricing_versions(id,sheet_id,client_id,currency,revision,title,note,effective_from,effective_until,created_by,base_minor,discount_minor,net_minor,tax_minor,total_minor,cost_minor)
 VALUES(version,target,client,profile->>'currency',rev,profile->>'title',profile->>'note',start_day,app.pricing_date(profile->'effective_until',true),actor,(calc->>'base_minor')::bigint,(calc->>'discount_minor')::bigint,(calc->>'net_minor')::bigint,(calc->>'tax_minor')::bigint,(calc->>'total_minor')::bigint,(calc->>'cost_minor')::bigint);
 FOR l IN SELECT value FROM jsonb_array_elements(calc->'lines') LOOP
  INSERT INTO app.pricing_lines VALUES(version,(l->>'position')::integer,l->>'description',l->>'kind',l->>'frequency',(l->>'quantity_micros')::bigint,(l->>'unit_price_minor')::bigint,(l->>'discount_bps')::integer,(l->>'tax_bps')::integer,(l->>'unit_cost_minor')::bigint,(l->>'base_minor')::bigint,(l->>'discount_minor')::bigint,(l->>'net_minor')::bigint,(l->>'tax_minor')::bigint,(l->>'total_minor')::bigint,(l->>'cost_minor')::bigint);
 END LOOP;
 RETURN QUERY SELECT 'ok'::text,CASE WHEN expected=0 THEN 'null'::jsonb ELSE jsonb_build_object('exists',true,'revision',expected) END,jsonb_build_object('exists',true,'revision',rev),rev;
END; $$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.pricing_copy(actor uuid,client uuid,target uuid,version uuid,expected bigint,profile jsonb,new_collection uuid)
RETURNS TABLE(code text,before_state jsonb,after_state jsonb,collection_id uuid,new_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE s app.pricing_sheets%ROWTYPE; v app.pricing_versions%ROWTYPE; prior app.pricing_snapshots%ROWTYPE; command uuid; day date; due date; result record;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'pricing.view',client) OR NOT app.authorization_allowed(actor,'billing.view',client) OR NOT app.authorization_allowed(actor,'billing.create',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF expected IS NULL OR expected<1 OR profile IS NULL OR jsonb_typeof(profile)<>'object' OR profile-ARRAY['command_id','billing_date','due_date','internal_note']<>'{}'::jsonb OR
  jsonb_typeof(profile->'command_id') IS DISTINCT FROM 'string' OR profile->>'command_id' !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' OR
  jsonb_typeof(profile->'internal_note') IS DISTINCT FROM 'string' OR char_length(profile->>'internal_note')>8000 OR replace(profile->>'internal_note',E'\n','')~'[[:cntrl:]]' THEN RAISE invalid_parameter_value; END IF;
 command:=(profile->>'command_id')::uuid;day:=app.pricing_date(profile->'billing_date',false);due:=app.pricing_date(profile->'due_date',true);
 IF command='00000000-0000-0000-0000-000000000000' OR day>(statement_timestamp() AT TIME ZONE 'UTC')::date THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO prior FROM app.pricing_snapshots WHERE client_id=client AND command_id=command;
 IF FOUND THEN
  IF (prior.created_by,prior.sheet_id,prior.version_id,prior.expected_revision,prior.billing_date,prior.original_due_date,prior.original_internal_note) IS DISTINCT FROM (actor,target,version,expected,day,due,profile->>'internal_note') THEN RAISE EXCEPTION 'Command reused' USING ERRCODE='P0001'; END IF;
  RETURN QUERY SELECT 'replay'::text,NULL::jsonb,NULL::jsonb,prior.collection_id,c.revision FROM app.collections c WHERE c.id=prior.collection_id;RETURN;
 END IF;
 SELECT * INTO s FROM app.pricing_sheets WHERE id=target AND client_id=client FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 SELECT * INTO v FROM app.pricing_versions WHERE id=version AND sheet_id=target;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF s.revision<>expected OR v.total_minor<=0 OR EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NOT NULL) OR
  v.effective_from>day OR v.effective_until<=day OR
  v.revision<>(SELECT max(revision) FROM app.pricing_versions WHERE sheet_id=target AND effective_from<=day) THEN RAISE EXCEPTION 'Stale revision or inactive pricing' USING ERRCODE='P0001'; END IF;
 SELECT * INTO result FROM app.billing_write(actor,client,new_collection,0,'create',jsonb_build_object('description',v.title,'internal_note',profile->>'internal_note','amount_minor',v.total_minor::text,'currency',v.currency,'due_date',to_char(due,'YYYY-MM-DD')),NULL);
 IF result.code<>'ok' THEN RAISE EXCEPTION 'Collection cannot be created' USING ERRCODE='P0001'; END IF;
 INSERT INTO app.pricing_snapshots VALUES(new_collection,client,target,version,v.currency,command,expected,actor,clock_timestamp(),day,due,profile->>'internal_note',v.title,v.base_minor,v.discount_minor,v.net_minor,v.tax_minor,v.total_minor);
 INSERT INTO app.pricing_snapshot_lines SELECT new_collection,position,description,kind,frequency,quantity_micros,unit_price_minor,discount_bps,tax_bps,base_minor,discount_minor,net_minor,tax_minor,total_minor FROM app.pricing_lines WHERE version_id=version;
 RETURN QUERY SELECT 'ok'::text,result.before_state,result.after_state,new_collection,result.new_revision;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.pricing_snapshot_read(actor uuid,client uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE result jsonb;
BEGIN
 IF NOT app.authorization_allowed(actor,'billing.view',client) THEN RETURN NULL; END IF;
 SELECT jsonb_build_object('collection_id',p.collection_id,'client_id',p.client_id,'sheet_id',p.sheet_id,'version_id',p.version_id,'pricing_revision',v.revision::text,'command_id',p.command_id,'billing_date',to_char(p.billing_date,'YYYY-MM-DD'),'title',p.title,'created_by',p.created_by,'created_at',p.created_at,'currency',p.currency,'currency_exponent',s.currency_exponent,
  'base_minor',p.base_minor::text,'discount_minor',p.discount_minor::text,'net_minor',p.net_minor::text,'tax_minor',p.tax_minor::text,'total_minor',p.total_minor::text,
  'lines',(SELECT jsonb_agg(jsonb_build_object('position',l.position,'description',l.description,'kind',l.kind,'frequency',l.frequency,'quantity_micros',l.quantity_micros::text,'unit_price_minor',l.unit_price_minor::text,'discount_bps',l.discount_bps::text,'tax_bps',l.tax_bps::text,'base_minor',l.base_minor::text,'discount_minor',l.discount_minor::text,'net_minor',l.net_minor::text,'tax_minor',l.tax_minor::text,'total_minor',l.total_minor::text) ORDER BY l.position) FROM app.pricing_snapshot_lines l WHERE l.collection_id=target)) INTO result
 FROM app.pricing_snapshots p JOIN app.pricing_versions v ON v.id=p.version_id JOIN app.pricing_sheets s ON s.id=p.sheet_id WHERE p.collection_id=target AND p.client_id=client;
 RETURN result;
END; $$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION app.pricing_history_guard(),app.pricing_insert_guard(),app.pricing_amount_guard(),app.pricing_consistency_guard(),app.pricing_integer(jsonb,boolean,numeric),app.pricing_date(jsonb,boolean),app.pricing_calculate(jsonb),app.pricing_version_document(uuid,boolean),
 app.pricing_read(uuid,uuid,uuid,uuid),app.pricing_list(uuid,uuid,uuid,uuid,integer),app.pricing_preview(uuid,uuid,jsonb),app.pricing_write(uuid,uuid,uuid,uuid,bigint,jsonb),app.pricing_copy(uuid,uuid,uuid,uuid,bigint,jsonb,uuid),app.pricing_snapshot_read(uuid,uuid,uuid) FROM PUBLIC;


-- +goose Up
-- Earliest due work needs a deadline index; reminder/activity/finance indexes
-- already support their respective projections. No stored aggregate is added.
CREATE INDEX tasks_open_due ON app.tasks(client_id,due_at,id)
 WHERE archived_at IS NULL AND status NOT IN ('done','cancelled') AND due_at IS NOT NULL;

-- One bounded runtime entrypoint. Guarded writers use the exclusive form of
-- this lifecycle lock; shared readers can run together and observe queued
-- revocations before returning any private module data.
-- +goose StatementBegin
CREATE FUNCTION app.client_overview(actor uuid,client uuid) RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE result jsonb; module jsonb; sample jsonb; bucket text;
 stamp timestamptz:=statement_timestamp(); horizon timestamptz:=statement_timestamp()+INTERVAL '7 days';
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) THEN RAISE no_data_found; END IF;
 SELECT jsonb_build_object('client',jsonb_build_object('id',c.id,'name',c.name,
  'status',CASE WHEN c.archived_at IS NULL THEN 'active' ELSE 'archived' END,'archived_at',c.archived_at),
  'as_of',stamp,'horizon_end',horizon) INTO result FROM app.clients c WHERE c.id=client;
 IF result IS NULL THEN RAISE no_data_found; END IF;

 IF app.authorization_allowed(actor,'billing.view',client) THEN
  SELECT jsonb_build_object('currencies',coalesce(jsonb_agg(v ORDER BY v->>'currency'),'[]'::jsonb))
   INTO module FROM app.billing_summary(actor,client) v;
  result:=result||jsonb_build_object('finance',module);
 END IF;

 IF app.authorization_allowed(actor,'tasks.view',client) THEN
  module:='{}'::jsonb;
  FOREACH bucket IN ARRAY ARRAY['overdue','due_soon'] LOOP
   WITH candidates AS MATERIALIZED (
    SELECT t.id,t.title,t.status,t.priority,t.due_at FROM app.tasks t
    WHERE t.client_id=client AND t.archived_at IS NULL AND t.status NOT IN ('done','cancelled') AND t.due_at IS NOT NULL
     AND t.due_at>CASE WHEN bucket='overdue' THEN '-infinity'::timestamptz ELSE stamp END
     AND t.due_at<=CASE WHEN bucket='overdue' THEN stamp ELSE horizon END
    ORDER BY t.due_at,t.id LIMIT 6
   ) SELECT jsonb_build_object('items',coalesce((SELECT jsonb_agg(to_jsonb(v) ORDER BY v.due_at,v.id)
     FROM (SELECT * FROM candidates ORDER BY due_at,id LIMIT 5) v),'[]'::jsonb),
     'has_more',(SELECT count(*)>5 FROM candidates)) INTO sample;
   module:=module||jsonb_build_object(bucket,sample);
  END LOOP;
  result:=result||jsonb_build_object('tasks',module);
 END IF;

 IF app.authorization_allowed(actor,'reminders.view',client) THEN
  module:='{}'::jsonb;
  FOREACH bucket IN ARRAY ARRAY['due','upcoming'] LOOP
   WITH candidates AS MATERIALIZED (
    SELECT r.id,r.title,r.scheduled_at,r.timezone FROM app.reminders r
    WHERE r.client_id=client AND r.status='pending'
     AND r.scheduled_at>CASE WHEN bucket='due' THEN '-infinity'::timestamptz ELSE stamp END
     AND r.scheduled_at<=CASE WHEN bucket='due' THEN stamp ELSE horizon END
    ORDER BY r.scheduled_at,r.id LIMIT 6
   ) SELECT jsonb_build_object('items',coalesce((SELECT jsonb_agg(to_jsonb(v) ORDER BY v.scheduled_at,v.id)
     FROM (SELECT * FROM candidates ORDER BY scheduled_at,id LIMIT 5) v),'[]'::jsonb),
     'has_more',(SELECT count(*)>5 FROM candidates)) INTO sample;
   module:=module||jsonb_build_object(bucket,sample);
  END LOOP;
  result:=result||jsonb_build_object('reminders',module);
 END IF;

 IF app.authorization_allowed(actor,'activity.view',client) THEN
  WITH candidates AS MATERIALIZED (SELECT * FROM app.activity_list(actor,client,NULL,NULL,6))
  SELECT jsonb_build_object('items',coalesce((SELECT jsonb_agg(to_jsonb(v) ORDER BY v.occurred_at DESC,v.id DESC)
   FROM (SELECT * FROM candidates ORDER BY occurred_at DESC,id DESC LIMIT 5) v),'[]'::jsonb),
   'has_more',(SELECT count(*)>5 FROM candidates)) INTO module;
  result:=result||jsonb_build_object('activity',module);
 END IF;
 RETURN result;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.client_overview(uuid,uuid) FROM PUBLIC;


-- +goose Up
INSERT INTO app.permissions(permission_key,scope_kind,description)
 VALUES ('integrations.view','client','View authorized integration connection metadata');
INSERT INTO app.role_permissions(id,role_id,permission_key,seeded)
 VALUES (gen_random_uuid(),'00000000-0000-4000-8000-000000000001','integrations.view',true);

-- Metadata only. Credential storage and verified lifecycle writers follow in
-- separate slices. No production/demo connection or provider success is seeded.
CREATE TABLE app.integration_connections (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'::uuid),
 client_id uuid NOT NULL REFERENCES app.clients(id) ON DELETE RESTRICT,
 provider text NOT NULL CHECK(provider='meta_ads'),
 provider_account_id text NOT NULL CHECK(provider_account_id ~ '^[1-9][0-9]{0,31}$'),
 state text NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','connected','disconnect_pending','revocation_failed','disconnected','reauthorization_required')),
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 generation bigint NOT NULL DEFAULT 1 CHECK(generation>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp()
  CHECK(created_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND created_at<TIMESTAMPTZ '10000-01-01 00:00:00+00'),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
  CHECK(updated_at>=created_at AND updated_at<TIMESTAMPTZ '10000-01-01 00:00:00+00'),
 UNIQUE(provider,provider_account_id)
);
CREATE INDEX integration_connections_client_id ON app.integration_connections(client_id,id);

-- +goose StatementBegin
CREATE FUNCTION app.integration_connection_ownership_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog AS $$
BEGIN
 IF (NEW.id,NEW.client_id,NEW.provider,NEW.provider_account_id,NEW.created_at) IS DISTINCT FROM
    (OLD.id,OLD.client_id,OLD.provider,OLD.provider_account_id,OLD.created_at) THEN
  RAISE invalid_parameter_value USING MESSAGE='Integration ownership is immutable';
 END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_connection_ownership_guard() FROM PUBLIC;
CREATE TRIGGER integration_connection_ownership BEFORE UPDATE ON app.integration_connections
 FOR EACH ROW EXECUTE FUNCTION app.integration_connection_ownership_guard();

-- Reads wait behind exclusive lifecycle writers before performing fresh checks.
-- Only explicit safe columns cross the runtime boundary. Account IDs and
-- generation remain private; no SELECT privilege is granted on the table.
-- +goose StatementBegin
CREATE FUNCTION app.integration_connection_list(actor uuid,client uuid,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR
 after_id='00000000-0000-0000-0000-000000000000'::uuid THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at
 FROM app.integration_connections c WHERE c.client_id=client AND (after_id IS NULL OR c.id>after_id)
 ORDER BY c.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_connection_list(uuid,uuid,uuid,integer) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.integration_connection_read(actor uuid,client uuid,connection uuid)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at
 FROM app.integration_connections c WHERE c.client_id=client AND c.id=connection;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_connection_read(uuid,uuid,uuid) FROM PUBLIC;


-- +goose Up
-- Private per-material accounting in one authoritative database. No keys,
-- plaintext or ciphertext. Restore/clone requires fresh material before sealing.
CREATE TABLE app.integration_encryption_keys (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid() CHECK(id<>'00000000-0000-0000-0000-000000000000'::uuid),
 key_label text NOT NULL UNIQUE CHECK(key_label ~ '^[a-z0-9][a-z0-9_-]{0,63}$'),
 fingerprint bytea NOT NULL UNIQUE CHECK(octet_length(fingerprint)=32 AND fingerprint<>decode(repeat('00',32),'hex')),
 reservations bigint NOT NULL DEFAULT 0 CHECK(reservations BETWEEN 0 AND 16777216),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp()
  CHECK(created_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND created_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')
);
REVOKE ALL ON app.integration_encryption_keys FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.integration_encryption_history_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog AS $$
BEGIN
 IF TG_OP<>'UPDATE' THEN RAISE EXCEPTION 'Encryption accounting history is retained'; END IF;
 IF (NEW.id,NEW.key_label,NEW.fingerprint,NEW.created_at) IS DISTINCT FROM
 (OLD.id,OLD.key_label,OLD.fingerprint,OLD.created_at) OR NEW.reservations<>OLD.reservations+1 THEN
  RAISE EXCEPTION 'Encryption accounting identity and monotonic count are immutable';
 END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_encryption_history_guard() FROM PUBLIC;
CREATE TRIGGER integration_encryption_history BEFORE UPDATE OR DELETE ON app.integration_encryption_keys
 FOR EACH ROW EXECUTE FUNCTION app.integration_encryption_history_guard();
CREATE TRIGGER integration_encryption_truncate BEFORE TRUNCATE ON app.integration_encryption_keys
 FOR EACH STATEMENT EXECUTE FUNCTION app.integration_encryption_history_guard();

-- Reservation is used only inside the reviewed typed audited transaction.
-- +goose StatementBegin
CREATE FUNCTION app.integration_encryption_reserve(actor uuid,client uuid,connection uuid,label text,digest bytea)
RETURNS uuid
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE used bigint; saved bytea;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) OR
 NOT EXISTS(SELECT 1 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client
  AND c.provider='meta_ads' AND c.state IN ('pending','connected','reauthorization_required')) THEN RAISE no_data_found; END IF;
 IF label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
 octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex') THEN RAISE invalid_parameter_value; END IF;
 INSERT INTO app.integration_encryption_keys(key_label,fingerprint) VALUES(label,digest)
 ON CONFLICT(key_label) DO NOTHING;
 SELECT k.reservations,k.fingerprint INTO used,saved FROM app.integration_encryption_keys k
 WHERE k.key_label=label FOR UPDATE;
 IF saved IS DISTINCT FROM digest THEN RAISE invalid_parameter_value; END IF;
 IF used>=16777216 THEN RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='Integration encryption budget exhausted'; END IF;
 UPDATE app.integration_encryption_keys k SET reservations=k.reservations+1 WHERE k.key_label=label;
 RETURN gen_random_uuid();
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_encryption_reserve(uuid,uuid,uuid,text,bytea) FROM PUBLIC;

-- A separate transaction rechecks current access after reservation commits and
-- holds the shared lifecycle lock while Go encrypts. It returns no account ID.
-- +goose StatementBegin
CREATE FUNCTION app.integration_encryption_binding(actor uuid,client uuid,connection uuid)
RETURNS TABLE(client_id uuid,connection_id uuid,provider text,revision bigint,generation bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT c.client_id,c.id,c.provider,c.revision,c.generation FROM app.integration_connections c
 WHERE c.id=connection AND c.client_id=client AND c.provider='meta_ads'
 AND c.state IN ('pending','connected','reauthorization_required');
 IF NOT FOUND THEN RAISE no_data_found; END IF;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_encryption_binding(uuid,uuid,uuid) FROM PUBLIC;


-- +goose Up
-- Private encrypted storage only. No provider acceptance or connection success.
-- +goose StatementBegin
CREATE FUNCTION app.integration_credential_envelope_valid(data bytea,label text) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $$
DECLARE n integer;
BEGIN
 IF data IS NULL OR label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$'
 OR octet_length(data)<32 OR octet_length(data)>16478 THEN RETURN false; END IF;
 n:=get_byte(data,1);
 RETURN get_byte(data,0)=1 AND n=octet_length(label) AND
  octet_length(data) BETWEEN 2+n+29 AND 2+n+28+16384 AND
  substring(data FROM 3 FOR n)=convert_to(label,'UTF8');
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_envelope_valid(bytea,text) FROM PUBLIC;

CREATE TABLE app.integration_credentials (
 connection_id uuid PRIMARY KEY REFERENCES app.integration_connections(id) ON DELETE RESTRICT,
 purpose text NOT NULL DEFAULT 'access_token' CHECK(purpose='access_token'),
 key_id uuid NOT NULL REFERENCES app.integration_encryption_keys(id) ON DELETE RESTRICT,
 envelope bytea NOT NULL CHECK(octet_length(envelope) BETWEEN 32 AND 16478),
 revision bigint NOT NULL CHECK(revision>0),
 generation bigint NOT NULL CHECK(generation>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp()
  CHECK(created_at>=TIMESTAMPTZ '0001-01-01 00:00:00+00' AND created_at<TIMESTAMPTZ '10000-01-01 00:00:00+00'),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp()
  CHECK(updated_at>=created_at AND updated_at<TIMESTAMPTZ '10000-01-01 00:00:00+00')
);
REVOKE ALL ON app.integration_credentials FROM PUBLIC;
CREATE INDEX integration_credentials_key ON app.integration_credentials(key_id,connection_id);

-- Guard owner DML too; admin DDL remains the existing migration trust boundary.
-- +goose StatementBegin
CREATE FUNCTION app.integration_credential_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog AS $$
DECLARE label text; used bigint;
BEGIN
 IF TG_OP IN ('DELETE','TRUNCATE') THEN RAISE EXCEPTION 'Credential history is retained'; END IF;
 IF TG_OP='UPDATE' AND ((NEW.connection_id,NEW.purpose,NEW.created_at) IS DISTINCT FROM
  (OLD.connection_id,OLD.purpose,OLD.created_at) OR OLD.revision=9223372036854775807 OR
  NEW.revision<>OLD.revision+1 OR NEW.generation<OLD.generation OR NEW.updated_at<OLD.updated_at) THEN
  RAISE EXCEPTION 'Credential identity and revision are immutable';
 END IF;
 SELECT k.key_label,k.reservations INTO label,used FROM app.integration_encryption_keys k WHERE k.id=NEW.key_id;
 IF used IS NULL OR used<1 OR NOT app.integration_credential_envelope_valid(NEW.envelope,label) THEN
  RAISE invalid_parameter_value;
 END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_guard() FROM PUBLIC;
CREATE TRIGGER integration_credential_guard BEFORE INSERT OR UPDATE OR DELETE ON app.integration_credentials
 FOR EACH ROW EXECUTE FUNCTION app.integration_credential_guard();
CREATE TRIGGER integration_credential_truncate BEFORE TRUNCATE ON app.integration_credentials
 FOR EACH STATEMENT EXECUTE FUNCTION app.integration_credential_guard();

-- One internal snapshot; ciphertext never enters a public projection.
-- +goose StatementBegin
CREATE FUNCTION app.integration_credential_read(actor uuid,client uuid,connection uuid)
RETURNS TABLE(connection_revision bigint,connection_generation bigint,credential_revision bigint,
 credential_generation bigint,envelope bytea)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT c.revision,c.generation,coalesce(s.revision,0),coalesce(s.generation,0),s.envelope
 FROM app.integration_connections c LEFT JOIN app.integration_credentials s ON s.connection_id=c.id
 WHERE c.id=connection AND c.client_id=client AND c.provider='meta_ads'
 AND c.state IN ('pending','connected','reauthorization_required');
 IF NOT FOUND THEN RAISE no_data_found; END IF;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_read(uuid,uuid,uuid) FROM PUBLIC;

-- Used only by the reviewed typed audited Go writer. Full CAS after crypto.
-- +goose StatementBegin
CREATE FUNCTION app.integration_credential_write(actor uuid,client uuid,connection uuid,
 expected_connection bigint,expected_generation bigint,expected_credential bigint,
 label text,digest bytea,data bytea,rewrap boolean)
RETURNS TABLE(connection_revision bigint,connection_generation bigint,credential_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections; s app.integration_credentials; key uuid; now_at timestamptz;
 new_generation bigint; new_revision bigint;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client
 AND a.provider='meta_ads' AND a.state IN ('pending','connected','reauthorization_required') FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF expected_connection IS NULL OR expected_generation IS NULL OR expected_credential IS NULL OR rewrap IS NULL
 OR expected_connection<1 OR expected_generation<1 OR expected_credential<0 OR
 NOT app.integration_credential_envelope_valid(data,label) OR digest IS NULL OR octet_length(digest)<>32 THEN
  RAISE invalid_parameter_value;
 END IF;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=connection FOR UPDATE;
 IF (c.revision,c.generation,coalesce(s.revision,0)) IS DISTINCT FROM
 (expected_connection,expected_generation,expected_credential) OR
 (rewrap AND (s.connection_id IS NULL OR s.generation<>c.generation)) OR
 c.revision=9223372036854775807 OR coalesce(s.revision,0)=9223372036854775807 OR
 (NOT rewrap AND c.generation=9223372036854775807) THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration credential revision conflict';
 END IF;
 SELECT k.id INTO key FROM app.integration_encryption_keys k
 WHERE k.key_label=label AND k.fingerprint=digest AND k.reservations>0;
 IF NOT FOUND THEN RAISE invalid_parameter_value; END IF;
 now_at:=greatest(clock_timestamp(),c.updated_at,coalesce(s.updated_at,c.updated_at));
 new_generation:=c.generation+CASE WHEN rewrap THEN 0 ELSE 1 END;
 new_revision:=coalesce(s.revision,0)+1;
 INSERT INTO app.integration_credentials(connection_id,key_id,envelope,revision,generation,created_at,updated_at)
 VALUES(connection,key,data,new_revision,new_generation,now_at,now_at)
 ON CONFLICT(connection_id) DO UPDATE SET key_id=EXCLUDED.key_id,envelope=EXCLUDED.envelope,
 revision=EXCLUDED.revision,generation=EXCLUDED.generation,updated_at=EXCLUDED.updated_at;
 UPDATE app.integration_connections a SET revision=c.revision+1,generation=new_generation,updated_at=now_at
 WHERE a.id=connection;
 RETURN QUERY SELECT c.revision+1,new_generation,new_revision;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_write(uuid,uuid,uuid,bigint,bigint,bigint,text,bytea,bytea,boolean) FROM PUBLIC;


-- +goose Up
-- Local disablement only. No configured provider revoker or remote success.
-- +goose StatementBegin
CREATE FUNCTION app.integration_local_disconnect(actor uuid,client uuid,connection uuid,expected bigint)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,
 created_at timestamptz,updated_at timestamptz,changed boolean)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client
 AND a.provider='meta_ads' FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF expected IS NULL OR expected<1 THEN RAISE invalid_parameter_value; END IF;
 IF c.revision<>expected OR c.state='disconnected' THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration disconnect revision conflict';
 END IF;
 IF c.state='revocation_failed' THEN
  RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at,false;
  RETURN;
 END IF;
 IF c.revision=9223372036854775807 OR c.generation=9223372036854775807 THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration disconnect revision conflict';
 END IF;
 UPDATE app.integration_connections a SET state='revocation_failed',revision=c.revision+1,
 generation=c.generation+1,updated_at=greatest(clock_timestamp(),c.updated_at) WHERE a.id=connection
 RETURNING a.* INTO c;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at,true;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_local_disconnect(uuid,uuid,uuid,bigint) FROM PUBLIC;


-- +goose Up
-- Trusted process startup capability: boolean only, never a key registry reader.
-- +goose StatementBegin
CREATE FUNCTION app.integration_key_preflight(labels text[],digests bytea[],active_label text,restored boolean)
RETURNS boolean LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF labels IS NULL OR digests IS NULL OR active_label IS NULL OR restored IS NULL OR
 array_ndims(labels) IS DISTINCT FROM 1 OR array_ndims(digests) IS DISTINCT FROM 1 OR
 array_lower(labels,1) IS DISTINCT FROM 1 OR array_lower(digests,1) IS DISTINCT FROM 1 OR
 cardinality(labels) NOT BETWEEN 1 AND 8 OR cardinality(labels)<>cardinality(digests) THEN RETURN false; END IF;
 IF EXISTS(SELECT 1 FROM unnest(labels,digests) AS supplied(label,digest)
  WHERE label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
  octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex')) OR
 (SELECT count(DISTINCT label) FROM unnest(labels) AS supplied(label))<>cardinality(labels) OR
 (SELECT count(DISTINCT digest) FROM unnest(digests) AS supplied(digest))<>cardinality(digests) OR
 NOT active_label=ANY(labels) THEN RETURN false; END IF;
 IF EXISTS(SELECT 1 FROM unnest(labels,digests) AS supplied(label,digest)
  JOIN app.integration_encryption_keys k ON k.key_label=label OR k.fingerprint=digest
  WHERE k.key_label<>label OR k.fingerprint<>digest) OR
 EXISTS(SELECT 1 FROM app.integration_credentials c JOIN app.integration_encryption_keys k ON k.id=c.key_id
  WHERE NOT k.key_label=ANY(labels)) OR
 EXISTS(SELECT 1 FROM app.integration_encryption_keys k WHERE k.key_label=active_label
  AND (restored OR k.reservations>=16777216)) THEN RETURN false; END IF;
 RETURN true;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_key_preflight(text[],bytea[],text,boolean) FROM PUBLIC;


-- +goose Up
-- Private exact-client rotation planning only: no envelope or key projection.
-- +goose StatementBegin
CREATE FUNCTION app.integration_rotation_candidates(actor uuid,client uuid,label text,digest bytea,
 after_id uuid,page_size integer)
RETURNS TABLE(connection_id uuid,connection_revision bigint,connection_generation bigint,credential_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
 octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex') OR page_size IS NULL OR
 page_size NOT BETWEEN 1 AND 100 OR after_id='00000000-0000-0000-0000-000000000000'::uuid THEN
  RAISE invalid_parameter_value;
 END IF;
 IF EXISTS(SELECT 1 FROM app.integration_encryption_keys k
  WHERE (k.key_label=label OR k.fingerprint=digest) AND (k.key_label<>label OR k.fingerprint<>digest)) THEN
  RAISE invalid_parameter_value;
 END IF;
 RETURN QUERY SELECT c.id,c.revision,c.generation,s.revision
 FROM app.integration_connections c JOIN app.integration_credentials s ON s.connection_id=c.id
 JOIN app.integration_encryption_keys k ON k.id=s.key_id
 WHERE c.client_id=client AND c.provider='meta_ads' AND
 c.state IN ('pending','connected','reauthorization_required') AND s.generation=c.generation AND
 k.fingerprint<>digest AND (after_id IS NULL OR c.id>after_id)
 ORDER BY c.id LIMIT page_size+1;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_rotation_candidates(uuid,uuid,text,bytea,uuid,integer) FROM PUBLIC;


-- +goose Up
-- Trusted live retention observation: source-relative counts, no key identity.
-- +goose StatementBegin
CREATE FUNCTION app.integration_key_inventory(actor uuid,labels text[],digests bytea[],active_label text,restored boolean)
RETURNS TABLE(key_position integer,is_active boolean,stored_rows bigint,eligible_rows bigint,excluded_rows bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE active_digest bytea;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT EXISTS(SELECT 1 FROM app.authorization_grants(actor) g WHERE g.permission_key='clients.view' AND g.scope_kind='global') OR
 NOT EXISTS(SELECT 1 FROM app.authorization_grants(actor) g WHERE g.permission_key='integrations.manage' AND g.scope_kind='global') THEN
  RAISE no_data_found;
 END IF;
 IF labels IS NULL OR digests IS NULL OR active_label IS NULL OR restored IS NULL OR
 array_ndims(labels) IS DISTINCT FROM 1 OR array_ndims(digests) IS DISTINCT FROM 1 OR
 array_lower(labels,1) IS DISTINCT FROM 1 OR array_lower(digests,1) IS DISTINCT FROM 1 OR
 cardinality(labels) NOT BETWEEN 1 AND 8 OR cardinality(labels)<>cardinality(digests) THEN RAISE invalid_parameter_value; END IF;
 IF EXISTS(SELECT 1 FROM unnest(labels,digests) AS supplied(label,digest)
  WHERE label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
  octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex')) OR
 (SELECT count(DISTINCT label) FROM unnest(labels) AS supplied(label))<>cardinality(labels) OR
 (SELECT count(DISTINCT digest) FROM unnest(digests) AS supplied(digest))<>cardinality(digests) OR
 NOT active_label=ANY(labels) THEN RAISE invalid_parameter_value; END IF;
 IF EXISTS(SELECT 1 FROM unnest(labels,digests) AS supplied(label,digest)
  JOIN app.integration_encryption_keys k ON k.key_label=label OR k.fingerprint=digest
  WHERE k.key_label<>label OR k.fingerprint<>digest) OR
 EXISTS(SELECT 1 FROM app.integration_credentials c JOIN app.integration_encryption_keys k ON k.id=c.key_id
  WHERE NOT k.key_label=ANY(labels)) OR
 (restored AND EXISTS(SELECT 1 FROM app.integration_encryption_keys k WHERE k.key_label=active_label)) THEN
  RAISE object_not_in_prerequisite_state;
 END IF;
 SELECT supplied.digest INTO active_digest FROM unnest(labels,digests) AS supplied(label,digest) WHERE supplied.label=active_label;
 RETURN QUERY WITH tally AS (
  SELECT supplied.ordinal::integer AS slot,supplied.key_label=active_label AS active,
   count(s.connection_id) AS total,
   count(s.connection_id) FILTER(WHERE k.fingerprint<>active_digest AND cl.id IS NOT NULL AND cl.archived_at IS NULL AND
    c.provider='meta_ads' AND c.state IN ('pending','connected','reauthorization_required') AND s.generation=c.generation) AS eligible
  FROM unnest(labels,digests) WITH ORDINALITY AS supplied(key_label,key_digest,ordinal)
  LEFT JOIN app.integration_encryption_keys k ON k.key_label=supplied.key_label AND k.fingerprint=supplied.key_digest
  LEFT JOIN app.integration_credentials s ON s.key_id=k.id
  LEFT JOIN app.integration_connections c ON c.id=s.connection_id
  LEFT JOIN app.clients cl ON cl.id=c.client_id
  GROUP BY supplied.ordinal,supplied.key_label
 ) SELECT tally.slot,tally.active,tally.total,tally.eligible,tally.total-tally.eligible FROM tally ORDER BY tally.slot;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_key_inventory(uuid,text[],bytea[],text,boolean) FROM PUBLIC;


-- +goose Up
-- Expand private catalog only; no public setup, provider traffic or success seed.
SELECT pg_advisory_xact_lock(871092650209);
LOCK TABLE app.integration_connections,app.integration_credentials,app.audit_events IN ACCESS EXCLUSIVE MODE;

-- Syntax only. Destination/ownership verification belongs to future transport.
-- +goose StatementBegin
CREATE FUNCTION app.integration_account_valid(provider text,account text) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $$
DECLARE host text; tail text; part text;
BEGIN
 IF provider IS NULL OR account IS NULL THEN RETURN false; END IF;
 IF provider='meta_ads' THEN RETURN account COLLATE "C" ~ '^[1-9][0-9]{0,31}$'; END IF;
 IF provider='ga4' THEN RETURN account COLLATE "C" ~ '^[1-9][0-9]{0,19}$'; END IF;
 IF provider<>'woocommerce' OR octet_length(account)>520 OR
  account COLLATE "C" !~ '^https://[a-z0-9.-]+(/[A-Za-z0-9_-]+)*$' THEN RETURN false; END IF;
 host:=split_part(substring(account FROM 9),'/',1);
 tail:=substring(account FROM 9+length(host));
 IF length(host)>253 OR length(tail)>256 OR position('.' IN host)=0 THEN RETURN false; END IF;
 FOREACH part IN ARRAY string_to_array(host,'.') LOOP
  IF length(part) NOT BETWEEN 1 AND 63 OR part COLLATE "C" !~ '^[a-z0-9]([a-z0-9-]*[a-z0-9])?$' THEN RETURN false; END IF;
 END LOOP;
 -- Alphabetic TLD start rejects direct numeric/IPv4 hosts; IPv6 fails above.
 part:=split_part(host,'.',-1);
 RETURN part COLLATE "C" ~ '^[a-z][a-z0-9-]*[a-z0-9]$';
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_account_valid(text,text) FROM PUBLIC;

ALTER TABLE app.integration_connections DROP CONSTRAINT integration_connections_provider_check,
 DROP CONSTRAINT integration_connections_provider_account_id_check;
ALTER TABLE app.integration_connections ADD CONSTRAINT integration_connections_provider_check
 CHECK(provider IN ('meta_ads','ga4','woocommerce')),
 ADD CONSTRAINT integration_connections_provider_account_id_check CHECK(app.integration_account_valid(provider,provider_account_id));
ALTER TABLE app.integration_credentials DROP CONSTRAINT integration_credentials_purpose_check;
ALTER TABLE app.integration_credentials ADD CONSTRAINT integration_credentials_purpose_check
 CHECK(purpose IN ('access_token','provider_credential'));

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_encryption_reserve(actor uuid,client uuid,connection uuid,label text,digest bytea)
RETURNS uuid
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE used bigint; saved bytea;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) OR
 NOT EXISTS(SELECT 1 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client
  AND c.provider IN ('meta_ads','ga4','woocommerce') AND c.state IN ('pending','connected','reauthorization_required')) THEN RAISE no_data_found; END IF;
 IF label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
 octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex') THEN RAISE invalid_parameter_value; END IF;
 INSERT INTO app.integration_encryption_keys(key_label,fingerprint) VALUES(label,digest)
 ON CONFLICT(key_label) DO NOTHING;
 SELECT k.reservations,k.fingerprint INTO used,saved FROM app.integration_encryption_keys k
 WHERE k.key_label=label FOR UPDATE;
 IF saved IS DISTINCT FROM digest THEN RAISE invalid_parameter_value; END IF;
 IF used>=16777216 THEN RAISE EXCEPTION USING ERRCODE='P0001',MESSAGE='Integration encryption budget exhausted'; END IF;
 UPDATE app.integration_encryption_keys k SET reservations=k.reservations+1 WHERE k.key_label=label;
 RETURN gen_random_uuid();
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_encryption_reserve(uuid,uuid,uuid,text,bytea) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_encryption_binding(actor uuid,client uuid,connection uuid)
RETURNS TABLE(client_id uuid,connection_id uuid,provider text,revision bigint,generation bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT c.client_id,c.id,c.provider,c.revision,c.generation FROM app.integration_connections c
 WHERE c.id=connection AND c.client_id=client AND c.provider IN ('meta_ads','ga4','woocommerce')
 AND c.state IN ('pending','connected','reauthorization_required');
 IF NOT FOUND THEN RAISE no_data_found; END IF;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_encryption_binding(uuid,uuid,uuid) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_credential_guard() RETURNS trigger
LANGUAGE plpgsql SET search_path=pg_catalog AS $$
DECLARE label text; used bigint;
BEGIN
 IF TG_OP IN ('DELETE','TRUNCATE') THEN RAISE EXCEPTION 'Credential history is retained'; END IF;
 IF TG_OP='UPDATE' AND ((NEW.connection_id,NEW.purpose,NEW.created_at) IS DISTINCT FROM
  (OLD.connection_id,OLD.purpose,OLD.created_at) OR OLD.revision=9223372036854775807 OR
  NEW.revision<>OLD.revision+1 OR NEW.generation<OLD.generation OR NEW.updated_at<OLD.updated_at) THEN
  RAISE EXCEPTION 'Credential identity and revision are immutable';
 END IF;
 IF NEW.purpose IS DISTINCT FROM (SELECT CASE c.provider WHEN 'meta_ads' THEN 'access_token'
  WHEN 'ga4' THEN 'provider_credential' WHEN 'woocommerce' THEN 'provider_credential' END
  FROM app.integration_connections c WHERE c.id=NEW.connection_id) THEN RAISE invalid_parameter_value; END IF;
 SELECT k.key_label,k.reservations INTO label,used FROM app.integration_encryption_keys k WHERE k.id=NEW.key_id;
 IF used IS NULL OR used<1 OR NOT app.integration_credential_envelope_valid(NEW.envelope,label) THEN
  RAISE invalid_parameter_value;
 END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_guard() FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_credential_read(actor uuid,client uuid,connection uuid)
RETURNS TABLE(connection_revision bigint,connection_generation bigint,credential_revision bigint,
 credential_generation bigint,envelope bytea)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 RETURN QUERY SELECT c.revision,c.generation,coalesce(s.revision,0),coalesce(s.generation,0),s.envelope
 FROM app.integration_connections c LEFT JOIN app.integration_credentials s ON s.connection_id=c.id
 WHERE c.id=connection AND c.client_id=client AND c.provider IN ('meta_ads','ga4','woocommerce')
 AND c.state IN ('pending','connected','reauthorization_required');
 IF NOT FOUND THEN RAISE no_data_found; END IF;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_read(uuid,uuid,uuid) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_credential_write(actor uuid,client uuid,connection uuid,
 expected_connection bigint,expected_generation bigint,expected_credential bigint,
 label text,digest bytea,data bytea,rewrap boolean)
RETURNS TABLE(connection_revision bigint,connection_generation bigint,credential_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections; s app.integration_credentials; key uuid; now_at timestamptz;
 new_generation bigint; new_revision bigint;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client
 AND a.provider IN ('meta_ads','ga4','woocommerce') AND a.state IN ('pending','connected','reauthorization_required') FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF expected_connection IS NULL OR expected_generation IS NULL OR expected_credential IS NULL OR rewrap IS NULL
 OR expected_connection<1 OR expected_generation<1 OR expected_credential<0 OR
 NOT app.integration_credential_envelope_valid(data,label) OR digest IS NULL OR octet_length(digest)<>32 THEN
  RAISE invalid_parameter_value;
 END IF;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=connection FOR UPDATE;
 IF (c.revision,c.generation,coalesce(s.revision,0)) IS DISTINCT FROM
 (expected_connection,expected_generation,expected_credential) OR
 (rewrap AND (s.connection_id IS NULL OR s.generation<>c.generation)) OR
 c.revision=9223372036854775807 OR coalesce(s.revision,0)=9223372036854775807 OR
 (NOT rewrap AND c.generation=9223372036854775807) THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration credential revision conflict';
 END IF;
 SELECT k.id INTO key FROM app.integration_encryption_keys k
 WHERE k.key_label=label AND k.fingerprint=digest AND k.reservations>0;
 IF NOT FOUND THEN RAISE invalid_parameter_value; END IF;
 now_at:=greatest(clock_timestamp(),c.updated_at,coalesce(s.updated_at,c.updated_at));
 new_generation:=c.generation+CASE WHEN rewrap THEN 0 ELSE 1 END;
 new_revision:=coalesce(s.revision,0)+1;
 INSERT INTO app.integration_credentials(connection_id,purpose,key_id,envelope,revision,generation,created_at,updated_at)
 VALUES(connection,CASE c.provider WHEN 'meta_ads' THEN 'access_token' ELSE 'provider_credential' END,key,data,new_revision,new_generation,now_at,now_at)
 ON CONFLICT(connection_id) DO UPDATE SET key_id=EXCLUDED.key_id,envelope=EXCLUDED.envelope,
 revision=EXCLUDED.revision,generation=EXCLUDED.generation,updated_at=EXCLUDED.updated_at;
 UPDATE app.integration_connections a SET revision=c.revision+1,generation=new_generation,updated_at=now_at
 WHERE a.id=connection;
 RETURN QUERY SELECT c.revision+1,new_generation,new_revision;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_credential_write(uuid,uuid,uuid,bigint,bigint,bigint,text,bytea,bytea,boolean) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_local_disconnect(actor uuid,client uuid,connection uuid,expected bigint)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,
 created_at timestamptz,updated_at timestamptz,changed boolean)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client
 AND a.provider IN ('meta_ads','ga4','woocommerce') FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF expected IS NULL OR expected<1 THEN RAISE invalid_parameter_value; END IF;
 IF c.revision<>expected OR c.state='disconnected' THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration disconnect revision conflict';
 END IF;
 IF c.state='revocation_failed' THEN
  RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at,false;
  RETURN;
 END IF;
 IF c.revision=9223372036854775807 OR c.generation=9223372036854775807 THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration disconnect revision conflict';
 END IF;
 UPDATE app.integration_connections a SET state='revocation_failed',revision=c.revision+1,
 generation=c.generation+1,updated_at=greatest(clock_timestamp(),c.updated_at) WHERE a.id=connection
 RETURNING a.* INTO c;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at,true;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_local_disconnect(uuid,uuid,uuid,bigint) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_rotation_candidates(actor uuid,client uuid,label text,digest bytea,
 after_id uuid,page_size integer)
RETURNS TABLE(connection_id uuid,connection_revision bigint,connection_generation bigint,credential_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
 octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex') OR page_size IS NULL OR
 page_size NOT BETWEEN 1 AND 100 OR after_id='00000000-0000-0000-0000-000000000000'::uuid THEN
  RAISE invalid_parameter_value;
 END IF;
 IF EXISTS(SELECT 1 FROM app.integration_encryption_keys k
  WHERE (k.key_label=label OR k.fingerprint=digest) AND (k.key_label<>label OR k.fingerprint<>digest)) THEN
  RAISE invalid_parameter_value;
 END IF;
 RETURN QUERY SELECT c.id,c.revision,c.generation,s.revision
 FROM app.integration_connections c JOIN app.integration_credentials s ON s.connection_id=c.id
 JOIN app.integration_encryption_keys k ON k.id=s.key_id
 WHERE c.client_id=client AND c.provider IN ('meta_ads','ga4','woocommerce') AND
 c.state IN ('pending','connected','reauthorization_required') AND s.generation=c.generation AND
 k.fingerprint<>digest AND (after_id IS NULL OR c.id>after_id)
 ORDER BY c.id LIMIT page_size+1;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_rotation_candidates(uuid,uuid,text,bytea,uuid,integer) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.integration_key_inventory(actor uuid,labels text[],digests bytea[],active_label text,restored boolean)
RETURNS TABLE(key_position integer,is_active boolean,stored_rows bigint,eligible_rows bigint,excluded_rows bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE active_digest bytea;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT EXISTS(SELECT 1 FROM app.authorization_grants(actor) g WHERE g.permission_key='clients.view' AND g.scope_kind='global') OR
 NOT EXISTS(SELECT 1 FROM app.authorization_grants(actor) g WHERE g.permission_key='integrations.manage' AND g.scope_kind='global') THEN
  RAISE no_data_found;
 END IF;
 IF labels IS NULL OR digests IS NULL OR active_label IS NULL OR restored IS NULL OR
 array_ndims(labels) IS DISTINCT FROM 1 OR array_ndims(digests) IS DISTINCT FROM 1 OR
 array_lower(labels,1) IS DISTINCT FROM 1 OR array_lower(digests,1) IS DISTINCT FROM 1 OR
 cardinality(labels) NOT BETWEEN 1 AND 8 OR cardinality(labels)<>cardinality(digests) THEN RAISE invalid_parameter_value; END IF;
 IF EXISTS(SELECT 1 FROM unnest(labels,digests) AS supplied(label,digest)
  WHERE label IS NULL OR label !~ '^[a-z0-9][a-z0-9_-]{0,63}$' OR digest IS NULL OR
  octet_length(digest)<>32 OR digest=decode(repeat('00',32),'hex')) OR
 (SELECT count(DISTINCT label) FROM unnest(labels) AS supplied(label))<>cardinality(labels) OR
 (SELECT count(DISTINCT digest) FROM unnest(digests) AS supplied(digest))<>cardinality(digests) OR
 NOT active_label=ANY(labels) THEN RAISE invalid_parameter_value; END IF;
 IF EXISTS(SELECT 1 FROM unnest(labels,digests) AS supplied(label,digest)
  JOIN app.integration_encryption_keys k ON k.key_label=label OR k.fingerprint=digest
  WHERE k.key_label<>label OR k.fingerprint<>digest) OR
 EXISTS(SELECT 1 FROM app.integration_credentials c JOIN app.integration_encryption_keys k ON k.id=c.key_id
  WHERE NOT k.key_label=ANY(labels)) OR
 (restored AND EXISTS(SELECT 1 FROM app.integration_encryption_keys k WHERE k.key_label=active_label)) THEN
  RAISE object_not_in_prerequisite_state;
 END IF;
 SELECT supplied.digest INTO active_digest FROM unnest(labels,digests) AS supplied(label,digest) WHERE supplied.label=active_label;
 RETURN QUERY WITH tally AS (
  SELECT supplied.ordinal::integer AS slot,supplied.key_label=active_label AS active,
   count(s.connection_id) AS total,
   count(s.connection_id) FILTER(WHERE k.fingerprint<>active_digest AND cl.id IS NOT NULL AND cl.archived_at IS NULL AND
    c.provider IN ('meta_ads','ga4','woocommerce') AND c.state IN ('pending','connected','reauthorization_required') AND s.generation=c.generation) AS eligible
  FROM unnest(labels,digests) WITH ORDINALITY AS supplied(key_label,key_digest,ordinal)
  LEFT JOIN app.integration_encryption_keys k ON k.key_label=supplied.key_label AND k.fingerprint=supplied.key_digest
  LEFT JOIN app.integration_credentials s ON s.key_id=k.id
  LEFT JOIN app.integration_connections c ON c.id=s.connection_id
  LEFT JOIN app.clients cl ON cl.id=c.client_id
  GROUP BY supplied.ordinal,supplied.key_label
 ) SELECT tally.slot,tally.active,tally.total,tally.eligible,tally.total-tally.eligible FROM tally ORDER BY tally.slot;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.integration_key_inventory(uuid,text[],bytea[],text,boolean) FROM PUBLIC;

-- +goose Up
-- Existing #26: private, durable GA4 work. No jobs or provider success are seeded.
SELECT pg_advisory_xact_lock(871092650209);

CREATE TABLE app.analytics_sync_jobs (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'::uuid),
 client_id uuid NOT NULL REFERENCES app.clients(id) ON DELETE RESTRICT,
 connection_id uuid NOT NULL REFERENCES app.integration_connections(id) ON DELETE RESTRICT,
 requested_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
 since date NOT NULL CHECK(since>=DATE '2000-01-01' AND since<DATE '10000-01-01'),
 until date NOT NULL CHECK(until>=since AND until-since<=30),
 connection_revision bigint NOT NULL CHECK(connection_revision>0),
 generation bigint NOT NULL CHECK(generation>0),
 credential_revision bigint NOT NULL CHECK(credential_revision>0),
 state text NOT NULL DEFAULT 'queued' CHECK(state IN ('queued','running','succeeded','failed')),
 reason text CHECK(reason IN ('provider_unavailable','authorization_required','connection_changed','interrupted')),
 attempts integer NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 3),
 lease_token uuid CHECK(lease_token<>'00000000-0000-0000-0000-000000000000'::uuid),
 lease_until timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 finished_at timestamptz,
 CHECK(updated_at>=created_at),
 CHECK((state='running')=(lease_token IS NOT NULL AND lease_until IS NOT NULL)),
 CHECK((lease_token IS NULL)=(lease_until IS NULL)),
 CHECK((state IN ('succeeded','failed'))=(finished_at IS NOT NULL)),
 CHECK((state='failed')=(reason IS NOT NULL))
);
CREATE UNIQUE INDEX analytics_sync_one_active ON app.analytics_sync_jobs(connection_id) WHERE state IN ('queued','running');
CREATE INDEX analytics_sync_claim ON app.analytics_sync_jobs(state,lease_until,created_at,id) WHERE state IN ('queued','running');
CREATE INDEX analytics_sync_client_latest ON app.analytics_sync_jobs(client_id,connection_id,created_at DESC,id DESC);

CREATE TABLE app.analytics_snapshots (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 client_id uuid NOT NULL REFERENCES app.clients(id) ON DELETE RESTRICT,
 connection_id uuid NOT NULL REFERENCES app.integration_connections(id) ON DELETE RESTRICT,
 generation bigint NOT NULL CHECK(generation>0),
 since date NOT NULL CHECK(since>=DATE '2000-01-01' AND since<DATE '10000-01-01'),
 until date NOT NULL CHECK(until>=since AND until-since<=30),
 workspace jsonb NOT NULL CHECK(jsonb_typeof(workspace)='object' AND octet_length(workspace::text)<=2097152),
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 synced_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 CONSTRAINT analytics_snapshot_period UNIQUE(connection_id,generation,since,until)
);
CREATE INDEX analytics_snapshots_retention ON app.analytics_snapshots(synced_at,id);
CREATE INDEX analytics_snapshots_client_period ON app.analytics_snapshots(client_id,connection_id,since,until,generation);
REVOKE ALL ON app.analytics_sync_jobs,app.analytics_snapshots FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.ga4_connection_create(actor uuid,client uuid,connection uuid,account text)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF connection IS NULL OR connection='00000000-0000-0000-0000-000000000000'::uuid OR
 account IS NULL OR NOT app.integration_account_valid('ga4',account) THEN RAISE invalid_parameter_value; END IF;
 BEGIN
  INSERT INTO app.integration_connections(id,client_id,provider,provider_account_id) VALUES(connection,client,'ga4',account);
 EXCEPTION WHEN unique_violation THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration connection conflict'; END;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at
 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.ga4_connection_create(uuid,uuid,uuid,text) FROM PUBLIC;

-- Lock order: lifecycle, job admission, connection/job/snapshot rows. The setup
-- transaction calls this before the existing credential writer takes row locks.
-- No transaction/lifecycle lock spans external provider requests.
-- +goose StatementBegin
CREATE FUNCTION app.analytics_writer_lock() RETURNS void
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT pg_advisory_xact_lock_shared(871092650209);
 SELECT pg_advisory_xact_lock(871092650210);
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_writer_lock() FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_sync_enqueue(actor uuid,client uuid,connection uuid,expected_revision bigint,
 expected_generation bigint,expected_credential bigint,since_at date,until_at date,job uuid,credential_changed boolean)
RETURNS TABLE(job_id uuid,connection_revision bigint,job_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections; s app.integration_credentials; next_revision bigint;
BEGIN
 PERFORM app.analytics_writer_lock();
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client AND a.provider='ga4'
 AND a.state IN ('pending','connected','reauthorization_required') FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=connection;
 IF s.connection_id IS NULL OR s.generation<>c.generation OR c.revision IS DISTINCT FROM expected_revision OR
 c.generation IS DISTINCT FROM expected_generation OR s.revision IS DISTINCT FROM expected_credential OR
 c.revision=9223372036854775807 THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict'; END IF;
 IF since_at IS NULL OR until_at IS NULL OR since_at<DATE '2000-01-01' OR until_at>=DATE '10000-01-01' OR
 until_at<since_at OR until_at-since_at>30 OR job IS NULL OR job='00000000-0000-0000-0000-000000000000'::uuid OR
 credential_changed IS NULL THEN RAISE invalid_parameter_value; END IF;
 -- Replacing credentials must atomically interrupt older queued/running work.
 -- It does not mutate those jobs here: require the caller to cancel and audit
 -- them through analytics_sync_cancel before enqueueing this replacement.
 IF EXISTS(SELECT 1 FROM app.analytics_sync_jobs j WHERE j.connection_id=connection AND j.state IN ('queued','running')) THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict';
 END IF;
 next_revision:=c.revision;
 IF credential_changed THEN
  next_revision:=c.revision+1;
  UPDATE app.integration_connections a SET state='pending',revision=next_revision,updated_at=greatest(clock_timestamp(),a.updated_at) WHERE a.id=connection;
 END IF;
 INSERT INTO app.analytics_sync_jobs(id,client_id,connection_id,requested_by,since,until,connection_revision,generation,credential_revision)
 VALUES(job,client,connection,actor,since_at,until_at,next_revision,c.generation,s.revision);
 RETURN QUERY SELECT job,next_revision,1::bigint;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_sync_enqueue(uuid,uuid,uuid,bigint,bigint,bigint,date,date,uuid,boolean) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_sync_cancel(actor uuid,client uuid,connection uuid)
RETURNS TABLE(id uuid,before_revision bigint,after_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM app.analytics_writer_lock();
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) OR
 NOT EXISTS(SELECT 1 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client AND c.provider='ga4'
 AND c.state IN ('pending','connected','reauthorization_required')) THEN RAISE no_data_found; END IF;
 RETURN QUERY UPDATE app.analytics_sync_jobs j SET state='failed',reason='connection_changed',lease_token=NULL,lease_until=NULL,
 finished_at=clock_timestamp(),updated_at=greatest(clock_timestamp(),j.updated_at),revision=j.revision+1
 WHERE j.connection_id=connection AND j.client_id=client AND j.state IN ('queued','running') AND j.revision<9223372036854775807
 RETURNING j.id,j.revision-1,j.revision;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_sync_cancel(uuid,uuid,uuid) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_job_allowed(job uuid,token uuid) RETURNS boolean
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 RETURN EXISTS(SELECT 1 FROM app.analytics_sync_jobs j JOIN app.integration_connections c ON c.id=j.connection_id
 JOIN app.integration_credentials s ON s.connection_id=c.id JOIN app.clients a ON a.id=j.client_id
 WHERE j.id=job AND j.state='running' AND j.lease_token=token AND j.lease_until>clock_timestamp() AND a.archived_at IS NULL
 AND c.client_id=j.client_id AND c.provider='ga4' AND c.state IN ('pending','connected','reauthorization_required')
 AND c.revision=j.connection_revision AND c.generation=j.generation AND s.generation=j.generation AND s.revision=j.credential_revision
 AND app.authorization_allowed(j.requested_by,'clients.view',j.client_id) AND app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id));
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_job_allowed(uuid,uuid) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_sync_claim()
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,requested_by uuid,since date,until date,state text,
 before_revision bigint,revision bigint,lease_token uuid,property_account text,envelope bytea)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE j app.analytics_sync_jobs; c app.integration_connections; s app.integration_credentials; failure text; next_token uuid;
BEGIN
 PERFORM app.analytics_writer_lock();
 IF (SELECT count(*) FROM app.analytics_sync_jobs a WHERE a.state='running' AND a.lease_until>clock_timestamp())>=2 THEN RETURN; END IF;
 SELECT * INTO j FROM app.analytics_sync_jobs a WHERE a.state='queued' OR (a.state='running' AND a.lease_until<=clock_timestamp())
 ORDER BY a.created_at,a.id LIMIT 1 FOR UPDATE;
 IF NOT FOUND THEN RETURN; END IF;
 IF j.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=j.connection_id FOR UPDATE;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=j.connection_id;
 IF NOT app.authorization_allowed(j.requested_by,'clients.view',j.client_id) OR
 NOT app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=j.client_id AND a.archived_at IS NULL) THEN failure:='authorization_required';
 ELSIF c.client_id IS DISTINCT FROM j.client_id OR c.provider IS DISTINCT FROM 'ga4' OR
 c.state NOT IN ('pending','connected','reauthorization_required') OR c.revision IS DISTINCT FROM j.connection_revision OR
 c.generation IS DISTINCT FROM j.generation OR s.generation IS DISTINCT FROM j.generation OR s.revision IS DISTINCT FROM j.credential_revision THEN failure:='connection_changed';
 ELSIF j.attempts>=3 THEN failure:='interrupted'; END IF;
 IF failure IS NOT NULL THEN
  UPDATE app.analytics_sync_jobs a SET state='failed',reason=failure,lease_token=NULL,lease_until=NULL,
  finished_at=clock_timestamp(),updated_at=greatest(clock_timestamp(),a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
  RETURN QUERY SELECT j.id,j.client_id,j.connection_id,j.requested_by,j.since,j.until,'failed'::text,j.revision,j.revision+1,NULL::uuid,NULL::text,NULL::bytea;
  RETURN;
 END IF;
 next_token:=gen_random_uuid();
 UPDATE app.analytics_sync_jobs a SET state='running',attempts=a.attempts+1,lease_token=next_token,lease_until=clock_timestamp()+INTERVAL '180 seconds',
 updated_at=greatest(clock_timestamp(),a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
 RETURN QUERY SELECT j.id,j.client_id,j.connection_id,j.requested_by,j.since,j.until,'running'::text,j.revision,j.revision+1,next_token,c.provider_account_id,s.envelope;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_sync_claim() FROM PUBLIC;

-- The public shape has no property/account, credential, unused catalog, raw
-- provider response or diagnostic. These checks also protect direct SQL writers.
-- +goose StatementBegin
CREATE FUNCTION app.analytics_workspace_valid(value jsonb,client uuid,connection uuid,since_at date,until_at date) RETURNS boolean
LANGUAGE plpgsql STABLE SET search_path=pg_catalog AS $$
DECLARE key text; r jsonb; row_value jsonb; column_value jsonb; d jsonb; dimensions jsonb; timezone text; n integer; i integer;
BEGIN
 IF value IS NULL OR jsonb_typeof(value)<>'object' OR octet_length(value::text)>2097152 OR
 value-ARRAY['definitions','summary','daily','acquisition','devices','landing']<>'{}'::jsonb OR
 NOT value ?& ARRAY['definitions','summary','daily','acquisition','devices','landing'] OR
 jsonb_typeof(value->'definitions')<>'array' OR jsonb_array_length(value->'definitions')<>4 THEN RETURN false; END IF;
 FOR i IN 0..3 LOOP
  d:=value->'definitions'->i;
  IF jsonb_typeof(d)<>'object' OR d-ARRAY['name','type','display_name','description']<>'{}'::jsonb OR
  NOT d ?& ARRAY['name','type','display_name','description'] OR
  d->>'name' IS DISTINCT FROM (ARRAY['activeUsers','sessions','screenPageViews','keyEvents'])[i+1] OR
  jsonb_typeof(d->'type')<>'string' OR (i<3 AND d->>'type'<>'TYPE_INTEGER') OR
  (i=3 AND d->>'type' NOT IN ('TYPE_INTEGER','TYPE_FLOAT')) OR
  jsonb_typeof(d->'display_name')<>'string' OR octet_length(d->>'display_name') NOT BETWEEN 1 AND 256 OR
  jsonb_typeof(d->'description')<>'string' OR octet_length(d->>'description') NOT BETWEEN 1 AND 4096 THEN RETURN false; END IF;
 END LOOP;
 timezone:=value->'summary'->>'timezone';
 IF timezone IS NULL OR octet_length(timezone) NOT BETWEEN 1 AND 128 OR timezone='Local' OR
 NOT EXISTS(SELECT 1 FROM pg_timezone_names z WHERE z.name=timezone) THEN RETURN false; END IF;
 FOREACH key IN ARRAY ARRAY['summary','daily','acquisition','devices','landing'] LOOP
  dimensions:=CASE key WHEN 'summary' THEN '[]'::jsonb WHEN 'daily' THEN '["date"]'::jsonb
  WHEN 'acquisition' THEN '["date","sessionDefaultChannelGroup"]'::jsonb WHEN 'devices' THEN '["date","deviceCategory"]'::jsonb ELSE '["landingPage"]'::jsonb END;
  r:=value->key;
  IF jsonb_typeof(r)<>'object' OR r-ARRAY['client_id','connection_id','api_version','timezone','since','until','dimensions','metrics','rows']<>'{}'::jsonb OR
  NOT r ?& ARRAY['client_id','connection_id','api_version','timezone','since','until','dimensions','metrics','rows'] OR
  r->>'client_id' IS DISTINCT FROM client::text OR r->>'connection_id' IS DISTINCT FROM connection::text OR
  r->>'api_version' IS DISTINCT FROM 'v1beta' OR r->>'timezone' IS DISTINCT FROM timezone OR
  r->>'since' IS DISTINCT FROM to_char(since_at,'YYYY-MM-DD') OR r->>'until' IS DISTINCT FROM to_char(until_at,'YYYY-MM-DD') OR
  r->'dimensions' IS DISTINCT FROM dimensions OR r->'metrics' IS DISTINCT FROM '["activeUsers","sessions","screenPageViews","keyEvents"]'::jsonb OR
  jsonb_typeof(r->'rows')<>'array' THEN RETURN false; END IF;
  n:=jsonb_array_length(r->'rows');
  IF n>1000 OR (key='summary' AND n>1) THEN RETURN false; END IF;
  FOR row_value IN SELECT a FROM jsonb_array_elements(r->'rows') a LOOP
   IF jsonb_typeof(row_value)<>'object' OR row_value-ARRAY['dimensions','metrics']<>'{}'::jsonb OR
   NOT row_value ?& ARRAY['dimensions','metrics'] OR jsonb_typeof(row_value->'dimensions')<>'array' OR
   jsonb_array_length(row_value->'dimensions')<>jsonb_array_length(dimensions) OR jsonb_typeof(row_value->'metrics')<>'array' OR
   jsonb_array_length(row_value->'metrics')<>4 THEN RETURN false; END IF;
   FOR i IN 0..3 LOOP
    column_value:=row_value->'metrics'->i;
    IF jsonb_typeof(column_value)<>'string' OR
    (i<3 AND column_value#>>'{}' !~ '^(0|[1-9][0-9]{0,17})$') OR
    (i=3 AND column_value#>>'{}' !~ '^(0|[1-9][0-9]{0,17})(\.[0-9]{1,18})?$') OR
    (i=3 AND value->'definitions'->i->>'type'='TYPE_INTEGER' AND column_value#>>'{}' !~ '^(0|[1-9][0-9]{0,17})$') THEN RETURN false; END IF;
   END LOOP;
   FOR column_value IN SELECT a FROM jsonb_array_elements(row_value->'dimensions') a LOOP
    IF jsonb_typeof(column_value)<>'string' OR octet_length(column_value#>>'{}')>1024 OR column_value#>>'{}' ~ '[[:cntrl:]]' THEN RETURN false; END IF;
   END LOOP;
   IF key IN ('daily','acquisition','devices') AND
   ((row_value->'dimensions'->>0)!~'^[0-9]{8}$' OR row_value->'dimensions'->>0<to_char(since_at,'YYYYMMDD') OR row_value->'dimensions'->>0>to_char(until_at,'YYYYMMDD')) THEN RETURN false; END IF;
   IF key='landing' AND row_value->'dimensions'->>0<>'(not set)' AND
   (left(row_value->'dimensions'->>0,1)<>'/' OR left(row_value->'dimensions'->>0,2)='//' OR row_value->'dimensions'->>0 ~ '[?#@\\]') THEN RETURN false; END IF;
  END LOOP;
 END LOOP;
 RETURN true;
EXCEPTION WHEN OTHERS THEN RETURN false;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_workspace_valid(jsonb,uuid,uuid,date,date) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_sync_finish(job uuid,token uuid,value jsonb)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,state text,before_job_revision bigint,job_revision bigint,
 before_connection_revision bigint,connection_revision bigint,snapshot_id uuid,before_snapshot_revision bigint,snapshot_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE j app.analytics_sync_jobs; c app.integration_connections; saved app.analytics_snapshots; failure text; next_connection bigint; now_at timestamptz;
BEGIN
 PERFORM app.analytics_writer_lock();
 SELECT * INTO j FROM app.analytics_sync_jobs a WHERE a.id=job AND a.state='running' AND a.lease_token=token
 AND a.lease_until>clock_timestamp() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict'; END IF;
 IF j.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=j.connection_id FOR UPDATE;
 IF NOT app.analytics_job_allowed(job,token) THEN
  failure:='connection_changed';
  IF NOT app.authorization_allowed(j.requested_by,'clients.view',j.client_id) OR NOT app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id) OR
  NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=j.client_id AND a.archived_at IS NULL) THEN failure:='authorization_required'; END IF;
 ELSIF value IS NULL THEN failure:='provider_unavailable';
 ELSIF NOT app.analytics_workspace_valid(value,j.client_id,j.connection_id,j.since,j.until) THEN RAISE invalid_parameter_value;
 END IF;
 now_at:=clock_timestamp(); next_connection:=c.revision;
 IF failure IS NULL THEN
  IF c.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
  SELECT * INTO saved FROM app.analytics_snapshots a WHERE a.connection_id=j.connection_id AND a.generation=j.generation AND a.since=j.since AND a.until=j.until FOR UPDATE;
  IF saved.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
  INSERT INTO app.analytics_snapshots(id,client_id,connection_id,generation,since,until,workspace,revision,synced_at)
  VALUES(coalesce(saved.id,gen_random_uuid()),j.client_id,j.connection_id,j.generation,j.since,j.until,value,coalesce(saved.revision,0)+1,now_at)
  ON CONFLICT ON CONSTRAINT analytics_snapshot_period DO UPDATE SET workspace=EXCLUDED.workspace,revision=EXCLUDED.revision,synced_at=EXCLUDED.synced_at;
  next_connection:=c.revision+1;
  UPDATE app.integration_connections a SET state='connected',revision=next_connection,updated_at=greatest(now_at,a.updated_at) WHERE a.id=c.id;
 END IF;
 UPDATE app.analytics_sync_jobs a SET state=CASE WHEN failure IS NULL THEN 'succeeded' ELSE 'failed' END,reason=failure,
 lease_token=NULL,lease_until=NULL,finished_at=now_at,updated_at=greatest(now_at,a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
 RETURN QUERY SELECT j.id,j.client_id,j.connection_id,CASE WHEN failure IS NULL THEN 'succeeded'::text ELSE 'failed'::text END,
 j.revision,j.revision+1,c.revision,next_connection,
 CASE WHEN failure IS NULL THEN (SELECT a.id FROM app.analytics_snapshots a WHERE a.connection_id=j.connection_id AND a.generation=j.generation AND a.since=j.since AND a.until=j.until) ELSE NULL::uuid END,
 CASE WHEN failure IS NULL THEN coalesce(saved.revision,0) ELSE 0::bigint END,
 CASE WHEN failure IS NULL THEN coalesce(saved.revision,0)+1 ELSE 0::bigint END;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_sync_finish(uuid,uuid,jsonb) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_workspace_read(actor uuid,client uuid,connection uuid,since_at date,until_at date)
RETURNS TABLE(job_id uuid,job_state text,reason text,job_updated_at timestamptz,last_synced_at timestamptz,workspace jsonb)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'analytics.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client AND a.provider='ga4';
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF since_at IS NULL OR until_at IS NULL OR since_at<DATE '2000-01-01' OR until_at>=DATE '10000-01-01' OR until_at<since_at OR until_at-since_at>30 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT j.id,j.state,j.reason,j.updated_at,s.synced_at,s.workspace
 FROM (SELECT 1) one LEFT JOIN LATERAL(SELECT a.id,a.state,a.reason,a.updated_at FROM app.analytics_sync_jobs a
 WHERE a.client_id=client AND a.connection_id=connection AND a.generation=c.generation AND a.since=since_at AND a.until=until_at ORDER BY a.created_at DESC,a.id DESC LIMIT 1) j ON true
 LEFT JOIN LATERAL(SELECT a.synced_at,a.workspace FROM app.analytics_snapshots a WHERE a.client_id=client AND a.connection_id=connection
 AND a.generation=c.generation AND a.since=since_at AND a.until=until_at AND a.synced_at>clock_timestamp()-INTERVAL '90 days'
 AND c.state='connected') s ON true;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_workspace_read(uuid,uuid,uuid,date,date) FROM PUBLIC;

-- Analytics view independently lists only safe GA4 metadata; it never implies
-- integrations.view/manage or permission to read provider account/credentials.
-- +goose StatementBegin
CREATE FUNCTION app.analytics_connection_list(actor uuid,client uuid,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'analytics.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 26 OR after_id='00000000-0000-0000-0000-000000000000'::uuid THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at FROM app.integration_connections c
 WHERE c.client_id=client AND c.provider='ga4' AND (after_id IS NULL OR c.id>after_id) ORDER BY c.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_connection_list(uuid,uuid,uuid,integer) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.analytics_snapshots_prune(page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM app.analytics_writer_lock();
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 100 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY DELETE FROM app.analytics_snapshots a WHERE a.id IN
 (SELECT s.id FROM app.analytics_snapshots s WHERE s.synced_at<=clock_timestamp()-INTERVAL '90 days' ORDER BY s.synced_at,s.id LIMIT page_limit FOR UPDATE)
 RETURNING a.id,a.client_id,a.revision;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_snapshots_prune(integer) FROM PUBLIC;


-- +goose Up
-- Existing #27. Shared durable work and admission; distinct measured periods.
SELECT pg_advisory_xact_lock(871092650209);
SELECT pg_advisory_xact_lock(871092650210);

-- +goose StatementBegin
CREATE FUNCTION app.commerce_period_valid(start_at timestamptz,end_at timestamptz,currency text) RETURNS boolean
LANGUAGE sql IMMUTABLE SET search_path=pg_catalog SET timezone='UTC' AS $$
 SELECT coalesce(start_at>=TIMESTAMPTZ '2000-01-01 00:00:00+00' AND end_at<TIMESTAMPTZ '10000-01-01 00:00:00+00'
 AND end_at>start_at AND end_at-start_at<=INTERVAL '31 days'
 AND date_trunc('second',start_at)=start_at AND date_trunc('second',end_at)=end_at
 AND currency IN ('USD','EUR','GBP','TRY','JPY','KWD'),false);
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_period_valid(timestamptz,timestamptz,text) FROM PUBLIC;

ALTER TABLE app.analytics_sync_jobs
 ADD COLUMN provider text NOT NULL DEFAULT 'ga4',
 ADD COLUMN start_at timestamptz, ADD COLUMN end_at timestamptz, ADD COLUMN currency text,
 ALTER COLUMN since DROP NOT NULL, ALTER COLUMN until DROP NOT NULL,
 ADD CONSTRAINT analytics_jobs_provider_period CHECK(coalesce(
 (provider='ga4' AND since IS NOT NULL AND until IS NOT NULL AND start_at IS NULL AND end_at IS NULL AND currency IS NULL) OR
 (provider='woocommerce' AND since IS NULL AND until IS NULL AND app.commerce_period_valid(start_at,end_at,currency)),false));
ALTER TABLE app.analytics_snapshots
 ADD COLUMN provider text NOT NULL DEFAULT 'ga4',
 ADD COLUMN start_at timestamptz, ADD COLUMN end_at timestamptz, ADD COLUMN currency text,
 ALTER COLUMN since DROP NOT NULL, ALTER COLUMN until DROP NOT NULL,
 ADD CONSTRAINT analytics_snapshots_provider_period CHECK(coalesce(
 (provider='ga4' AND since IS NOT NULL AND until IS NOT NULL AND start_at IS NULL AND end_at IS NULL AND currency IS NULL) OR
 (provider='woocommerce' AND since IS NULL AND until IS NULL AND app.commerce_period_valid(start_at,end_at,currency)),false)),
 DROP CONSTRAINT analytics_snapshot_period,
 ADD CONSTRAINT analytics_snapshot_period UNIQUE NULLS NOT DISTINCT(connection_id,generation,provider,since,until,start_at,end_at,currency);
CREATE INDEX analytics_jobs_provider_claim ON app.analytics_sync_jobs(provider,state,lease_until,created_at,id) WHERE state IN ('queued','running');
CREATE INDEX commerce_jobs_client_period ON app.analytics_sync_jobs(client_id,connection_id,generation,start_at,end_at,currency,created_at DESC,id DESC) WHERE provider='woocommerce';
CREATE INDEX commerce_snapshots_client_period ON app.analytics_snapshots(client_id,connection_id,generation,start_at,end_at,currency) WHERE provider='woocommerce';

-- +goose StatementBegin
CREATE FUNCTION app.commerce_connection_create(actor uuid,client uuid,connection uuid,account text)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF connection IS NULL OR connection='00000000-0000-0000-0000-000000000000'::uuid OR
 account IS NULL OR NOT app.integration_account_valid('woocommerce',account) THEN RAISE invalid_parameter_value; END IF;
 BEGIN
  INSERT INTO app.integration_connections(id,client_id,provider,provider_account_id) VALUES(connection,client,'woocommerce',account);
 EXCEPTION WHEN unique_violation THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration connection conflict'; END;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at
 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_connection_create(uuid,uuid,uuid,text) FROM PUBLIC;
-- +goose StatementBegin
CREATE FUNCTION app.commerce_sync_enqueue(actor uuid,client uuid,connection uuid,expected_revision bigint,
 expected_generation bigint,expected_credential bigint,start_at timestamptz,end_at timestamptz,currency_code text,job uuid,credential_changed boolean)
RETURNS TABLE(job_id uuid,connection_revision bigint,job_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections; s app.integration_credentials; next_revision bigint;
BEGIN
 PERFORM app.analytics_writer_lock();
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client AND a.provider='woocommerce'
 AND a.state IN ('pending','connected','reauthorization_required') FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=connection;
 IF s.connection_id IS NULL OR s.generation<>c.generation OR c.revision IS DISTINCT FROM expected_revision OR
 c.generation IS DISTINCT FROM expected_generation OR s.revision IS DISTINCT FROM expected_credential OR
 c.revision=9223372036854775807 THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict'; END IF;
 IF NOT app.commerce_period_valid(start_at,end_at,currency_code) OR job IS NULL OR job='00000000-0000-0000-0000-000000000000'::uuid OR
 credential_changed IS NULL THEN RAISE invalid_parameter_value; END IF;
 -- Replacing credentials must atomically interrupt older queued/running work.
 -- It does not mutate those jobs here: require the caller to cancel and audit
 -- them through analytics_sync_cancel before enqueueing this replacement.
 IF EXISTS(SELECT 1 FROM app.analytics_sync_jobs j WHERE j.connection_id=connection AND j.state IN ('queued','running')) THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict';
 END IF;
 next_revision:=c.revision;
 IF credential_changed THEN
  next_revision:=c.revision+1;
  UPDATE app.integration_connections a SET state='pending',revision=next_revision,updated_at=greatest(clock_timestamp(),a.updated_at) WHERE a.id=connection;
 END IF;
 INSERT INTO app.analytics_sync_jobs(id,client_id,connection_id,requested_by,since,until,connection_revision,generation,credential_revision,provider,start_at,end_at,currency)
 VALUES(job,client,connection,actor,NULL,NULL,next_revision,c.generation,s.revision,'woocommerce',start_at,end_at,currency_code);
 RETURN QUERY SELECT job,next_revision,1::bigint;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_sync_enqueue(uuid,uuid,uuid,bigint,bigint,bigint,timestamptz,timestamptz,text,uuid,boolean) FROM PUBLIC;
-- +goose StatementBegin
CREATE FUNCTION app.commerce_sync_cancel(actor uuid,client uuid,connection uuid)
RETURNS TABLE(id uuid,before_revision bigint,after_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM app.analytics_writer_lock();
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) OR
 NOT EXISTS(SELECT 1 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client AND c.provider='woocommerce'
 AND c.state IN ('pending','connected','reauthorization_required')) THEN RAISE no_data_found; END IF;
 RETURN QUERY UPDATE app.analytics_sync_jobs j SET state='failed',reason='connection_changed',lease_token=NULL,lease_until=NULL,
 finished_at=clock_timestamp(),updated_at=greatest(clock_timestamp(),j.updated_at),revision=j.revision+1
 WHERE j.connection_id=connection AND j.client_id=client AND j.state IN ('queued','running') AND j.revision<9223372036854775807
 RETURNING j.id,j.revision-1,j.revision;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_sync_cancel(uuid,uuid,uuid) FROM PUBLIC;
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.analytics_job_allowed(job uuid,token uuid) RETURNS boolean
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 RETURN EXISTS(SELECT 1 FROM app.analytics_sync_jobs j JOIN app.integration_connections c ON c.id=j.connection_id
 JOIN app.integration_credentials s ON s.connection_id=c.id JOIN app.clients a ON a.id=j.client_id
 WHERE j.id=job AND j.state='running' AND j.lease_token=token AND j.lease_until>clock_timestamp() AND a.archived_at IS NULL
 AND c.client_id=j.client_id AND c.provider=j.provider AND c.state IN ('pending','connected','reauthorization_required')
 AND c.revision=j.connection_revision AND c.generation=j.generation AND s.generation=j.generation AND s.revision=j.credential_revision
 AND app.authorization_allowed(j.requested_by,'clients.view',j.client_id) AND app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id));
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_job_allowed(uuid,uuid) FROM PUBLIC;
-- +goose StatementBegin
CREATE FUNCTION app.provider_sync_claim(preferred_provider text)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,requested_by uuid,since date,until date,provider text,start_at timestamptz,end_at timestamptz,currency text,state text,
 before_revision bigint,revision bigint,lease_token uuid,property_account text,envelope bytea)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE j app.analytics_sync_jobs; c app.integration_connections; s app.integration_credentials; failure text; next_token uuid;
BEGIN
 IF preferred_provider IS NULL OR preferred_provider NOT IN ('ga4','woocommerce') THEN RAISE invalid_parameter_value; END IF;
 PERFORM app.analytics_writer_lock();
 IF (SELECT count(*) FROM app.analytics_sync_jobs a WHERE a.state='running' AND a.lease_until>clock_timestamp())>=2 THEN RETURN; END IF;
 SELECT * INTO j FROM app.analytics_sync_jobs a WHERE a.provider=preferred_provider AND (a.state='queued' OR (a.state='running' AND a.lease_until<=clock_timestamp()))
 ORDER BY a.created_at,a.id LIMIT 1 FOR UPDATE;
 IF NOT FOUND THEN RETURN; END IF;
 IF j.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=j.connection_id FOR UPDATE;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=j.connection_id;
 IF NOT app.authorization_allowed(j.requested_by,'clients.view',j.client_id) OR
 NOT app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=j.client_id AND a.archived_at IS NULL) THEN failure:='authorization_required';
 ELSIF c.client_id IS DISTINCT FROM j.client_id OR c.provider IS DISTINCT FROM j.provider OR
 c.state NOT IN ('pending','connected','reauthorization_required') OR c.revision IS DISTINCT FROM j.connection_revision OR
 c.generation IS DISTINCT FROM j.generation OR s.generation IS DISTINCT FROM j.generation OR s.revision IS DISTINCT FROM j.credential_revision THEN failure:='connection_changed';
 ELSIF j.attempts>=3 THEN failure:='interrupted'; END IF;
 IF failure IS NOT NULL THEN
  UPDATE app.analytics_sync_jobs a SET state='failed',reason=failure,lease_token=NULL,lease_until=NULL,
  finished_at=clock_timestamp(),updated_at=greatest(clock_timestamp(),a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
  RETURN QUERY SELECT j.id,j.client_id,j.connection_id,j.requested_by,j.since,j.until,j.provider,j.start_at,j.end_at,j.currency,'failed'::text,j.revision,j.revision+1,NULL::uuid,NULL::text,NULL::bytea;
  RETURN;
 END IF;
 next_token:=gen_random_uuid();
 UPDATE app.analytics_sync_jobs a SET state='running',attempts=a.attempts+1,lease_token=next_token,lease_until=clock_timestamp()+INTERVAL '180 seconds',
 updated_at=greatest(clock_timestamp(),a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
 RETURN QUERY SELECT j.id,j.client_id,j.connection_id,j.requested_by,j.since,j.until,j.provider,j.start_at,j.end_at,j.currency,'running'::text,j.revision,j.revision+1,next_token,c.provider_account_id,s.envelope;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.provider_sync_claim(text) FROM PUBLIC;
-- Existing GA4 entrypoint remains provider-specific.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.analytics_sync_claim()
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,requested_by uuid,since date,until date,state text,
 before_revision bigint,revision bigint,lease_token uuid,property_account text,envelope bytea)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
 SELECT a.job_id,a.client_id,a.connection_id,a.requested_by,a.since,a.until,a.state,a.before_revision,a.revision,a.lease_token,a.property_account,a.envelope
 FROM app.provider_sync_claim('ga4') a;
$$;
-- +goose StatementEnd


-- Validate the minimal public shape independently of Go. No expanded provider
-- object, account, key, customer data or unconstrained exact decimal is stored.
-- +goose StatementBegin
CREATE FUNCTION app.commerce_workspace_valid(value jsonb,client uuid,connection uuid,start_at timestamptz,end_at timestamptz,currency text) RETURNS boolean
LANGUAGE plpgsql STABLE SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE report jsonb; row_value jsonb; key text; name text; rows_key text; keys text[]; row_keys text[];
 exponent integer; first_at timestamptz; last_at timestamptz; created timestamptz; field text;
 orders_count integer; total_lines integer:=0; orders_ids numeric[]:=ARRAY[]::numeric[];
 previous numeric; current_id numeric; parent numeric; product numeric; variation numeric;
 previous_product numeric:=-1; previous_variation numeric:=-1; quantity numeric; order_count integer; line_count integer;
 grand numeric:=0; refunded numeric:=0; remainder numeric:=0; refund_events numeric:=0;
 row_grand numeric; row_refunded numeric; row_remainder numeric; net numeric; tax numeric; line_grand numeric;
BEGIN
 IF NOT app.commerce_period_valid(start_at,end_at,currency) OR client IS NULL OR connection IS NULL OR
 value IS NULL OR jsonb_typeof(value)<>'object' OR octet_length(value::text)>2097152 OR
 value-ARRAY['orders','refunds','products','collected_from','collected_through']<>'{}'::jsonb OR
 NOT value ?& ARRAY['orders','refunds','products','collected_from','collected_through'] THEN RETURN false; END IF;
 FOREACH key IN ARRAY ARRAY['collected_from','collected_through'] LOOP
  IF jsonb_typeof(value->key)<>'string' OR value->>key !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?Z$' THEN RETURN false; END IF;
  created:=(value->>key)::timestamptz;
  field:=to_char(created,'YYYY-MM-DD"T"HH24:MI:SS') || CASE WHEN extract(microseconds FROM created)::bigint%1000000=0 THEN ''
   ELSE '.' || rtrim(to_char(created,'US'),'0') END || 'Z';
  IF field IS DISTINCT FROM value->>key OR created<TIMESTAMPTZ '2000-01-01' OR created>=TIMESTAMPTZ '10000-01-01' THEN RETURN false; END IF;
 END LOOP;
 first_at:=(value->>'collected_from')::timestamptz; last_at:=(value->>'collected_through')::timestamptz;
 IF last_at<first_at OR last_at-first_at>INTERVAL '121 seconds' THEN RETURN false; END IF;
 exponent:=CASE currency WHEN 'JPY' THEN 0 WHEN 'KWD' THEN 3 ELSE 2 END;
 FOREACH name IN ARRAY ARRAY['orders','refunds','products'] LOOP
  report:=value->name; rows_key:=name;
  keys:=ARRAY['client_id','connection_id','api_version','currency','currency_exponent','start','end',rows_key];
  IF name='orders' THEN keys:=keys || ARRAY['grand_total_minor','lifetime_refund_minor','remainder_minor'];
  ELSIF name='refunds' THEN keys:=keys || ARRAY['amount_minor']; END IF;
  IF jsonb_typeof(report)<>'object' OR report-keys<>'{}'::jsonb OR NOT report ?& keys OR
  report->>'client_id' IS DISTINCT FROM client::text OR report->>'connection_id' IS DISTINCT FROM connection::text OR
  report->>'api_version' IS DISTINCT FROM 'wc/v3' OR report->>'currency' IS DISTINCT FROM currency OR
  report->'currency_exponent' IS DISTINCT FROM to_jsonb(exponent) OR
  report->>'start' IS DISTINCT FROM to_char(start_at,'YYYY-MM-DD"T"HH24:MI:SS"Z"') OR
  report->>'end' IS DISTINCT FROM to_char(end_at,'YYYY-MM-DD"T"HH24:MI:SS"Z"') OR
  jsonb_typeof(report->rows_key)<>'array' THEN RETURN false; END IF;
  IF jsonb_array_length(report->rows_key)>(CASE name WHEN 'products' THEN 1000 ELSE 500 END) THEN RETURN false; END IF;
  IF name='orders' THEN orders_count:=jsonb_array_length(report->rows_key); END IF;
  FOREACH key IN ARRAY keys LOOP
   IF key IN ('client_id','connection_id','api_version','currency','start','end') AND jsonb_typeof(report->key)<>'string' THEN RETURN false; END IF;
   IF key IN ('grand_total_minor','lifetime_refund_minor','remainder_minor','amount_minor') AND
   (jsonb_typeof(report->key)<>'string' OR report->>key !~ '^(0|[1-9][0-9]{0,23})$') THEN RETURN false; END IF;
  END LOOP;
  previous:=0;
  FOR row_value IN SELECT a FROM jsonb_array_elements(report->rows_key) a LOOP
   row_keys:=CASE name WHEN 'orders' THEN ARRAY['id','status','created_at','grand_total_minor','lifetime_refund_minor','remainder_minor']
   WHEN 'refunds' THEN ARRAY['id','parent_id','created_at','amount_minor']
   ELSE ARRAY['product_id','variation_id','quantity','order_count','line_count','total_minor','tax_minor','line_grand_minor'] END;
   IF jsonb_typeof(row_value)<>'object' OR row_value-row_keys<>'{}'::jsonb OR NOT row_value ?& row_keys THEN RETURN false; END IF;
   FOREACH key IN ARRAY row_keys LOOP
    IF jsonb_typeof(row_value->key)<>'string' THEN RETURN false; END IF;
    IF key NOT IN ('status','created_at') AND row_value->>key !~ '^(0|[1-9][0-9]{0,22})$' THEN RETURN false; END IF;
    IF key IN ('id','parent_id') AND row_value->>key !~ '^[1-9][0-9]{0,17}$' THEN RETURN false; END IF;
    IF key IN ('product_id','variation_id') AND length(row_value->>key)>18 THEN RETURN false; END IF;
   END LOOP;
   IF name IN ('orders','refunds') THEN
    current_id:=(row_value->>'id')::numeric;
    IF current_id<=previous OR row_value->>'created_at' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$' THEN RETURN false; END IF;
    previous:=current_id; created:=(row_value->>'created_at')::timestamptz;
    IF to_char(created,'YYYY-MM-DD"T"HH24:MI:SS"Z"') IS DISTINCT FROM row_value->>'created_at' OR created<start_at OR created>=end_at THEN RETURN false; END IF;
   END IF;
   IF name='orders' THEN
    IF row_value->>'status' NOT IN ('pending','processing','on-hold','completed','cancelled','refunded','failed','trash') OR
    length(row_value->>'grand_total_minor')>18 OR length(row_value->>'lifetime_refund_minor')>20 OR length(row_value->>'remainder_minor')>18 THEN RETURN false; END IF;
    row_grand:=(row_value->>'grand_total_minor')::numeric; row_refunded:=(row_value->>'lifetime_refund_minor')::numeric; row_remainder:=(row_value->>'remainder_minor')::numeric;
    IF row_grand<>row_refunded+row_remainder THEN RETURN false; END IF;
    grand:=grand+row_grand; refunded:=refunded+row_refunded; remainder:=remainder+row_remainder; orders_ids:=array_append(orders_ids,current_id);
   ELSIF name='refunds' THEN
    parent:=(row_value->>'parent_id')::numeric;
    IF current_id=parent OR current_id=ANY(orders_ids) OR length(row_value->>'amount_minor')>18 THEN RETURN false; END IF;
    refund_events:=refund_events+(row_value->>'amount_minor')::numeric;
   ELSE
    product:=(row_value->>'product_id')::numeric; variation:=(row_value->>'variation_id')::numeric;
    quantity:=(row_value->>'quantity')::numeric; order_count:=(row_value->>'order_count')::integer; line_count:=(row_value->>'line_count')::integer;
    net:=(row_value->>'total_minor')::numeric; tax:=(row_value->>'tax_minor')::numeric; line_grand:=(row_value->>'line_grand_minor')::numeric;
    IF product<previous_product OR (product=previous_product AND variation<=previous_variation) OR quantity<=0 OR
    length(row_value->>'order_count')>3 OR length(row_value->>'line_count')>5 OR order_count<1 OR order_count>orders_count OR
    line_count<order_count OR line_count>order_count*50 OR quantity<line_count OR quantity>line_count::numeric*999999999999999999 OR
    net>line_count::numeric*999999999999999999 OR tax>line_count::numeric*999999999999999999 OR line_grand<>net+tax THEN RETURN false; END IF;
    total_lines:=total_lines+line_count; previous_product:=product; previous_variation:=variation;
   END IF;
  END LOOP;
 END LOOP;
 RETURN grand::text=value->'orders'->>'grand_total_minor' AND refunded::text=value->'orders'->>'lifetime_refund_minor'
 AND remainder::text=value->'orders'->>'remainder_minor' AND refund_events::text=value->'refunds'->>'amount_minor'
 AND total_lines<=orders_count*50;
EXCEPTION WHEN OTHERS THEN RETURN false;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_workspace_valid(jsonb,uuid,uuid,timestamptz,timestamptz,text) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.provider_sync_finish(selected_provider text,job uuid,token uuid,value jsonb)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,state text,before_job_revision bigint,job_revision bigint,
 before_connection_revision bigint,connection_revision bigint,snapshot_id uuid,before_snapshot_revision bigint,snapshot_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE j app.analytics_sync_jobs; c app.integration_connections; saved app.analytics_snapshots; failure text; next_connection bigint; now_at timestamptz;
BEGIN
 IF selected_provider IS NULL OR selected_provider NOT IN ('ga4','woocommerce') THEN RAISE invalid_parameter_value; END IF;
 PERFORM app.analytics_writer_lock();
 SELECT * INTO j FROM app.analytics_sync_jobs a WHERE a.id=job AND a.provider=selected_provider AND a.state='running' AND a.lease_token=token
 AND a.lease_until>clock_timestamp() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict'; END IF;
 IF j.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=j.connection_id FOR UPDATE;
 IF NOT app.analytics_job_allowed(job,token) THEN
  failure:='connection_changed';
  IF NOT app.authorization_allowed(j.requested_by,'clients.view',j.client_id) OR NOT app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id) OR
  NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=j.client_id AND a.archived_at IS NULL) THEN failure:='authorization_required'; END IF;
 ELSIF value IS NULL THEN failure:='provider_unavailable';
 ELSIF (j.provider='ga4' AND NOT app.analytics_workspace_valid(value,j.client_id,j.connection_id,j.since,j.until)) OR
 (j.provider='woocommerce' AND NOT app.commerce_workspace_valid(value,j.client_id,j.connection_id,j.start_at,j.end_at,j.currency)) THEN RAISE invalid_parameter_value;
 END IF;
 now_at:=clock_timestamp(); next_connection:=c.revision;
 IF failure IS NULL THEN
  IF c.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
  SELECT * INTO saved FROM app.analytics_snapshots a WHERE a.connection_id=j.connection_id AND a.generation=j.generation AND a.provider=j.provider AND a.since IS NOT DISTINCT FROM j.since AND a.until IS NOT DISTINCT FROM j.until AND a.start_at IS NOT DISTINCT FROM j.start_at AND a.end_at IS NOT DISTINCT FROM j.end_at AND a.currency IS NOT DISTINCT FROM j.currency FOR UPDATE;
  IF saved.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
  INSERT INTO app.analytics_snapshots(id,client_id,connection_id,generation,since,until,workspace,revision,synced_at,provider,start_at,end_at,currency)
  VALUES(coalesce(saved.id,gen_random_uuid()),j.client_id,j.connection_id,j.generation,j.since,j.until,value,coalesce(saved.revision,0)+1,now_at,j.provider,j.start_at,j.end_at,j.currency)
  ON CONFLICT ON CONSTRAINT analytics_snapshot_period DO UPDATE SET workspace=EXCLUDED.workspace,revision=EXCLUDED.revision,synced_at=EXCLUDED.synced_at;
  next_connection:=c.revision+1;
  UPDATE app.integration_connections a SET state='connected',revision=next_connection,updated_at=greatest(now_at,a.updated_at) WHERE a.id=c.id;
 END IF;
 UPDATE app.analytics_sync_jobs a SET state=CASE WHEN failure IS NULL THEN 'succeeded' ELSE 'failed' END,reason=failure,
 lease_token=NULL,lease_until=NULL,finished_at=now_at,updated_at=greatest(now_at,a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
 RETURN QUERY SELECT j.id,j.client_id,j.connection_id,CASE WHEN failure IS NULL THEN 'succeeded'::text ELSE 'failed'::text END,
 j.revision,j.revision+1,c.revision,next_connection,
 CASE WHEN failure IS NULL THEN (SELECT a.id FROM app.analytics_snapshots a WHERE a.connection_id=j.connection_id AND a.generation=j.generation AND a.provider=j.provider AND a.since IS NOT DISTINCT FROM j.since AND a.until IS NOT DISTINCT FROM j.until AND a.start_at IS NOT DISTINCT FROM j.start_at AND a.end_at IS NOT DISTINCT FROM j.end_at AND a.currency IS NOT DISTINCT FROM j.currency) ELSE NULL::uuid END,
 CASE WHEN failure IS NULL THEN coalesce(saved.revision,0) ELSE 0::bigint END,
 CASE WHEN failure IS NULL THEN coalesce(saved.revision,0)+1 ELSE 0::bigint END;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.provider_sync_finish(text,uuid,uuid,jsonb) FROM PUBLIC;
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.analytics_sync_finish(job uuid,token uuid,value jsonb)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,state text,before_job_revision bigint,job_revision bigint,
 before_connection_revision bigint,connection_revision bigint,snapshot_id uuid,before_snapshot_revision bigint,snapshot_revision bigint)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
 SELECT * FROM app.provider_sync_finish('ga4',job,token,value);
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.analytics_sync_finish(uuid,uuid,jsonb) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.commerce_sync_finish(job uuid,token uuid,value jsonb)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,state text,before_job_revision bigint,job_revision bigint,
 before_connection_revision bigint,connection_revision bigint,snapshot_id uuid,before_snapshot_revision bigint,snapshot_revision bigint)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
 SELECT * FROM app.provider_sync_finish('woocommerce',job,token,value);
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_sync_finish(uuid,uuid,jsonb) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.commerce_workspace_read(actor uuid,client uuid,connection uuid,start_value timestamptz,end_value timestamptz,currency_code text)
RETURNS TABLE(job_id uuid,job_state text,reason text,job_updated_at timestamptz,last_synced_at timestamptz,workspace jsonb)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'analytics.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client AND a.provider='woocommerce';
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF NOT app.commerce_period_valid(start_value,end_value,currency_code) THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT j.id,j.state,j.reason,j.updated_at,s.synced_at,s.workspace
 FROM (SELECT 1) one LEFT JOIN LATERAL(SELECT a.id,a.state,a.reason,a.updated_at FROM app.analytics_sync_jobs a
 WHERE a.client_id=client AND a.connection_id=connection AND a.generation=c.generation AND a.provider='woocommerce' AND a.start_at=start_value AND a.end_at=end_value AND a.currency=currency_code ORDER BY a.created_at DESC,a.id DESC LIMIT 1) j ON true
 LEFT JOIN LATERAL(SELECT a.synced_at,a.workspace FROM app.analytics_snapshots a WHERE a.client_id=client AND a.connection_id=connection
 AND a.generation=c.generation AND a.provider='woocommerce' AND a.start_at=start_value AND a.end_at=end_value AND a.currency=currency_code AND a.synced_at>clock_timestamp()-INTERVAL '90 days'
 AND c.state='connected') s ON true;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_workspace_read(uuid,uuid,uuid,timestamptz,timestamptz,text) FROM PUBLIC;
-- +goose StatementBegin
CREATE FUNCTION app.commerce_connection_list(actor uuid,client uuid,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'analytics.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 26 OR after_id='00000000-0000-0000-0000-000000000000'::uuid THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at FROM app.integration_connections c
 WHERE c.client_id=client AND c.provider='woocommerce' AND (after_id IS NULL OR c.id>after_id) ORDER BY c.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.commerce_connection_list(uuid,uuid,uuid,integer) FROM PUBLIC;


-- +goose Up
-- Existing #25: account-calendar reports share the global durable admission.
SELECT pg_advisory_xact_lock(871092650209);
SELECT pg_advisory_xact_lock(871092650210);

ALTER TABLE app.analytics_sync_jobs DROP CONSTRAINT analytics_jobs_provider_period,
 ADD CONSTRAINT analytics_jobs_provider_period CHECK(coalesce(
 (provider IN ('ga4','meta_ads') AND since IS NOT NULL AND until IS NOT NULL AND start_at IS NULL AND end_at IS NULL AND currency IS NULL) OR
 (provider='woocommerce' AND since IS NULL AND until IS NULL AND app.commerce_period_valid(start_at,end_at,currency)),false));
ALTER TABLE app.analytics_snapshots DROP CONSTRAINT analytics_snapshots_provider_period,
 ADD CONSTRAINT analytics_snapshots_provider_period CHECK(coalesce(
 (provider IN ('ga4','meta_ads') AND since IS NOT NULL AND until IS NOT NULL AND start_at IS NULL AND end_at IS NULL AND currency IS NULL) OR
 (provider='woocommerce' AND since IS NULL AND until IS NULL AND app.commerce_period_valid(start_at,end_at,currency)),false));

-- +goose StatementBegin
CREATE FUNCTION app.marketing_connection_create(actor uuid,client uuid,connection uuid,account text)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client AND c.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF connection IS NULL OR connection='00000000-0000-0000-0000-000000000000'::uuid OR
 account IS NULL OR account !~ '^[1-9][0-9]{0,19}$' THEN RAISE invalid_parameter_value; END IF;
 BEGIN
  INSERT INTO app.integration_connections(id,client_id,provider,provider_account_id) VALUES(connection,client,'meta_ads',account);
 EXCEPTION WHEN unique_violation THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration connection conflict'; END;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at
 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_connection_create(uuid,uuid,uuid,text) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.marketing_sync_enqueue(actor uuid,client uuid,connection uuid,expected_revision bigint,
 expected_generation bigint,expected_credential bigint,since_at date,until_at date,job uuid,credential_changed boolean)
RETURNS TABLE(job_id uuid,connection_revision bigint,job_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections; s app.integration_credentials; next_revision bigint;
BEGIN
 PERFORM app.analytics_writer_lock();
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client AND a.provider='meta_ads'
 AND a.state IN ('pending','connected','reauthorization_required') FOR UPDATE;
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=connection;
 IF s.connection_id IS NULL OR s.generation<>c.generation OR c.revision IS DISTINCT FROM expected_revision OR
 c.generation IS DISTINCT FROM expected_generation OR s.revision IS DISTINCT FROM expected_credential OR
 c.revision=9223372036854775807 THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict'; END IF;
 IF c.provider_account_id !~ '^[1-9][0-9]{0,19}$' OR since_at IS NULL OR until_at IS NULL OR since_at<DATE '2000-01-01' OR until_at>=DATE '10000-01-01' OR
 until_at<since_at OR until_at-since_at>30 OR job IS NULL OR job='00000000-0000-0000-0000-000000000000'::uuid OR
 credential_changed IS NULL THEN RAISE invalid_parameter_value; END IF;
 -- Replacing credentials must atomically interrupt older queued/running work.
 -- It does not mutate those jobs here: require the caller to cancel and audit
 -- them through marketing_sync_cancel before enqueueing this replacement.
 IF EXISTS(SELECT 1 FROM app.analytics_sync_jobs j WHERE j.connection_id=connection AND j.state IN ('queued','running')) THEN
  RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict';
 END IF;
 next_revision:=c.revision;
 IF credential_changed THEN
  next_revision:=c.revision+1;
  UPDATE app.integration_connections a SET state='pending',revision=next_revision,updated_at=greatest(clock_timestamp(),a.updated_at) WHERE a.id=connection;
 END IF;
 INSERT INTO app.analytics_sync_jobs(id,client_id,connection_id,requested_by,since,until,connection_revision,generation,credential_revision,provider)
 VALUES(job,client,connection,actor,since_at,until_at,next_revision,c.generation,s.revision,'meta_ads');
 RETURN QUERY SELECT job,next_revision,1::bigint;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_sync_enqueue(uuid,uuid,uuid,bigint,bigint,bigint,date,date,uuid,boolean) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.marketing_sync_cancel(actor uuid,client uuid,connection uuid)
RETURNS TABLE(id uuid,before_revision bigint,after_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM app.analytics_writer_lock();
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) OR
 NOT EXISTS(SELECT 1 FROM app.integration_connections c WHERE c.id=connection AND c.client_id=client AND c.provider='meta_ads'
 AND c.state IN ('pending','connected','reauthorization_required')) THEN RAISE no_data_found; END IF;
 RETURN QUERY UPDATE app.analytics_sync_jobs j SET state='failed',reason='connection_changed',lease_token=NULL,lease_until=NULL,
 finished_at=clock_timestamp(),updated_at=greatest(clock_timestamp(),j.updated_at),revision=j.revision+1
 WHERE j.connection_id=connection AND j.client_id=client AND j.state IN ('queued','running') AND j.revision<9223372036854775807
 RETURNING j.id,j.revision-1,j.revision;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_sync_cancel(uuid,uuid,uuid) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.marketing_workspace_read(actor uuid,client uuid,connection uuid,since_at date,until_at date)
RETURNS TABLE(job_id uuid,job_state text,reason text,job_updated_at timestamptz,last_synced_at timestamptz,workspace jsonb)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE c app.integration_connections;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'analytics.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=connection AND a.client_id=client AND a.provider='meta_ads';
 IF NOT FOUND THEN RAISE no_data_found; END IF;
 IF since_at IS NULL OR until_at IS NULL OR since_at<DATE '2000-01-01' OR until_at>=DATE '10000-01-01' OR until_at<since_at OR until_at-since_at>30 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT j.id,j.state,j.reason,j.updated_at,s.synced_at,s.workspace
 FROM (SELECT 1) one LEFT JOIN LATERAL(SELECT a.id,a.state,a.reason,a.updated_at FROM app.analytics_sync_jobs a
 WHERE a.client_id=client AND a.connection_id=connection AND a.generation=c.generation AND a.provider='meta_ads' AND a.since=since_at AND a.until=until_at ORDER BY a.created_at DESC,a.id DESC LIMIT 1) j ON true
 LEFT JOIN LATERAL(SELECT a.synced_at,a.workspace FROM app.analytics_snapshots a WHERE a.client_id=client AND a.connection_id=connection
 AND a.generation=c.generation AND a.provider='meta_ads' AND a.since=since_at AND a.until=until_at AND a.synced_at>clock_timestamp()-INTERVAL '90 days'
 AND c.state='connected') s ON true;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_workspace_read(uuid,uuid,uuid,date,date) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.marketing_connection_list(actor uuid,client uuid,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,provider text,state text,revision bigint,created_at timestamptz,updated_at timestamptz)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'analytics.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=client AND a.archived_at IS NULL) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 26 OR after_id='00000000-0000-0000-0000-000000000000'::uuid THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT c.id,c.client_id,c.provider,c.state,c.revision,c.created_at,c.updated_at FROM app.integration_connections c
 WHERE c.client_id=client AND c.provider='meta_ads' AND (after_id IS NULL OR c.id>after_id) ORDER BY c.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_connection_list(uuid,uuid,uuid,integer) FROM PUBLIC;

-- Exact nonnegative ratios: integer quotient/remainder avoids double rounding.
-- +goose StatementBegin
CREATE FUNCTION app.marketing_ratio(numerator numeric,denominator numeric,multiplier numeric) RETURNS text
LANGUAGE sql IMMUTABLE SET search_path=pg_catalog AS $$
 SELECT CASE WHEN denominator=0 THEN NULL ELSE
 (div(q,1000000))::text||'.'||lpad(mod(q,1000000)::text,6,'0') END
 FROM (SELECT div(numerator*multiplier*1000000,denominator)+
 CASE WHEN mod(numerator*multiplier*1000000,denominator)*2>=denominator THEN 1 ELSE 0 END AS q
 WHERE denominator<>0) exact;
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_ratio(numeric,numeric,numeric) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.marketing_metrics_valid(value jsonb,digits integer) RETURNS boolean
LANGUAGE plpgsql IMMUTABLE SET search_path=pg_catalog AS $$
DECLARE spend numeric; impressions numeric; clicks numeric;
BEGIN
 IF value IS NULL OR jsonb_typeof(value)<>'object' OR digits NOT IN (18,20) OR
 value-ARRAY['spend_decimal','impressions','clicks','ctr_percent','cpc_decimal','cpm_decimal']<>'{}'::jsonb OR
 NOT value ?& ARRAY['spend_decimal','impressions','clicks','ctr_percent','cpc_decimal','cpm_decimal'] OR
 jsonb_typeof(value->'spend_decimal')<>'string' OR jsonb_typeof(value->'impressions')<>'string' OR jsonb_typeof(value->'clicks')<>'string' OR
 value->>'spend_decimal' !~ ('^(0|[1-9][0-9]{0,'||(digits-1)::text||'})(\.[0-9]{0,5}[1-9])?$') OR
 value->>'impressions' !~ ('^(0|[1-9][0-9]{0,'||(digits-1)::text||'})$') OR
 value->>'clicks' !~ ('^(0|[1-9][0-9]{0,'||(digits-1)::text||'})$') THEN RETURN false; END IF;
 spend:=(value->>'spend_decimal')::numeric; impressions:=(value->>'impressions')::numeric; clicks:=(value->>'clicks')::numeric;
 RETURN value->'ctr_percent' IS NOT DISTINCT FROM coalesce(to_jsonb(app.marketing_ratio(clicks,impressions,100)),'null'::jsonb) AND
 value->'cpc_decimal' IS NOT DISTINCT FROM coalesce(to_jsonb(app.marketing_ratio(spend,clicks,1)),'null'::jsonb) AND
 value->'cpm_decimal' IS NOT DISTINCT FROM coalesce(to_jsonb(app.marketing_ratio(spend,impressions,1000)),'null'::jsonb);
EXCEPTION WHEN OTHERS THEN RETURN false;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_metrics_valid(jsonb,integer) FROM PUBLIC;

-- Independent public-shape, binding, calendar, arithmetic and interval checks.
-- +goose StatementBegin
CREATE FUNCTION app.marketing_workspace_valid(value jsonb,client uuid,connection uuid,since_at date,until_at date) RETURNS boolean
LANGUAGE plpgsql STABLE SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE r jsonb; day jsonb; key text; timestamp_value timestamptz; canonical text;
 collected_from timestamptz; collected_through timestamptz; date_value date; previous_date date;
 spend numeric:=0; impressions numeric:=0; clicks numeric:=0;
BEGIN
 IF value IS NULL OR jsonb_typeof(value)<>'object' OR octet_length(value::text)>2097152 OR
 value-ARRAY['report','collected_from','collected_through']<>'{}'::jsonb OR NOT value ?& ARRAY['report','collected_from','collected_through'] OR
 client IS NULL OR connection IS NULL OR client='00000000-0000-0000-0000-000000000000'::uuid OR connection='00000000-0000-0000-0000-000000000000'::uuid OR
 since_at IS NULL OR until_at IS NULL OR since_at<DATE '2000-01-01' OR until_at>=DATE '10000-01-01' OR until_at<since_at OR until_at-since_at>30 THEN RETURN false; END IF;
 FOREACH key IN ARRAY ARRAY['collected_from','collected_through'] LOOP
  IF jsonb_typeof(value->key)<>'string' OR value->>key !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{0,5}[1-9])?Z$' THEN RETURN false; END IF;
  timestamp_value:=(value->>key)::timestamptz;
  canonical:=to_char(timestamp_value,'YYYY-MM-DD"T"HH24:MI:SS')||
   CASE WHEN to_char(timestamp_value,'US')='000000' THEN '' ELSE '.'||rtrim(to_char(timestamp_value,'US'),'0') END||'Z';
  IF timestamp_value<TIMESTAMPTZ '2000-01-01 00:00:00+00' OR timestamp_value>=TIMESTAMPTZ '10000-01-01 00:00:00+00' OR value->>key<>canonical THEN RETURN false; END IF;
  IF key='collected_from' THEN collected_from:=timestamp_value; ELSE collected_through:=timestamp_value; END IF;
 END LOOP;
 IF collected_through<collected_from OR collected_through-collected_from>INTERVAL '121 seconds' THEN RETURN false; END IF;
 r:=value->'report';
 IF jsonb_typeof(r)<>'object' OR r-ARRAY['client_id','connection_id','graph_version','currency','timezone','since','until','days','totals','attribution_status']<>'{}'::jsonb OR
 NOT r ?& ARRAY['client_id','connection_id','graph_version','currency','timezone','since','until','days','totals','attribution_status'] OR
 r->>'client_id' IS DISTINCT FROM client::text OR r->>'connection_id' IS DISTINCT FROM connection::text OR
 r->>'graph_version' IS DISTINCT FROM 'v26.0' OR r->>'since' IS DISTINCT FROM to_char(since_at,'YYYY-MM-DD') OR r->>'until' IS DISTINCT FROM to_char(until_at,'YYYY-MM-DD') OR
 r->>'attribution_status' IS DISTINCT FROM 'unavailable' OR jsonb_typeof(r->'currency')<>'string' OR r->>'currency' !~ '^[A-Z]{3}$' OR
 jsonb_typeof(r->'timezone')<>'string' OR octet_length(r->>'timezone') NOT BETWEEN 1 AND 128 OR r->>'timezone'='Local' OR
 NOT EXISTS(SELECT 1 FROM pg_timezone_names z WHERE z.name=r->>'timezone') OR
 jsonb_typeof(r->'days')<>'array' OR jsonb_array_length(r->'days')>31 OR NOT app.marketing_metrics_valid(r->'totals',20) THEN RETURN false; END IF;
 FOR day IN SELECT a FROM jsonb_array_elements(r->'days') a LOOP
  IF jsonb_typeof(day)<>'object' OR NOT day ? 'date' OR jsonb_typeof(day->'date')<>'string' OR day->>'date' !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' OR
  NOT app.marketing_metrics_valid(day-'date',18) THEN RETURN false; END IF;
  date_value:=(day->>'date')::date;
  IF day->>'date'<>to_char(date_value,'YYYY-MM-DD') OR date_value<since_at OR date_value>until_at OR date_value<=previous_date THEN RETURN false; END IF;
  previous_date:=date_value;
  spend:=spend+(day->>'spend_decimal')::numeric; impressions:=impressions+(day->>'impressions')::numeric; clicks:=clicks+(day->>'clicks')::numeric;
 END LOOP;
 RETURN (r->'totals'->>'spend_decimal')::numeric=spend AND (r->'totals'->>'impressions')::numeric=impressions AND (r->'totals'->>'clicks')::numeric=clicks;
EXCEPTION WHEN OTHERS THEN RETURN false;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_workspace_valid(jsonb,uuid,uuid,date,date) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.provider_sync_claim(preferred_provider text)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,requested_by uuid,since date,until date,provider text,start_at timestamptz,end_at timestamptz,currency text,state text,
 before_revision bigint,revision bigint,lease_token uuid,property_account text,envelope bytea)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE j app.analytics_sync_jobs; c app.integration_connections; s app.integration_credentials; failure text; next_token uuid;
BEGIN
 IF preferred_provider IS NULL OR preferred_provider NOT IN ('ga4','woocommerce','meta_ads') THEN RAISE invalid_parameter_value; END IF;
 PERFORM app.analytics_writer_lock();
 IF (SELECT count(*) FROM app.analytics_sync_jobs a WHERE a.state='running' AND a.lease_until>clock_timestamp())>=2 THEN RETURN; END IF;
 SELECT * INTO j FROM app.analytics_sync_jobs a WHERE a.provider=preferred_provider AND (a.state='queued' OR (a.state='running' AND a.lease_until<=clock_timestamp()))
 ORDER BY a.created_at,a.id LIMIT 1 FOR UPDATE;
 IF NOT FOUND THEN RETURN; END IF;
 IF j.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=j.connection_id FOR UPDATE;
 SELECT * INTO s FROM app.integration_credentials a WHERE a.connection_id=j.connection_id;
 IF NOT app.authorization_allowed(j.requested_by,'clients.view',j.client_id) OR
 NOT app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id) OR
 NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=j.client_id AND a.archived_at IS NULL) THEN failure:='authorization_required';
 ELSIF c.client_id IS DISTINCT FROM j.client_id OR c.provider IS DISTINCT FROM j.provider OR
 c.state NOT IN ('pending','connected','reauthorization_required') OR c.revision IS DISTINCT FROM j.connection_revision OR
 c.generation IS DISTINCT FROM j.generation OR s.generation IS DISTINCT FROM j.generation OR s.revision IS DISTINCT FROM j.credential_revision THEN failure:='connection_changed';
 ELSIF j.attempts>=3 THEN failure:='interrupted'; END IF;
 IF failure IS NOT NULL THEN
  UPDATE app.analytics_sync_jobs a SET state='failed',reason=failure,lease_token=NULL,lease_until=NULL,
  finished_at=clock_timestamp(),updated_at=greatest(clock_timestamp(),a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
  RETURN QUERY SELECT j.id,j.client_id,j.connection_id,j.requested_by,j.since,j.until,j.provider,j.start_at,j.end_at,j.currency,'failed'::text,j.revision,j.revision+1,NULL::uuid,NULL::text,NULL::bytea;
  RETURN;
 END IF;
 next_token:=gen_random_uuid();
 UPDATE app.analytics_sync_jobs a SET state='running',attempts=a.attempts+1,lease_token=next_token,lease_until=clock_timestamp()+INTERVAL '180 seconds',
 updated_at=greatest(clock_timestamp(),a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
 RETURN QUERY SELECT j.id,j.client_id,j.connection_id,j.requested_by,j.since,j.until,j.provider,j.start_at,j.end_at,j.currency,'running'::text,j.revision,j.revision+1,next_token,c.provider_account_id,s.envelope;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.provider_sync_claim(text) FROM PUBLIC;

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.provider_sync_finish(selected_provider text,job uuid,token uuid,value jsonb)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,state text,before_job_revision bigint,job_revision bigint,
 before_connection_revision bigint,connection_revision bigint,snapshot_id uuid,before_snapshot_revision bigint,snapshot_revision bigint)
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE j app.analytics_sync_jobs; c app.integration_connections; saved app.analytics_snapshots; failure text; next_connection bigint; now_at timestamptz;
BEGIN
 IF selected_provider IS NULL OR selected_provider NOT IN ('ga4','woocommerce','meta_ads') THEN RAISE invalid_parameter_value; END IF;
 PERFORM app.analytics_writer_lock();
 SELECT * INTO j FROM app.analytics_sync_jobs a WHERE a.id=job AND a.provider=selected_provider AND a.state='running' AND a.lease_token=token
 AND a.lease_until>clock_timestamp() FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION USING ERRCODE='P0003',MESSAGE='Integration synchronization conflict'; END IF;
 IF j.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
 SELECT * INTO c FROM app.integration_connections a WHERE a.id=j.connection_id FOR UPDATE;
 IF NOT app.analytics_job_allowed(job,token) THEN
  failure:='connection_changed';
  IF NOT app.authorization_allowed(j.requested_by,'clients.view',j.client_id) OR NOT app.authorization_allowed(j.requested_by,'integrations.manage',j.client_id) OR
  NOT EXISTS(SELECT 1 FROM app.clients a WHERE a.id=j.client_id AND a.archived_at IS NULL) THEN failure:='authorization_required'; END IF;
 ELSIF value IS NULL THEN failure:='provider_unavailable';
 ELSIF (j.provider='ga4' AND NOT app.analytics_workspace_valid(value,j.client_id,j.connection_id,j.since,j.until)) OR
 (j.provider='woocommerce' AND NOT app.commerce_workspace_valid(value,j.client_id,j.connection_id,j.start_at,j.end_at,j.currency)) OR
 (j.provider='meta_ads' AND NOT app.marketing_workspace_valid(value,j.client_id,j.connection_id,j.since,j.until)) THEN RAISE invalid_parameter_value;
 END IF;
 now_at:=clock_timestamp(); next_connection:=c.revision;
 IF failure IS NULL THEN
  IF c.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
  SELECT * INTO saved FROM app.analytics_snapshots a WHERE a.connection_id=j.connection_id AND a.generation=j.generation AND a.provider=j.provider AND a.since IS NOT DISTINCT FROM j.since AND a.until IS NOT DISTINCT FROM j.until AND a.start_at IS NOT DISTINCT FROM j.start_at AND a.end_at IS NOT DISTINCT FROM j.end_at AND a.currency IS NOT DISTINCT FROM j.currency FOR UPDATE;
  IF saved.revision=9223372036854775807 THEN RAISE invalid_parameter_value; END IF;
  INSERT INTO app.analytics_snapshots(id,client_id,connection_id,generation,since,until,workspace,revision,synced_at,provider,start_at,end_at,currency)
  VALUES(coalesce(saved.id,gen_random_uuid()),j.client_id,j.connection_id,j.generation,j.since,j.until,value,coalesce(saved.revision,0)+1,now_at,j.provider,j.start_at,j.end_at,j.currency)
  ON CONFLICT ON CONSTRAINT analytics_snapshot_period DO UPDATE SET workspace=EXCLUDED.workspace,revision=EXCLUDED.revision,synced_at=EXCLUDED.synced_at;
  next_connection:=c.revision+1;
  UPDATE app.integration_connections a SET state='connected',revision=next_connection,updated_at=greatest(now_at,a.updated_at) WHERE a.id=c.id;
 END IF;
 UPDATE app.analytics_sync_jobs a SET state=CASE WHEN failure IS NULL THEN 'succeeded' ELSE 'failed' END,reason=failure,
 lease_token=NULL,lease_until=NULL,finished_at=now_at,updated_at=greatest(now_at,a.updated_at),revision=a.revision+1 WHERE a.id=j.id;
 RETURN QUERY SELECT j.id,j.client_id,j.connection_id,CASE WHEN failure IS NULL THEN 'succeeded'::text ELSE 'failed'::text END,
 j.revision,j.revision+1,c.revision,next_connection,
 CASE WHEN failure IS NULL THEN (SELECT a.id FROM app.analytics_snapshots a WHERE a.connection_id=j.connection_id AND a.generation=j.generation AND a.provider=j.provider AND a.since IS NOT DISTINCT FROM j.since AND a.until IS NOT DISTINCT FROM j.until AND a.start_at IS NOT DISTINCT FROM j.start_at AND a.end_at IS NOT DISTINCT FROM j.end_at AND a.currency IS NOT DISTINCT FROM j.currency) ELSE NULL::uuid END,
 CASE WHEN failure IS NULL THEN coalesce(saved.revision,0) ELSE 0::bigint END,
 CASE WHEN failure IS NULL THEN coalesce(saved.revision,0)+1 ELSE 0::bigint END;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.provider_sync_finish(text,uuid,uuid,jsonb) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.marketing_sync_finish(job uuid,token uuid,value jsonb)
RETURNS TABLE(job_id uuid,client_id uuid,connection_id uuid,state text,before_job_revision bigint,job_revision bigint,
 before_connection_revision bigint,connection_revision bigint,snapshot_id uuid,before_snapshot_revision bigint,snapshot_revision bigint)
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
 SELECT * FROM app.provider_sync_finish('meta_ads',job,token,value);
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.marketing_sync_finish(uuid,uuid,jsonb) FROM PUBLIC;


-- +goose Up
-- Legacy profile URL remains byte-preserved for compatibility and recovery.
CREATE TABLE app.client_websites (
 id uuid PRIMARY KEY CHECK(id<>'00000000-0000-0000-0000-000000000000'::uuid),
 client_id uuid NOT NULL REFERENCES app.clients(id),
 name text NOT NULL CHECK(char_length(name) BETWEEN 1 AND 200 AND name=btrim(name) AND name!~'[[:cntrl:]]'),
 url text NOT NULL CHECK(char_length(url) BETWEEN 1 AND 2048 AND url!~'[[:cntrl:]]'),
 domain text NOT NULL CHECK(char_length(domain)<=253 AND domain=lower(domain) AND domain!~'[[:cntrl:]]'),
 description text NOT NULL DEFAULT '' CHECK(char_length(description)<=4000 AND description!~'[[:cntrl:]]'),
 is_primary boolean NOT NULL DEFAULT false,
 needs_review boolean NOT NULL DEFAULT false,
 legacy_source boolean NOT NULL DEFAULT false,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 archived_at timestamptz,
 UNIQUE(id,client_id),
 CHECK(updated_at>=created_at AND (archived_at IS NULL OR archived_at>=created_at)),
 CHECK(NOT is_primary OR (archived_at IS NULL AND NOT needs_review)),
 CHECK(needs_review OR (url~'^https?://' AND domain~'^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$'))
);
CREATE INDEX client_websites_client ON app.client_websites(client_id,id);
CREATE UNIQUE INDEX client_websites_primary ON app.client_websites(client_id) WHERE is_primary AND archived_at IS NULL;
CREATE UNIQUE INDEX client_websites_legacy ON app.client_websites(client_id) WHERE legacy_source;
CREATE UNIQUE INDEX client_websites_active_url ON app.client_websites(client_id,url) WHERE archived_at IS NULL AND NOT needs_review;
-- Migration accepts only a conservative hostname-only legacy syntax. Other values
-- stay exactly intact for explicit review, rather than inventing normalization.
INSERT INTO app.client_websites(id,client_id,name,url,domain,is_primary,needs_review,legacy_source,created_at,updated_at,archived_at)
 SELECT gen_random_uuid(),id,name,website,
 CASE WHEN website~'^https?://[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?/?$' THEN lower(regexp_replace(regexp_replace(website,'^https?://',''),'/$','')) ELSE '' END,
 archived_at IS NULL AND website~'^https?://[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?/?$',
 website!~'^https?://[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?/?$',true,created_at,updated_at,archived_at
 FROM app.clients WHERE website<>'';

-- A nullable association does not change provider/client/connection identity or
-- ciphertext AAD. Existing integrations remain unassigned, never guessed.
ALTER TABLE app.integration_connections ADD CONSTRAINT integration_connection_client_identity UNIQUE(id,client_id);
CREATE TABLE app.website_integrations (
 connection_id uuid PRIMARY KEY,
 website_id uuid NOT NULL,
 client_id uuid NOT NULL,
 FOREIGN KEY(website_id,client_id) REFERENCES app.client_websites(id,client_id),
 FOREIGN KEY(connection_id,client_id) REFERENCES app.integration_connections(id,client_id)
);
CREATE INDEX website_integrations_website ON app.website_integrations(website_id,connection_id);

-- +goose StatementBegin
CREATE FUNCTION app.website_document(target uuid) RETURNS jsonb
LANGUAGE sql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT jsonb_build_object('id',w.id,'client_id',w.client_id,'name',w.name,'url',w.url,'domain',w.domain,
 'description',w.description,'is_primary',w.is_primary,'needs_review',w.needs_review,
 'status',CASE WHEN w.archived_at IS NULL THEN 'active' ELSE 'archived' END,'revision',w.revision,
 'created_at',w.created_at,'updated_at',w.updated_at,'archived_at',w.archived_at)
 FROM app.client_websites w WHERE w.id=target;
$$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.website_list(actor uuid,client uuid,after_id uuid,page_limit integer,state text) RETURNS SETOF jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR state IS NULL OR state NOT IN ('active','archived','all') THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT app.website_document(w.id) FROM app.client_websites w WHERE w.client_id=client
 AND (after_id IS NULL OR w.id>after_id) AND (state='all' OR (state='active' AND w.archived_at IS NULL) OR (state='archived' AND w.archived_at IS NOT NULL))
 ORDER BY w.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.website_read(actor uuid,client uuid,target uuid) RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT EXISTS(SELECT 1 FROM app.client_websites WHERE id=target AND client_id=client) THEN RETURN NULL; END IF;
 RETURN app.website_document(target);
END; $$;
-- +goose StatementEnd
-- Returns safe changed-record markers for one atomic multi-event audit.
-- +goose StatementBegin
CREATE FUNCTION app.website_write(actor uuid,client uuid,target uuid,expected bigint,operation text,profile jsonb) RETURNS jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE current app.client_websites%ROWTYPE; previous app.client_websites%ROWTYPE; changes jsonb:='[]'::jsonb; permission text;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 permission:=CASE WHEN operation='archive' THEN 'clients.archive' ELSE 'clients.update' END;
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,permission,client) OR NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client) THEN RETURN jsonb_build_object('code','missing'); END IF;
 IF NOT EXISTS(SELECT 1 FROM app.clients WHERE id=client AND archived_at IS NULL) THEN RETURN jsonb_build_object('code','conflict'); END IF;
 IF operation IS NULL OR operation NOT IN ('create','update','archive','primary') OR expected IS NULL OR expected<0 OR expected>=9223372036854775807 THEN RETURN jsonb_build_object('code','invalid'); END IF;
 IF operation='create' THEN
  IF expected<>0 THEN RETURN jsonb_build_object('code','invalid'); END IF;
 ELSE
  SELECT * INTO current FROM app.client_websites WHERE id=target AND client_id=client FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('code','missing'); END IF;
  IF current.revision<>expected OR current.archived_at IS NOT NULL THEN RETURN jsonb_build_object('code','conflict'); END IF;
 END IF;
 IF operation IN ('create','update') THEN
  IF profile IS NULL OR jsonb_typeof(profile)<>'object' OR profile-ARRAY['name','url','domain','description']<>'{}'::jsonb OR
  jsonb_typeof(profile->'name') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'url') IS DISTINCT FROM 'string' OR
  jsonb_typeof(profile->'domain') IS DISTINCT FROM 'string' OR jsonb_typeof(profile->'description') IS DISTINCT FROM 'string' THEN RETURN jsonb_build_object('code','invalid'); END IF;
  IF operation='create' THEN
   INSERT INTO app.client_websites(id,client_id,name,url,domain,description) VALUES(target,client,profile->>'name',profile->>'url',profile->>'domain',profile->>'description');
  ELSE
   UPDATE app.client_websites SET name=profile->>'name',url=profile->>'url',domain=profile->>'domain',description=profile->>'description',needs_review=false,revision=revision+1,updated_at=clock_timestamp() WHERE id=target;
  END IF;
 ELSIF operation='archive' THEN
  UPDATE app.client_websites SET is_primary=false,archived_at=clock_timestamp(),updated_at=clock_timestamp(),revision=revision+1 WHERE id=target;
 ELSE
  IF current.needs_review THEN RETURN jsonb_build_object('code','invalid'); END IF;
  SELECT * INTO previous FROM app.client_websites WHERE client_id=client AND is_primary AND id<>target FOR UPDATE;
  IF FOUND THEN
   IF previous.revision>=9223372036854775807 THEN RETURN jsonb_build_object('code','conflict'); END IF;
   UPDATE app.client_websites SET is_primary=false,revision=revision+1,updated_at=clock_timestamp() WHERE id=previous.id;
   changes:=changes||jsonb_build_array(jsonb_build_object('id',previous.id,'before',previous.revision,'after',previous.revision+1,'action','updated'));
  END IF;
  UPDATE app.client_websites SET is_primary=true,revision=revision+1,updated_at=clock_timestamp() WHERE id=target;
 END IF;
 RETURN jsonb_build_object('code','ok','changes',changes||jsonb_build_array(jsonb_build_object('id',target,'before',expected,'after',expected+1,'action',CASE operation WHEN 'create' THEN 'created' WHEN 'archive' THEN 'archived' ELSE 'updated' END)));
EXCEPTION WHEN check_violation OR not_null_violation OR invalid_text_representation THEN RETURN jsonb_build_object('code','invalid');
 WHEN unique_violation THEN RETURN jsonb_build_object('code','conflict');
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.website_connections(actor uuid,client uuid,website uuid,after_id uuid,page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT (app.authorization_allowed(actor,'integrations.view',client) OR app.authorization_allowed(actor,'analytics.view',client)) OR
 NOT EXISTS(SELECT 1 FROM app.client_websites WHERE id=website AND client_id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',c.id,'client_id',c.client_id,'provider',c.provider,'state',c.state,'revision',c.revision::text,'created_at',to_char(c.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'updated_at',to_char(c.updated_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'))
 FROM app.integration_connections c JOIN app.website_integrations b ON b.connection_id=c.id
 WHERE c.client_id=client AND b.client_id=client AND b.website_id=website AND (after_id IS NULL OR c.id>after_id)
 ORDER BY c.id LIMIT page_limit;
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.website_connection_binding(actor uuid,client uuid,website uuid,connection uuid,expected bigint,attach boolean) RETURNS text
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'integrations.manage',client) OR
 NOT EXISTS(SELECT 1 FROM app.client_websites w JOIN app.clients c ON c.id=w.client_id WHERE w.id=website_connection_binding.website AND w.client_id=client AND w.archived_at IS NULL AND c.archived_at IS NULL) OR
 NOT EXISTS(SELECT 1 FROM app.integration_connections WHERE id=connection AND client_id=client) THEN RETURN 'missing'; END IF;
 IF expected IS NULL OR expected<1 OR attach IS NULL THEN RETURN 'invalid'; END IF;
 IF NOT EXISTS(SELECT 1 FROM app.client_websites WHERE id=website AND revision=expected) THEN RETURN 'conflict'; END IF;
 IF attach THEN
  IF EXISTS(SELECT 1 FROM app.website_integrations WHERE connection_id=connection) THEN RETURN 'conflict'; END IF;
  INSERT INTO app.website_integrations VALUES(connection,website,client);
 ELSE
  DELETE FROM app.website_integrations WHERE connection_id=connection AND website_id=website AND client_id=client;
  IF NOT FOUND THEN RETURN 'conflict'; END IF;
 END IF;
 UPDATE app.client_websites SET revision=revision+1,updated_at=clock_timestamp() WHERE id=website;
 RETURN 'ok';
END; $$;
-- +goose StatementEnd
-- The actual provider handler still independently enforces its original grants.
-- +goose StatementBegin
CREATE FUNCTION app.website_connection_allowed(actor uuid,client uuid,website uuid,connection uuid,mutation boolean DEFAULT false) RETURNS boolean
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 RETURN app.authorization_allowed(actor,'clients.view',client) AND
 EXISTS(SELECT 1 FROM app.website_integrations b JOIN app.integration_connections c ON c.id=b.connection_id
 WHERE b.client_id=client AND b.website_id=website AND b.connection_id=connection AND c.client_id=client) AND
 (NOT mutation OR EXISTS(SELECT 1 FROM app.client_websites w JOIN app.clients c ON c.id=w.client_id WHERE w.id=website_connection_allowed.website AND w.client_id=client AND w.archived_at IS NULL AND c.archived_at IS NULL));
END; $$;
-- +goose StatementEnd
REVOKE ALL ON app.client_websites,app.website_integrations FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.website_document(uuid),app.website_list(uuid,uuid,uuid,integer,text),app.website_read(uuid,uuid,uuid),
 app.website_write(uuid,uuid,uuid,bigint,text,jsonb),app.website_connections(uuid,uuid,uuid,uuid,integer),
 app.website_connection_binding(uuid,uuid,uuid,uuid,bigint,boolean),app.website_connection_allowed(uuid,uuid,uuid,uuid,boolean) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.website_legacy_create() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 IF NEW.website<>'' THEN
 INSERT INTO app.client_websites(id,client_id,name,url,domain,is_primary,needs_review,legacy_source)
 VALUES(gen_random_uuid(),NEW.id,NEW.name,NEW.website,
 CASE WHEN NEW.website~'^https?://[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?/?$' THEN lower(regexp_replace(regexp_replace(NEW.website,'^https?://',''),'/$','')) ELSE '' END,
 NEW.website~'^https?://[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?/?$',NEW.website!~'^https?://[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?/?$',true);
 END IF;
 RETURN NEW;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.website_legacy_create() FROM PUBLIC;
CREATE TRIGGER website_legacy_create AFTER INSERT ON app.clients FOR EACH ROW EXECUTE FUNCTION app.website_legacy_create();

-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.activity_list(actor uuid,client uuid,after_time timestamptz,after_id uuid,page_limit integer)
RETURNS TABLE(id uuid,client_id uuid,occurred_at timestamptz,event_type text,resource_kind text,resource_id uuid)
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE task_access boolean; planning_access boolean; reminder_access boolean;
BEGIN
 IF NOT app.authorization_allowed(actor,'activity.view',client) OR
 NOT app.authorization_allowed(actor,'clients.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.clients c WHERE c.id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR
 (after_time IS NULL)<>(after_id IS NULL) OR after_id='00000000-0000-0000-0000-000000000000'::uuid OR
 (after_time IS NOT NULL AND (NOT isfinite(after_time) OR after_time<TIMESTAMPTZ '0001-01-01 00:00:00+00' OR after_time>=TIMESTAMPTZ '10000-01-01 00:00:00+00')) THEN RAISE invalid_parameter_value; END IF;
 task_access:=app.authorization_allowed(actor,'tasks.view',client);
 planning_access:=app.authorization_allowed(actor,'planning.view',client);
 reminder_access:=app.authorization_allowed(actor,'reminders.view',client);
 RETURN QUERY SELECT e.id,e.client_id,e.occurred_at,e.event_name,e.resource_kind,e.resource_id
 FROM app.audit_events e
 WHERE e.client_id=client AND e.schema_version=1 AND
 ((e.resource_kind='website' AND e.event_name IN ('website.created','website.updated','website.archived')) OR
  (e.resource_kind='client' AND e.event_name IN ('client.created','client.updated','client.archived')) OR
  (task_access AND e.resource_kind='task' AND e.event_name IN ('task.created','task.updated','task.archived','task.completed','task.cancelled')) OR
  (planning_access AND e.resource_kind='plan' AND e.event_name IN ('plan.created','plan.updated','plan.archived')) OR
  (planning_access AND e.resource_kind='milestone' AND e.event_name IN ('milestone.created','milestone.updated','milestone.archived')) OR
  (reminder_access AND e.resource_kind='reminder' AND e.event_name IN ('reminder.created','reminder.updated','reminder.completed','reminder.dismissed'))) AND
 (after_time IS NULL OR (e.occurred_at,e.id)<(after_time,after_id))
 ORDER BY e.occurred_at DESC,e.id DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd

-- +goose StatementBegin
CREATE FUNCTION app.website_activity(actor uuid,client uuid,website uuid,after_id uuid,page_limit integer) RETURNS SETOF jsonb
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog SET timezone='UTC' AS $$
DECLARE after_time timestamptz;
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT app.authorization_allowed(actor,'clients.view',client) OR NOT app.authorization_allowed(actor,'activity.view',client) OR
 NOT EXISTS(SELECT 1 FROM app.client_websites WHERE id=website AND client_id=client) THEN RAISE no_data_found; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 THEN RAISE invalid_parameter_value; END IF;
 IF after_id IS NOT NULL THEN SELECT occurred_at INTO after_time FROM app.audit_events WHERE id=after_id AND client_id=client AND resource_kind='website' AND resource_id=website;
 IF NOT FOUND THEN RAISE invalid_parameter_value; END IF; END IF;
 RETURN QUERY SELECT jsonb_build_object('id',e.id,'client_id',e.client_id,'occurred_at',to_char(e.occurred_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'event_type',e.event_name,'resource_kind','website','resource_id',e.resource_id,'summary',CASE e.event_name WHEN 'website.created' THEN 'Website created.' WHEN 'website.updated' THEN 'Website updated.' ELSE 'Website archived.' END)
 FROM app.audit_events e WHERE e.client_id=client AND e.resource_kind='website' AND e.resource_id=website AND e.event_name IN ('website.created','website.updated','website.archived')
 AND (after_id IS NULL OR (e.occurred_at,e.id)<(after_time,after_id)) ORDER BY e.occurred_at DESC,e.id DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.website_activity(uuid,uuid,uuid,uuid,integer) FROM PUBLIC;

-- +goose StatementBegin
CREATE FUNCTION app.website_legacy_marker(actor uuid,client uuid) RETURNS uuid
LANGUAGE sql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
 SELECT w.id FROM app.client_websites w WHERE w.client_id=client AND w.legacy_source AND app.authorization_allowed(actor,'clients.create',NULL);
$$;
-- +goose StatementEnd
REVOKE EXECUTE ON FUNCTION app.website_legacy_marker(uuid,uuid) FROM PUBLIC;


-- +goose Up
CREATE TABLE app.user_locale_preferences (
 user_id uuid PRIMARY KEY REFERENCES app.users(id),
 locale text NOT NULL CHECK(locale IN ('en','tr','ro','de','fr')),
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0)
);
-- +goose StatementBegin
CREATE FUNCTION app.user_locale_read(actor uuid) RETURNS text
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
BEGIN
 PERFORM pg_advisory_xact_lock_shared(871092650209);
 IF NOT EXISTS(SELECT 1 FROM app.users WHERE id=actor AND status='active') THEN RAISE no_data_found; END IF;
 RETURN (SELECT locale FROM app.user_locale_preferences WHERE user_id=actor);
END; $$;
-- +goose StatementEnd
-- +goose StatementBegin
CREATE FUNCTION app.user_locale_write(actor uuid,selected text) RETURNS bigint
LANGUAGE plpgsql VOLATILE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE task_revision bigint;
BEGIN
 PERFORM pg_advisory_xact_lock(871092650209);
 IF NOT EXISTS(SELECT 1 FROM app.users WHERE id=actor AND status='active') THEN RAISE no_data_found; END IF;
 IF selected IS NULL OR selected NOT IN ('en','tr','ro','de','fr') THEN RAISE invalid_parameter_value; END IF;
 INSERT INTO app.user_locale_preferences(user_id,locale) VALUES(actor,selected)
 ON CONFLICT(user_id) DO UPDATE SET locale=excluded.locale,revision=app.user_locale_preferences.revision+1 RETURNING revision INTO task_revision;
 RETURN task_revision;
END; $$;
-- +goose StatementEnd
REVOKE ALL ON app.user_locale_preferences FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION app.user_locale_read(uuid),app.user_locale_write(uuid,text) FROM PUBLIC;

-- Evaluate current client visibility once per directory statement. No table,
-- API, permission catalogue or mutation/audit change; retain the function ACL.
-- +goose Up
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION app.client_list(actor uuid,after_id uuid,page_limit integer,state text,search text,tag_filter text,descending boolean) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE global_view boolean; scoped_clients uuid[];
BEGIN
 -- The identical effective grant set belongs to this statement's snapshot.
 -- Evaluate once, rather than joining roles/permissions for every candidate row.
 SELECT coalesce(bool_or(g.scope_kind='global'),false),
  coalesce(array_agg(g.client_id) FILTER (WHERE g.scope_kind='client'),'{}'::uuid[])
 INTO global_view,scoped_clients
 FROM app.authorization_grants(actor) g WHERE g.permission_key='clients.view';
 IF NOT global_view AND cardinality(scoped_clients)=0 THEN RAISE insufficient_privilege; END IF;
 IF page_limit IS NULL OR page_limit NOT BETWEEN 1 AND 101 OR state IS NULL OR state NOT IN ('active','archived','all') OR
  search IS NULL OR char_length(search)>100 OR tag_filter IS NULL OR char_length(tag_filter)>40 OR descending IS NULL THEN RAISE invalid_parameter_value; END IF;
 RETURN QUERY SELECT app.client_document(c.id,false) FROM app.clients c
 WHERE (global_view OR c.id=ANY(scoped_clients))
  AND (state='all' OR (state='active' AND c.archived_at IS NULL) OR (state='archived' AND c.archived_at IS NOT NULL))
  AND (search='' OR strpos(lower(c.name),lower(search))>0)
  AND (tag_filter='' OR EXISTS (SELECT 1 FROM app.client_tags t WHERE t.client_id=c.id AND t.tag=tag_filter))
  AND (after_id IS NULL OR (NOT descending AND c.id>after_id) OR (descending AND c.id<after_id))
 ORDER BY CASE WHEN NOT descending THEN c.id END ASC,CASE WHEN descending THEN c.id END DESC LIMIT page_limit;
END; $$;
-- +goose StatementEnd


CREATE TABLE public.goose_db_version (id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,version_id bigint NOT NULL,is_applied boolean NOT NULL,tstamp timestamp NOT NULL DEFAULT now()); INSERT INTO public.goose_db_version(version_id,is_applied) VALUES (28,true);
COMMIT;
